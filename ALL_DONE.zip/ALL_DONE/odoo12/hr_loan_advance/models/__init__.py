# -*- coding: utf-8 -*-
from . import config
from . import res_config
from . import model
from . import hr
from . import hr_payroll






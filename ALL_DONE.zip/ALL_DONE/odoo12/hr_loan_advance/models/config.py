# -*- coding: utf-8 -*-
from openerp import models, fields, api, _
from openerp.exceptions import except_orm, Warning, RedirectWarning


class hr_accounting_config(models.TransientModel):
    _inherit = 'hr.accounting.config'

    def _get_loan_journal(self):
        config = self._get_hr_accounting_config()
        if (config) and config.loan_journal_id: return config.loan_journal_id.id
        return False

    def _get_advance_journal(self):
        config = self._get_hr_accounting_config()
        if (config) and config.advance_journal_id: return config.advance_journal_id.id
        return False

    loan_journal_id = fields.Many2one('account.journal', string='Loan Journal',
                                      help="The journal used when the loan is done.", default=_get_loan_journal)
    advance_journal_id = fields.Many2one('account.journal', string='Advance Journal',
                                         help="The journal used when the loan is done.", default=_get_advance_journal)

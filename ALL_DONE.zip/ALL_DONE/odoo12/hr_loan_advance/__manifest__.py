# -*- coding: utf-8 -*-
{
    "name" : "HR Loan Advance",
    "version" : "0.1",
    "author" : "Abdul Nazar,Pioneer Solution",
    "summary" : "HR Loan and Advance Management",
    "website" : "www.ps-sa.net",
    "category" : "Human Resources",
    'depends' : ['base','hr','hr_contract','hr_payroll','hr_payroll_account','account', 'common_ps'],
    'data' : [
        "data/template.xml",
        "views/menu.xml",
        "views/config_view.xml",
        "views/res_config_view.xml",
        "views/hr_view.xml",
        "views/model_view.xml",
        "data/sequence.xml",
        "data/data.xml",
        "security/hr_security.xml",
        "security/ir.model.access.csv",
        #"views/workflow.xml",
        "report/report.xml",
        "report/report_hr_loan.xml",
        "report/report_hr_advance.xml",
        "report/report_loan_advance.xml",
        "wizard/report_wizard_view.xml",


    ],

    "installable": True,
    'application': True,
    "auto_install": False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

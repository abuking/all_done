# -*- coding: utf-8 -*-
from odoo import http

# class ContractReport(http.Controller):
#     @http.route('/contract_report/contract_report/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/contract_report/contract_report/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('contract_report.listing', {
#             'root': '/contract_report/contract_report',
#             'objects': http.request.env['contract_report.contract_report'].search([]),
#         })

#     @http.route('/contract_report/contract_report/objects/<model("contract_report.contract_report"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('contract_report.object', {
#             'object': obj
#         })
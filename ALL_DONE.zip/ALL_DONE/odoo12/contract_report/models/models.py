# -*- coding: utf-8 -*-

from odoo import models, fields, api

from odoo.exceptions import ValidationError



class Contract(models.Model):
    _inherit = 'hr.contract'

    contract_issued_date = fields.Date('Issue Date')
    contract_no_year = fields.Integer('No of Year')
    contract_med_class = fields.Char('Class')
    contract_air_ticket = fields.Integer ('No of Ticket')
    contract_housing_allowance = fields.Float('Housing Allowance')
    contract_other_ex = fields.Float('Other Allowance')
    contract_wage = fields.Monetary(related='wage', string='Base Salary')
    contract_total = fields.Float('Total')


# class contract_report(models.Model):
#     _name = 'contract_report.contract_report'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100
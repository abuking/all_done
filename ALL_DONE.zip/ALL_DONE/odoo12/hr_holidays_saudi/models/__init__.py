# -*- coding: utf-8 -*-
from . import config
from . import hr
from . import hr_holidays_saudi
from . import hr_res_config





# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

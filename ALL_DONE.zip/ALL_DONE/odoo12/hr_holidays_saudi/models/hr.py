# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from datetime import datetime,timedelta,date
from dateutil import relativedelta
import math


class hr_employee(models.Model):
    _inherit = 'hr.employee'


    def _compute_date(self, date_from, date_to, DATETIME_FORMAT):
        days = months = years = 0

        #differents = relativedelta.relativedelta(datetime.strptime(date_to, DATETIME_FORMAT),datetime.strptime(date_from, DATETIME_FORMAT))
        differents = relativedelta.relativedelta(datetime.strptime(str(date_to), DATETIME_FORMAT), datetime.strptime(str(date_from), DATETIME_FORMAT))
        years = differents.years
        months = (years * 12) + differents.months
#        days = differents.days
        timedelta = datetime.strptime(str(date_to), DATETIME_FORMAT) - datetime.strptime(str(date_from), DATETIME_FORMAT)
        diff_day = timedelta.days + float(timedelta.seconds) / 86400
        days = round(math.floor(diff_day))
        return days, months, years

#    def _compute_year_result(self, employee_id, days, months, years, carryover_month):
#        result = 0
#        if carryover_month > 0:
#            mod = months % carryover_month
#            if mod <> 0:
#                a = mod / 12.0
#                result = int(a) * employee_id.type_id.annual_leave
#                if a > int(a):
#                    result += employee_id.type_id.annual_leave
#            else:
#                result = employee_id.type_id.leave_carryover_year * employee_id.type_id.annual_leave

#        else:
#            result = years * employee_id.type_id.annual_leave
#            if days > 0:
#                result += employee_id.type_id.annual_leave
#        return result

    def _compute_year_result(self, employee_id, days, months, years, carryover_month):
        result = 0
        if carryover_month > 0:
            diva, moda = divmod(months, carryover_month)
            if moda != 0:
                divb, modb = divmod(moda, 12)
                result = divb * employee_id.type_id.annual_leave
                if modb > 0:result += employee_id.type_id.annual_leave
            else:
                result = employee_id.type_id.leave_carryover_year * employee_id.type_id.annual_leave
        else:
            result = years * employee_id.type_id.annual_leave
            if days > 0:result += employee_id.type_id.annual_leave

        check_type = months % 12
        if employee_id.type_id.leave_start_month_type == 'every_year' and employee_id.type_id.leave_start_month > 0 and (check_type < employee_id.type_id.leave_start_month or check_type == employee_id.type_id.leave_start_month and days <= 0):
            result -= employee_id.type_id.annual_leave
        return result

    def _compute_month_result(self, employee_id, days, months, years, carryover_month):
        result = 0
        if carryover_month > 0:
            diva, moda = divmod(months, carryover_month)
            if moda != 0:result += moda * employee_id.type_id.annual_leave
            else:result += employee_id.type_id.leave_carryover_year * employee_id.type_id.annual_leave * 12
        else:
            result += months * employee_id.type_id.annual_leave
            if days > 0:result += employee_id.type_id.annual_leave
        divb, modb = divmod(months, 12)
        if employee_id.type_id.leave_start_month_type == 'every_year' and employee_id.type_id.leave_start_month > 0 and (modb < employee_id.type_id.leave_start_month or modb == employee_id.type_id.leave_start_month and days <= 0):

            result -= employee_id.type_id.annual_leave * 12
        
        return result

    def _compute_leave(self, employee_id):
        DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
        days = months = years = result = mod = a = 0
        current_date = (datetime.today()).strftime(DATETIME_FORMAT)
        if employee_id.joined_date and employee_id.type_id:
            days, months, years = self._compute_date(employee_id.joined_date, current_date, DATETIME_FORMAT)
            if (employee_id.type_id.leave_start_month < months) or (employee_id.type_id.leave_start_month == months and days > 0):
                carryover_month = employee_id.type_id.leave_carryover_year * 12
                if employee_id.type_id.annual_leave_type == 'year':result += self._compute_year_result(employee_id, days, months, years, carryover_month)
                if employee_id.type_id.annual_leave_type == 'month':result += self._compute_month_result(employee_id, days, months, years, carryover_month)
        return result

    @api.one
    @api.depends('joined_date', 'type_id')
    def _compute_availed_leave(self):
        self.availed_leave = self._compute_leave(self)

    @api.one
    @api.depends('availed_leave', 'used_leave')
    def _compute_balance_leave(self):
        self.balance_leave = self._compute_leave(self) - self.used_leave

    @api.one
    def _compute_holidays_count(self):
        self.holidays_count = self.env['hr.holidays.saudi'].search_count([('employee_id', '=', self.id)]) 



    type_id = fields.Many2one('hr.employee.type', string="Type")
    availed_leave = fields.Float(string='Availed Leave', readonly=True, compute='_compute_availed_leave', digits=dp.get_precision('Decimal Single'))
    used_leave = fields.Float(string='Used Leave', readonly=True, digits=dp.get_precision('Decimal Single'))
    balance_leave = fields.Float(string='Balance Leave', readonly=True, compute='_compute_balance_leave', digits=dp.get_precision('Decimal Single'))
    holidays_count = fields.Integer(string='Leaves', readonly=True, compute='_compute_holidays_count')



    @api.model
    def leave_compute(self, employee, date_from, date_to, deduction_type):
        total = 0
        deduction_ids = self.env['hr.holidays.deduction.summary.saudi'].search([('employee_id','=', employee), ('date','>=', date_from), ('date','<=', date_to), ('deduction_type','in', deduction_type), ('state','=', 'undeducted')])
        for record in deduction_ids:
            total += record.amount
        return total

    @api.model
    def overtime_compute(self, employee, date_from, date_to, wage, deduction_type):
        allowance = super(hr_employee, self).overtime_compute(employee, date_from, date_to, wage, deduction_type)
        deduction = self.leave_compute(employee, date_from, date_to, deduction_type)
        total = allowance - deduction
        return total




class hr_employee_type(models.Model):
    _name = 'hr.employee.type'

    name = fields.Char(string='Name', required=True, translate=True)
    annual_leave_type = fields.Selection([('month', 'Month'), ('year', 'Year'),], 'Annual Leave Type', required=True, default='month')
    annual_leave = fields.Float(string='Annual Leave', required=True, digits=dp.get_precision('Decimal Single'))
    leave_carryover_year = fields.Integer(string='Leave Carryover Year', required=True)
    leave_start_month = fields.Integer(string='Leave Start After (month)', required=True)
    leave_start_month_type = fields.Selection([('first_year', 'First Year Only'), ('every_year', 'Every Year'),], 'Leave Start Type', default='first_year')

    @api.constrains('leave_start_month', 'leave_carryover_year', 'annual_leave')
    def _value_constrains(self):
        if self.annual_leave < 0:
            raise except_orm(_('Invalid Value!'), _('Annual Leave should be possitive'))
        if self.leave_start_month < 0:
            raise except_orm(_('Invalid Value!'), _('Leave Start After (month) should be possitive'))
        if self.leave_carryover_year < 0:
            raise except_orm(_('Invalid Value!'), _('Leave Carryover Year should be possitive'))










     
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

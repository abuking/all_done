# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import except_orm, Warning, RedirectWarning


class update_used_vacation(models.TransientModel):
    _name = 'update.used.vacation'


    def _default_employee(self):
        return self.env['hr.employee'].browse(self._context.get('active_id'))


    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, default=_default_employee)
    days = fields.Float(string='Days', required=True)



    @api.multi
    def action_apply(self):
        self.employee_id.used_leave = self.days
        return {}






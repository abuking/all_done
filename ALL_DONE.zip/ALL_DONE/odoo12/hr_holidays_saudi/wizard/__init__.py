# -*- coding: utf-8 -*-
from . import update_used_vacation



# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:


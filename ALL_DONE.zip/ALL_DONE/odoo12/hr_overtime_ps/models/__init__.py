# -*- coding: utf-8 -*-
from . import hr_contract
from . import model






# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:



from odoo import models, fields, api
import time
#from odoo.report import report_sxw
from odoo import models, fields, api, _
from datetime import datetime, timedelta, time


class stock_move_report_ps(models.Model):
    _name = 'stock_ps.stock_ps'

    product_ids = fields.Many2many('product.product', string='Product')
    landscape = fields.Boolean(string='Landscape Mode', default=False)
    date_from = fields.Date(string='Start Date')
    date_to = fields.Date(string='End Date')
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.user.company_id.id)

    def print_report(self):
        data = {}
        data['form'] = self.read()[0]
        data['form'].update(self.read(['date_from', 'date_to','project_ids', 'company_id'])[0])
        datas = {
            'ids': [],
            'model': 'stock_ps.stock_ps',
            'form': data['form']
        }
        return self.env.ref("payslip_report_xls_ps.ps_action_report_payslip_ps").with_context(
            landscape=True).report_action(self, data=data)
        #return self.env['report'].with_context(landscape=False).get_action(self, 'stock_move_report_ps.report_stock_analysis', data=data)


#
# class stock_analysis(report_sxw.rml_parse):
#     def __init__(self, cr, uid, name, context):
#         super(stock_analysis, self).__init__(cr, uid, name, context)
#         self.localcontext.update({
#             'time': time,
#             'get_project': self.get_stock,
# 	        'get_task_count':self.get_task,
#
#         })
#         self.context = context
#
#     def get_stock(self, data):
#         record_ids = {}
#         env = api.Environment(self.cr, self.uid, self.localcontext)
#         domain = []
#         if len(data['form']['product_ids']) > 0:
#             domain += [('id', 'in', data['form']['product_ids'])]
#         record_ids = env['product.product'].search(domain)
#         return record_ids
#
#     def get_task(self, product, data):
#         env = api.Environment(self.cr, self.uid, self.localcontext)
#         domain = [('product_id','=',product.id)]
#         if data['form']['date_from']:
#             domain += [('create_date','>=',data['form']['date_from'])]
#         if data['form']['date_to']:
#             domain += [('create_date','<=',data['form']['date_to'])]
#         task_ids = env['stock.move'].search(domain)
#         return task_ids
#
#
#
class report_stock_analysis(models.AbstractModel):
    _name = 'report.stock_move_report_ps.report_stock_analysis'
    # _inherit = 'report.abstract_report'
    # _template = 'stock_move_report_ps.report_stock_analysis'
    # _wrapped_report_class = stock_analysis


    @api.model
    def _get_report_values(self, docids, data=None):
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        clause = []
        sales_records = []
        return {
            'doc_ids': self.ids,
            'doc_model': self.model,
            'docs': docs,
            'data': data,
            'get_project': self._get_stock,
            'get_task_count':self._get_task,
        }
    def _get_stock(self, data):
        record_ids = {}
        env = api.Environment(self.cr, self.uid, self.localcontext)
        domain = []
        if len(data['form']['product_ids']) > 0:
            domain += [('id', 'in', data['form']['product_ids'])]
        record_ids = env['product.product'].search(domain)
        return record_ids

    def _get_task(self, product, data):
        env = api.Environment(self.cr, self.uid, self.localcontext)
        domain = [('product_id','=',product.id)]
        if data['form']['date_from']:
            domain += [('create_date','>=',data['form']['date_from'])]
        if data['form']['date_to']:
            domain += [('create_date','<=',data['form']['date_to'])]
        task_ids = env['stock.move'].search(domain)
        return task_ids
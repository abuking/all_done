# -*- coding: utf-8 -*-
from odoo import http

# class StockPs(http.Controller):
#     @http.route('/stock_ps/stock_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/stock_ps/stock_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('stock_ps.listing', {
#             'root': '/stock_ps/stock_ps',
#             'objects': http.request.env['stock_ps.stock_ps'].search([]),
#         })

#     @http.route('/stock_ps/stock_ps/objects/<model("stock_ps.stock_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('stock_ps.object', {
#             'object': obj
#         })
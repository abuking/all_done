# -*- coding: utf-8 -*-
from odoo import http

# class HrLetter(http.Controller):
#     @http.route('/hr_letter/hr_letter/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_letter/hr_letter/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_letter.listing', {
#             'root': '/hr_letter/hr_letter',
#             'objects': http.request.env['hr_letter.hr_letter'].search([]),
#         })

#     @http.route('/hr_letter/hr_letter/objects/<model("hr_letter.hr_letter"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_letter.object', {
#             'object': obj
#         })
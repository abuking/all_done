# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

try:
    from service_solutions.common_ps.models.nazar import mail_create, get_email_from, get_config
except:
    try:
        from odoo.common_ps.models.nazar import mail_create, get_email_from, get_config
    except:
        from addons.common_ps.models.nazar import mail_create, get_email_from, get_config
from odoo.exceptions import UserError


def _get_employee(obj):
    ids = obj.env['hr.employee'].search([('user_id', '=', obj.env.uid)])
    if ids:
        return ids[0]
    else:
        raise UserError(_('The user is not an employee.'))
    return False


class HrLetter(models.Model):
    _name = 'hr.letter'
    _rec_name = 'employee_id'
    _description = 'Hr  Letter'
    _inherit = ['mail.thread', 'resource.mixin']

    @api.one
    def _get_current_user(self):
        self.is_direct_manager = False
        if (
                self.employee_id and self.employee_id.parent_id and self.employee_id.parent_id.user_id) and self.employee_id.parent_id.user_id.id == self.env.uid:
            self.is_direct_manager = True

    @api.multi
    def get_salary(self):
        cont_obj = self.env['hr.contract']
        for case in self:
            cont_id = cont_obj.search([('employee_id', '=', case.id)], limit=1)
            case.salary = cont_id.wage

    state = fields.Selection([
        ('draft', 'Draft'),
        ('request', 'Waiting for Approval'),
        ('confirm', 'Confirm'),
        ('off_confirm', 'Confirm'),
        ('approve', 'Approve'),
        ('gm_approve', 'GM Approve'),
        ('refuse', 'Refused'),
        ('cancel', 'Cancel'),
    ],
        'Status', readonly=True, track_visibility='onchange', default='draft')
    employee_id = fields.Many2one('hr.employee', 'Employee', default=_get_employee)
    letter_to = fields.Text('To', readonly=True, states={'draft': [('readonly', False)]}, translate=True)
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.user.company_id)
    country_id = fields.Many2one('res.country', related="employee_id.country_id", string='Nationality')
    emp_code = fields.Char('Id/Iqama', related='employee_id.identification_id')
    is_direct_manager = fields.Boolean(string='Is Direct Manager', readonly=True, compute='_get_current_user')

    @api.multi
    def action_request(self):
        if ((self.employee_id) and self.employee_id.parent_id) and self.employee_id.parent_id.work_email:
            email_from = get_email_from(self)
            if email_from:
                subject = ("HR letter request from employee  : %s ") % (self.employee_id.name)
                body = _("Hello,\n\n")
                body += _("<p>Employee %s sent HR letter request . Please take necessary steps..</p>") % (
                    self.employee_id.name)
                body += "--\n"
                mail_create(self, email_from, self.employee_id.parent_id.work_email, subject, body)
        return self.write({'state': 'request'})

    @api.multi
    def action_confirm(self):
        email_from = get_email_from(self)
        if self.employee_id.work_email:
            subject = ("Your HR letter request is confirmed")
            body = _("Hello,\n\n")
            body += _("Your HR letter request was confirmed.")
            body += "--\n"
            mail_create(self, email_from, self.employee_id.work_email, subject, body)
        return self.write({'state': 'confirm'})

    @api.multi
    def action_confirm_off(self):
        config = get_config(self)
        email_from = get_email_from(self)
        if email_from:
            if config:
                for manager in config.managers_ids:
                    subject = ("Leave request from Employee: '%s' ") % (self.employee_id.name)
                    body = _("Hello,\n\n")
                    body += _(
                        "Employee %s leave request was confirmed by officer, And its waiting for your approval,Please take necessary steps..") % (
                                self.employee_id.name)
                    body += "--\n"
                    if manager.work_email: mail_create(self, email_from, manager.work_email, subject, body)

            if self.employee_id.work_email:
                subject = ("Your leave request is waiting for HR Approval")
                body = _("Hello,\n\n")
                body += _("Your leave request was confirmed, And its waiting for HR Approval..")
                body += "--\n"
                mail_create(self, email_from, self.employee_id.work_email, subject, body)

        return self.write(
            {'state': 'off_confirm'})

    @api.multi
    def action_approve(self):

        email_from = get_email_from(self)
        if email_from:
            if ((self.employee_id) and self.employee_id.parent_id) and self.employee_id.parent_id.work_email:
                subject = ("HR letter was approved for employee : '%s' ") % (self.employee_id.name)
                body = _("Hello,\n\n")
                body += _("HR letter was approved for employee : '%s' by HR Manager") % (self.employee_id.name)
                body += "--\n"
                mail_create(self, email_from, self.employee_id.parent_id.work_email, subject, body)

            if (self.employee_id) and self.employee_id.work_email:
                subject = ("Your leave request was approved")
                body = _("Hello,\n\n")
                body += _("Your leave request was approved by HR Manager . Waiting for GM Approval")
                body += "--\n"
                mail_create(self, email_from, self.employee_id.work_email, subject, body)
        return self.write({'state': 'approve', 'hr_manager_id': self.env.uid, 'hr_manager_date': fields.date.today()})

    @api.multi
    def action_approve_gm(self):
        email_from = get_email_from(self)
        if email_from:
            if ((self.employee_id) and self.employee_id.parent_id) and self.employee_id.parent_id.work_email:
                subject = ("HR letter was approved for employee : '%s' ") % (self.employee_id.name)
                body = _("Hello,\n\n")
                body += _("HR letter was approved for employee : '%s' by GM Manager") % (self.employee_id.name)
                body += "--\n"
                mail_create(self, email_from, self.employee_id.parent_id.work_email, subject, body)

            if (self.employee_id) and self.employee_id.work_email:
                subject = ("Your leave request was approved")
                body = _("Hello,\n\n")
                body += _("Your leave request was approved by HR Manager . Happy Journey")
                body += "--\n"
                mail_create(self, email_from, self.employee_id.work_email, subject, body)

        return self.write(
            {'state': 'gm_approve', 'gm_manager_id': self.env.uid, 'gm_manager_date': fields.date.today()})

    @api.multi
    def action_refuse(self):
        email_from = get_email_from(self)
        state = ''
        if self.state == 'request':
            state = 'by Direct Manager'
        elif self.state == 'confirm':
            state = 'by HR Manager'
        if email_from:
            if self.employee_id.work_email:
                subject = ("Your leave request was refused")
                body = _("Hello,\n\n")
                body += _("Your leave request was refused %s") % (state)
                body += "--\n"
                mail_create(self, email_from, self.employee_id.work_email, subject, body)

            if ((self.employee_id) and self.employee_id.parent_id) and self.employee_id.parent_id.work_email \
                    and self.state == 'confirm':
                subject = ("HR letter was refused for employee : '%s' ") % (self.employee_id.name)
                body = _("Hello,\n\n")
                body += _("HR letter was refused for employee : '%s' %s") % (self.employee_id.name, state)
                body += "--\n"
                mail_create(self, email_from, self.employee_id.parent_id.work_email, subject, body)

        return self.write({'state': 'refuse', 'refused_by': self.env.uid, 'refused_date': fields.date.today()})

    @api.multi
    def print_report(self):
        self.ensure_one()
        return self.env.ref('hr_letter.action_report_hr_letter_english').report_action(self)

    @api.multi
    def print_report_arabic(self):
        self.ensure_one()
        return self.env.ref('hr_letter.action_report_hr_letter_arabic').report_action(self)

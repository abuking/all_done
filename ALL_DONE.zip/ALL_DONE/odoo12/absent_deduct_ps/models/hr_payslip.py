# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class HrEmployee(models.Model):
    _name = 'hr.employee'
    _inherit = 'hr.employee'


    @api.model
    def get_absent_hours(self, employee_id, date_from, date_to):
        absent_obj = self.env['absent.deduct.ps']
        absent_days = 0
        absent_ids = absent_obj.sudo().search([('employee_id','=',employee_id),
                                        ('state','=','approved'),
                                        ('absent_date','>=',date_from),
                                        ('absent_date','<=',date_to)])
        for absent in absent_ids:
            absent_days += absent.absent_deduct_hours
        return absent_days

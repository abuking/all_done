# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
try:
    from service_solutions.common_ps.models.nazar import mail_create, get_email_from, get_config
except:
    try:
        from odoo.common_ps.models.nazar import mail_create, get_email_from, get_config
    except:
        from addons.common_ps.models.nazar import mail_create, get_email_from, get_config

class absent_deduct_ps(models.Model):
    _name = 'absent.deduct.ps'
    _rec_name = "employee_id"
    _description = "Absent Deduct Hours"
    _inherit = ['mail.thread', 'resource.mixin']

    @api.one
    def _get_current_user(self):
        self.is_direct_manager = False
        if (
                self.employee_id and self.employee_id.parent_id and self.employee_id.parent_id.user_id) and self.employee_id.parent_id.user_id.id == self.env.uid:
            self.is_direct_manager = True

    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=False, )
    job_id = fields.Many2one(related="employee_id.job_id", comodel_name="hr.job", string="Job", required=False, )
    department_id = fields.Many2one(related="employee_id.department_id",comodel_name="hr.department",
                                    string="Department", required=False, )
    remarks = fields.Text(string="Remarks", required=False, )
    reasons = fields.Text(string="Reasons", required=False, )
    absent_deduct_hours = fields.Float(string="Absent Deduction Hours",  required=False, )
    state = fields.Selection(string="", selection=[('draft', 'Draft'), ('request', 'Request Sent'),
                                                   ('approved', 'Approved')], required=False, default="draft")
    is_direct_manager = fields.Boolean(string='Is Direct Manager', readonly=True, compute='_get_current_user')
    absent_date = fields.Date("Date", default=fields.Date.context_today)


    @api.multi
    def send_request(self):
        for case in self:
            if ((case.employee_id) and case.employee_id.parent_id) and case.employee_id.parent_id.work_email:
                email_from = get_email_from(self)
                if email_from:
                    subject = ("Absent Deduct Hours of Employee  : %s ") % (self.employee_id.name)
                    body = _("Hello,\n\n")
                    body += _("<p>Employee %s Absent Deduct Hours . Please take necessary steps..</p>") % (
                        self.employee_id.name)
                    body += "--\n"
                    mail_create(self, email_from, self.employee_id.parent_id.work_email, subject, body)
            case.write({'state':'request'})

    @api.multi
    def approve_request(self):
        for case in self:
            case.write({'state': 'approved'})




# -*- coding: utf-8 -*-
from odoo import http

# class AbsentDeductPs(http.Controller):
#     @http.route('/absent_deduct_ps/absent_deduct_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/absent_deduct_ps/absent_deduct_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('absent_deduct_ps.listing', {
#             'root': '/absent_deduct_ps/absent_deduct_ps',
#             'objects': http.request.env['absent_deduct_ps.absent_deduct_ps'].search([]),
#         })

#     @http.route('/absent_deduct_ps/absent_deduct_ps/objects/<model("absent_deduct_ps.absent_deduct_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('absent_deduct_ps.object', {
#             'object': obj
#         })
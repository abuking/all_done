# -*- coding: utf-8 -*-
{
    'name': "Absent Deduct Hours",

    'summary': """
        Module to track the Employee Absent Hours""",

    'description': """
        Salary Rule for Absent Deduct Hours:
        result = employee.get_absent_hours(payslip.employee_id, payslip.date_from, payslip.date_to)
    """,

    'author': "Mani, Pioneer Solutions",
    'website':"www.ps-sa.net",

    # any module necessary for this one to work correctly
    'depends': ['base','hr', 'common_ps','hr_payroll'],

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',



    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
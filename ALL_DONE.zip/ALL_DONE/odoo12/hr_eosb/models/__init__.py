# -*- coding: utf-8 -*-
from . import hr_payroll
from . import hr
from . import model
from . import res_config









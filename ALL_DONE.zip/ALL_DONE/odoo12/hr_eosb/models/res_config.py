# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import except_orm, Warning, RedirectWarning

class hr_accounting_config(models.TransientModel):
    _inherit = 'hr.accounting.config'

    eosb_eosb_journal_id = fields.Many2one('account.journal', string='EOSB Journal', help = "The journal used when the EOSB is done.")


    @api.model
    def get_default_values(self, fields):
        record_id = self.env['hr.accounting.config'].search([], limit=1, order='id desc')
        return {
            'eosb_eosb_journal_id': record_id.eosb_eosb_journal_id.id,

        }

    @api.one
    def set_values(self):
        self.eosb_eosb_journal_id = self.eosb_eosb_journal_id.id








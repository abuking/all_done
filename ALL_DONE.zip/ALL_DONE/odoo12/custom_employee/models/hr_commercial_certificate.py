from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class commercial_certificate_fig(models.Model):
    _name = 'commercial.certificate.fig'
    _description = 'Commercial Certificate'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    @api.depends('expiry_date')
    def _expiry_days(self):
        res = {}
        for case in self:
            if case.expiry_date:
                sdate = datetime.strptime(case.expiry_date, '%Y-%m-%d')
                edate = datetime.now()
                if sdate and edate:
                    tday = edate
                    sday = (sdate - tday).days
                    sday = sday + 1
                    case.expiry_days = sday
        return res

    company_id = fields.Many2one('res.company', "Company", required=True)
    id_no = fields.Char('ID Number', help="Enter ID Number.")
    classification_date = fields.Date('Classification Date', help="Enter Classification Date.")
    expiry_date = fields.Date('Expiry Date', help="Enter Expiry Date.", required=True)
    type = fields.Selection([('chamber', 'Chamber'), ('gosi', 'GOSI')
                                , ('zakat', 'Zakat'), ('municipality', 'Municipality')
                                , ('industrial_license', 'Industrial License'), ]
                            , string='Type', default="chamber", help='.', required=True)
    expiry_days = fields.Integer(compute='_expiry_days', string='Remaining Expiry Days', store=True)
    state = fields.Selection([('active', 'Active'),
                              ('expired', 'Expired')],
                             string='Status', default="active", readonly=True, track_visibility='onchange', help='.')

    def commercial_certificate_fig_expired(self):
        for case in self:
            case.write({'state' : 'expired'})

    @api.multi
    def button_print_commercial_certificate(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_commercial_certificate').report_action(self)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

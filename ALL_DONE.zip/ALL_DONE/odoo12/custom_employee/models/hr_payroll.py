from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime
from odoo.addons.custom_employee.models import hr_config_global as hg
import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree
import math
import time
from odoo.tools import float_compare, float_is_zero

class hr_payslip(models.Model):
    _inherit = "hr.payslip"

    ot_hour = fields.Integer('Over Time Hours', help="Specify if the Over Time Hours.", readonly=True,
        states={'draft': [('readonly', False)]})
    absent_days = fields.Float(string='Absent Days', help="Specify if the Absent Days.", readonly=True,
        states={'draft': [('readonly', False)]})

    # @api.multi
    # def get_absent_days(self):
    #     for case in self:
    #         employee = case.employee_id
    #         date_from = case.date_from
    #         date_to = case.date_to
    #         absent_days_amount = employee.absent_cal(employee.id, date_from, date_to)
    #         print ('absent_days_amount', absent_days_amount)
    #         case.absent_days_amount = absent_days_amount

    #overrideen
    @api.model
    def get_contract(self, employee, date_from, date_to):
        """
        @param employee: recordset of employee
        @param date_from: date field
        @param date_to: date field
        @return: returns the ids of all the contracts for the given employee that need to be considered for the given dates
        """
        # a contract is valid if it ends between the given dates
        clause_1 = ['&', ('date_end', '<=', date_to), ('date_end', '>=', date_from)]
        # OR if it starts between the given dates
        clause_2 = ['&', ('date_start', '<=', date_to), ('date_start', '>=', date_from)]
        # OR if it starts before the date_from and finish after the date_end (or never finish)
        clause_3 = ['&', ('date_start', '<=', date_from), '|', ('date_end', '=', False),
                    ('date_end', '>=', date_to)]
        clause_final = [('employee_id', '=', employee.id), ('state', 'in', ('draft','open')), '|',
                        '|'] + clause_1 + clause_2 + clause_3
        contract_ids = self.env['hr.contract'].search(clause_final)
        return contract_ids.ids

    #overrideen
    @api.multi
    def action_payslip_done(self):
        res = True#super(hr_payslip, self).action_payslip_done()
        precision = self.env['decimal.precision'].precision_get('Payroll')

        for slip in self:
            line_ids = []
            debit_sum = 0.0
            credit_sum = 0.0
            date = slip.date or slip.date_to

            name = _('Payslip of %s') % (slip.employee_id.name)
            move_dict = {
                'narration': name,
                'ref': slip.number,
                'journal_id': slip.journal_id.id,
                'date': date,
                'partner_id' : slip.employee_id.address_home_id.id,
            }
            for line in slip.details_by_salary_rule_category:
                amount = slip.credit_note and -line.total or line.total
                if float_is_zero(amount, precision_digits=precision):
                    continue
                debit_account_id = line.salary_rule_id.account_debit.id
                credit_account_id = line.salary_rule_id.account_credit.id

                if debit_account_id:
                    debit_line = (0, 0, {
                        'name': line.name,
                        'partner_id': line._get_partner_id(credit_account=False),
                        'account_id': debit_account_id,
                        'journal_id': slip.journal_id.id,
                        'date': date,
                        'debit': amount > 0.0 and amount or 0.0,
                        'credit': amount < 0.0 and -amount or 0.0,
                        'analytic_account_id': line.salary_rule_id.analytic_account_id.id
                                               or self.contract_id.analytic_account_id.id,
                        'tax_line_id': line.salary_rule_id.account_tax_id.id,
                    })
                    line_ids.append(debit_line)
                    debit_sum += debit_line[2]['debit'] - debit_line[2]['credit']

                if credit_account_id:
                    credit_line = (0, 0, {
                        'name': line.name,
                        'partner_id': line._get_partner_id(credit_account=True),
                        'account_id': credit_account_id,
                        'journal_id': slip.journal_id.id,
                        'date': date,
                        'debit': amount < 0.0 and -amount or 0.0,
                        'credit': amount > 0.0 and amount or 0.0,
                        'analytic_account_id': line.salary_rule_id.analytic_account_id.id
                                               or self.contract_id.analytic_account_id.id,
                        'tax_line_id': line.salary_rule_id.account_tax_id.id,
                    })
                    line_ids.append(credit_line)
                    credit_sum += credit_line[2]['credit'] - credit_line[2]['debit']

            if float_compare(credit_sum, debit_sum, precision_digits=precision) == -1:
                acc_id = slip.journal_id.default_credit_account_id.id
                if not acc_id:
                    raise UserError(_('The Expense Journal "%s" has not properly configured the Credit Account!') % (slip.journal_id.name))
                adjust_credit = (0, 0, {
                    'name': _('Adjustment Entry'),
                    'partner_id': False,
                    'account_id': acc_id,
                    'journal_id': slip.journal_id.id,
                    'date': date,
                    'debit': 0.0,
                    'credit': debit_sum - credit_sum,
                })
                line_ids.append(adjust_credit)

            elif float_compare(debit_sum, credit_sum, precision_digits=precision) == -1:
                acc_id = slip.journal_id.default_debit_account_id.id
                if not acc_id:
                    raise UserError(_('The Expense Journal "%s" has not properly configured the Debit Account!') % (slip.journal_id.name))
                adjust_debit = (0, 0, {
                    'name': _('Adjustment Entry'),
                    'partner_id': False,
                    'account_id': acc_id,
                    'journal_id': slip.journal_id.id,
                    'date': date,
                    'debit': credit_sum - debit_sum,
                    'credit': 0.0,
                })
                line_ids.append(adjust_debit)
            move_dict['line_ids'] = line_ids
            move = self.env['account.move'].create(move_dict)
            slip.write({'move_id': move.id, 'date': date})
            move.post()
        return res

    @api.multi
    def multi_action_payslip_done(self):
        context = dict(self._context or {})
        active_ids = context.get('active_ids',[])
        for active_id in active_ids:
            case = self.browse(active_id)
            if len(active_ids) > 50:
                raise UserError (_('You cannot confirm records higher than 50.'))
            if case.state != 'draft':
                raise UserError(_('You can confirm only draft records.'))
            case.action_payslip_done()

    @api.model
    def create(self, vals):
        context = dict(self._context or {})
        if 'journal_id' in context:
            if not context.get('journal_id'):
                del context['journal_id']
        res = super(hr_payslip, self.with_context(context)).create(vals)
        # post_id._check_for_publication(vals)
        return res

class hr_salary_rule(models.Model):
    _inherit = "hr.salary.rule"
    # used as hr_salary_rule.category_id,code
    # _columns = {
    #     'rule_type': fields.selection([('basic', 'Basic'),('gross', 'Gross'),('net','Net'),('hra','Housing Allowance'),('ma','Mobile Allowance'),('ta','Transport Allowance'),('food','Food Allowance'),('fuel','Fuel Allowance'),('ot','Over Time'),('creturn','Cash Return'),('perdiem','Per Diem'),('absent','Absent'),('loan','Loan'),('oncall','On Call Allowance'),('gas','Gasoline'),('seniority','seniority Reward'),('relocation','Relocation'),('traffic_accident','Traffic Accident'),('penalty','Penalty'),('advance','Advance'),('adjust','Adjust'),('other_allowance','Other Allowance'),('other_allowance_adjustment','Other Allowance Adjustment'),('other_deduction','Other Deduction'),('contracting_amount','Contracting Amount'),('gosi','GOSI'),('tuition','Tuition'),('work','Work Duty'),('major','Major'),('education','Education'),('hrdf','HRDF'),('sale','Sale')], 'Rule Type', track_visibility='onchange',help='Choose Rule Type for Salary Statement.'),

class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'

    journal_id = fields.Many2one(default=False, required=False)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

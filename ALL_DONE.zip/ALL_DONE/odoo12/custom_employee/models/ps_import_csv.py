# -*- coding: utf-8 -*-
##############################################################################
#
#    odoo, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
  
from odoo.exceptions import UserError, AccessError
from odoo.tools.translate import _
from odoo import api, fields, models
import logging
_logger = logging.getLogger(__name__)

class tr_bsp_reconcilation(models.TransientModel):
    _name = 'tr.bsp.reconcilation'

    bsp_xlsdata = fields.Binary('BSP-Excel File')
    
    
    @api.multi
    def process_bsp_data(self):     
        contract_obj = self.env["hr.contract"]
        employee_obj = self.env["hr.employee"]
        cr = self._cr
        for x in self:

            if not x.bsp_xlsdata:
                raise UserError(_('Please select the file'))
                return False
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #    Reading The XLS File
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            import csv
            import json
            import base64
            import tempfile
            dataFile = tempfile.mkstemp(".csv")[1]
            fp = open(dataFile, 'wb')
            fp.write(base64.b64decode(x.bsp_xlsdata))
            fp.close()
            f = open(dataFile, 'r')
            reader = csv.DictReader(f)
            out = json.dumps([row for row in reader])
            loop = 0
            for jd in json.loads(out):
                _logger.error(" ==> " + str(loop))
                loop = loop + 1
                #LEave
                emp_vals = {}
                pemployee_name = jd["employee_name"].replace("'", "")
                date_from = jd["date_from"]
                date_to = jd["date_to"]
                if not pemployee_name:
                    continue
                # employee_code = jd.get("emp_code")
                psql = """ select e.id, r.name as employee_name from hr_employee e
                                   left join resource_resource as r on r.id = e.resource_id
                                   where (r.name = '""" + str(pemployee_name) + """' or e.emp_code = '""" + str(pemployee_name) + """')"""
                cr.execute(psql)
                pemp_ids = [x for x in cr.dictfetchall()]
                pcompany_name = jd.get('company_name')
                cr.execute("select id from res_company where name = '" + pcompany_name + "'")
                company_ids = [c for c in cr.dictfetchall()]

                pemployee_job_name = jd.get('employee_job_name')
                cr.execute("select id from hr_job where name = '" + pemployee_job_name + "'")
                job_ids = [j for j in cr.dictfetchall()]
                if len(job_ids):
                    job_id = job_ids and job_ids[0]["id"]
                else:
                    job = self.env['hr.job'].create({'name' : pemployee_job_name})
                    job_id = job and job.id or False

                pleave_type_name = jd.get('leave_type_name')
                cr.execute("select id from hr_holidays_type_saudi where name = '" + pleave_type_name + "'")
                leavetype_ids = [j for j in cr.dictfetchall()]
                if len(leavetype_ids):
                    leavetype_id = leavetype_ids and leavetype_ids[0]["id"]
                else:
                    leavetype = self.env['hr.holidays.type.saudi'].create({'name': pleave_type_name, 'deduction_type' : 'full_paid'})
                    leavetype_id = leavetype and leavetype.id or False

                if len(pemp_ids) :
                    employee_id = pemp_ids[0]["id"]
                    employee = self.env['hr.employee'].browse(employee_id)
                    if employee.job_id.id != job_id:
                        employee.sudo().write({'job_id' : job_id})
                    emp_vals["employee_id"] = employee.id
                    emp_vals["contract_id"] = employee.contract_id.id
                    emp_vals['date_from'] = date_from
                    emp_vals['date_to'] = date_to
                    emp_vals["company_id"] = company_ids and company_ids[0]["id"]
                    emp_vals['leave_type_id'] = leavetype_id
                    self.env["hr.holidays.saudi"].create(emp_vals)
                elif pemployee_name == 'Moth Naim Hussein Waked':
                    employee = self.env['hr.employee'].search([('name' ,'=', "Mo'ath Naim Hussein Waked")])
                    if employee.job_id.id != job_id:
                        employee.sudo().write({'job_id' : job_id})
                    emp_vals["employee_id"] = employee.id
                    emp_vals["contract_id"] = employee.contract_id.id
                    emp_vals['date_from'] = date_from
                    emp_vals['date_to'] = date_to
                    emp_vals["company_id"] = company_ids and company_ids[0]["id"]
                    emp_vals['leave_type_id'] = leavetype_id
                    self.env["hr.holidays.saudi"].sudo().create(emp_vals)
                else:
                    _logger.error("Leave Saudi Error ==> " + str(pemployee_name))
                    emp_vals["employee_name"] = pemployee_name

            # print("jd", jd, type(jd['image']))
                # from PIL import Image, ImageFile
                # ImageFile.LOAD_TRUNCATED_IMAGES = True
                # contract_ref = jd.get("Contract Reference").replace("'","")
                # # employee_code = jd.get("emp_code")
                # # if not jd['id']:
                # #     continue
                # print ("employee_name",contract_ref)
                # sql  = """ select c.id from hr_contract c
                #                where (c.name = '""" + str(contract_ref) + """')"""
                # cr.execute(sql)
                # emp_ids = [x for x in cr.dictfetchall()]
                # if emp_ids:
                #     emp_list = ["Contract Reference"]#["position_classification/name"]#["address_id/name"]#["coach_id/namee"]#["parent_id/namee"] #["last_vacation_date"]
                #
                #     for idx, emp in enumerate(emp_ids):
                #         loop = loop + 1
                #         _logger.error("Contract Processing ==> " + str(loop) + " ,[" + str(contract_ref))
                #         emp = contract_obj.browse(emp['id'])
                #         emp_vals = {}
                #         for el in emp_list:
                #             if el == "Contract Reference":
                #                 pemployee_name = jd["Contract Reference"].replace("'", "")
                #                 if not pemployee_name:
                #                     continue
                #                 # employee_code = jd.get("emp_code")
                #                 psql = """ select e.id, r.name as employee_name from hr_employee e
                #                                    left join resource_resource as r on r.id = e.resource_id
                #                                    where (r.name = '""" + str(pemployee_name) + """' or e.emp_code = '""" + str(pemployee_name) + """')"""
                #                 cr.execute(psql)
                #                 pemp_ids = [x for x in cr.dictfetchall()]
                #                 if len(pemp_ids):
                #                     emp_vals["employee_id"] = pemp_ids[0]["id"]
                #                     emp_vals["employee_name"] = pemp_ids[0]["employee_name"]
                #                 else:
                #                     _logger.error("Contract Employee1 Error ==> " + str(pemployee_name))
                #                     emp_vals["employee_name"] = pemployee_name
                #         emp.write(emp_vals)
            # for jd in json.loads(out):
            #     print("jd", jd, type(jd['image']))
            #     from PIL import Image, ImageFile
            #     ImageFile.LOAD_TRUNCATED_IMAGES = True
            #     employee_name = jd.get("name").replace("'","")
            #     employee_code = jd.get("emp_code")
            #     if not jd['id']:
            #         continue
            #     print ("employee_name",employee_name)
            #     sql  = """ select e.id from hr_employee e
            #                    left join resource_resource as r on r.id = e.resource_id
            #                    where (e.emp_code = '""" + str(employee_code) + """'
            #                                 or r.name = '""" + str(employee_name) + """')"""
            #     cr.execute(sql)
            #     emp_ids = [x for x in cr.dictfetchall()]
            #     if emp_ids:
            #         emp_list = ["address_home_id/name"]#["position_classification/name"]#["address_id/name"]#["coach_id/namee"]#["parent_id/namee"] #["last_vacation_date"]
            #
            #         for idx, emp in enumerate(emp_ids):
            #             loop = loop + 1
            #             _logger.error("Employee Processing ==> " + str(loop) + " ,[" + str(employee_name + ' - ' + employee_code))
            #             emp = employee_obj.browse(emp['id'])
            #             emp_vals = {}
            #             for el in emp_list:
            #                 if el == "last_vacation_date":
            #                     if jd[el] != '':
            #                         emp_vals[el] = jd[el]
            #                 elif el == "parent_id/namee":
            #                     pemployee_name = jd["parent_id/namee"].replace("'", "")
            #                     if not pemployee_name:
            #                         continue
            #                     # employee_code = jd.get("emp_code")
            #                     psql = """ select e.id from hr_employee e
            #                                        left join resource_resource as r on r.id = e.resource_id
            #                                        where (r.name = '""" + str(pemployee_name) + """')"""
            #                     cr.execute(psql)
            #                     pemp_ids = [x for x in cr.dictfetchall()]
            #                     if len(pemp_ids):
            #                         emp_vals["parent_id"] = pemp_ids[0]["id"]
            #                     else:
            #                         _logger.error("Parent Employee Error ==> " + str(pemployee_name))
            #                         gtsgsdfgsdfgsd
            #                 elif el == "coach_id/namee":
            #                     pemployee_name = jd["coach_id/namee"].replace("'", "")
            #                     if not pemployee_name:
            #                         continue
            #                     # employee_code = jd.get("emp_code")
            #                     psql = """ select e.id from hr_employee e
            #                                        left join resource_resource as r on r.id = e.resource_id
            #                                        where (r.name = '""" + str(pemployee_name) + """')"""
            #                     cr.execute(psql)
            #                     pemp_ids = [x for x in cr.dictfetchall()]
            #                     if len(pemp_ids):
            #                         emp_vals["coach_id"] = pemp_ids[0]["id"]
            #                     else:
            #                         _logger.error("Coach Employee Error ==> " + str(pemployee_name))
            #                         gtsgsdfgsdfgsd
            #                 elif el == "address_id/name":
            #                     paddress_name = jd["address_id/name"].replace("'", "")
            #                     if not paddress_name:
            #                         continue
            #                     # employee_code = jd.get("emp_code")
            #                     psql = """ select p.id from res_partner p
            #                                        where (p.name = '""" + str(paddress_name) + """')"""
            #                     cr.execute(psql)
            #                     pemp_ids = [x for x in cr.dictfetchall()]
            #                     if len(pemp_ids):
            #                         emp_vals["address_id"] = pemp_ids[0]["id"]
            #                     else:
            #                         work_address = self.env["res.partner"].create({'name' : paddress_name, "comment" : "Bank Account Partner"})
            #                         emp_vals["address_id"] = work_address.id
            #                         _logger.error("Work Address Created ==> " + str(paddress_name))
            #                         # gtsgsdfgsdfgsd
            #
            #                 elif el == "position_classification/name":
            #                     position_classification_name = jd["position_classification/name"].replace("'", "")
            #                     if not position_classification_name:
            #                         continue
            #                     # employee_code = jd.get("emp_code")
            #                     psql = """ select p.id from hr_position_classifications p
            #                                        where (p.name = '""" + str(position_classification_name) + """')"""
            #                     cr.execute(psql)
            #                     pemp_ids = [x for x in cr.dictfetchall()]
            #                     if len(pemp_ids):
            #                         emp_vals["position_classification"] = pemp_ids[0]["id"]
            #                     else:
            #                         _logger.error("Work Address Created ==> " + str(position_classification_name) + str(position_classification_name.split(' - ')))
            #                         fassadadadsa
            #
            #                 elif el == "address_home_id/name":
            #                     paddress_name = jd["address_home_id/name"].replace("'", "")
            #                     if not paddress_name:
            #                         continue
            #                     # employee_code = jd.get("emp_code")
            #                     psql = """ select p.id from res_partner p
            #                                        where (p.name = '""" + str(paddress_name) + """')"""
            #                     cr.execute(psql)
            #                     pemp_ids = [x for x in cr.dictfetchall()]
            #                     if len(pemp_ids):
            #                         emp_vals["address_home_id"] = pemp_ids[0]["id"]
            #                     else:
            #                         work_address = self.env["res.partner"].create({'name' : paddress_name, "comment" : "Address Home Partner"})
            #                         emp_vals["address_home_id"] = work_address.id
            #                         _logger.error("Address Home Created ==> " + str(paddress_name))
            #                         # gtsgsdfgsdfgsd
            #                 else:
            #                     emp_vals[el] = jd[el]
            #             emp.write(emp_vals)
                        # for xd in emp.expiry_detail_ids:
                        #     if xd.type == 'iqama':
                        #         xd.update({"exp_id_no" : jd["iqama_id"]
                        #                   , "issue_date" : jd["iqama_idate"]
                        #                   , "expiry_date": jd["iqama_edate"]
                        #                   , "is_reminder" : jd["iqama_mail_sent"]
                        #                   , "issue_place": ""
                        #                   , "issue_by": ""
                        #                   , "note": ""
                        #                    })
                        #     if xd.type == 'license':
                        #         xd.update({"exp_id_no" : jd["license_id"]
                        #                   , "issue_date" : jd["license_idate"]
                        #                   , "expiry_date": jd["license_edate"]
                        #                   , "is_reminder" : jd["license_mail_sent"]
                        #                   , "issue_place": ""
                        #                   , "issue_by": ""
                        #                   , "note": ""
                        #                    })
                        #     if xd.type == 'medical':
                        #         xd.update({"exp_id_no" : jd["medical_id"]
                        #                   , "issue_date" : jd["medical_idate"]
                        #                   , "expiry_date": jd["medical_edate"]
                        #                   , "is_reminder" : jd["medical_mail_sent"]
                        #                   , "issue_place": ""
                        #                   , "issue_by": ""
                        #                   , "note": ""
                        #                    })
                        #     if xd.type == 'passport':
                        #         xd.update({"exp_id_no" : jd["passport_id"]
                        #                   , "issue_date" : jd["passport_idate"]
                        #                   , "expiry_date": jd["passport_edate"]
                        #                   , "is_reminder" : jd["passport_mail_sent"]
                        #                   , "issue_place": ""
                        #                   , "issue_by": ""
                        #                   , "note": ""
                        #                    })
                        #     if xd.type == 'visa':
                        #         xd.update({"exp_id_no" : jd["visa_id"]
                        #                   , "issue_date" : jd["visa_idate"]
                        #                   , "visa_type": jd["visa_type"]
                        #                   , "visa_exit_date": jd["visa_exit_date"]
                        #                   , "expiry_date": jd["visa_edate"]
                        #                   , "is_reminder" : jd["visa_mail_sent"]
                        #                   , "issue_place": ""
                        #                   , "issue_by": ""
                        #                   , "note": ""
                        #                    })
                # else:
                #     _logger.error("Employee Error ==> " + str(employee_name + ' - ' + employee_code))
                #     fsadasdasda
            return True
        














# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# -*- coding: utf-8 -*-

from . import hr_config_global
from . import hr_employee
from . import hr_contract
from . import hr_payroll
from . import hr_vacation_tickets
from . import hr_labour_office
from . import hr_transfer_company
from . import hr_employee_clearance
from . import hr_identification_letter
from . import hr_commercial_certificate
from . import hr_position_classifications
from . import hr_position_classifications_grade
from . import hr_position_classifications_category
from . import hr_position_classifications_position_level
from . import hr_business_travel
from . import hr_duty_commencement
from . import pss_res_partner
# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.tools.translate import _
from odoo.exceptions import UserError
import time
import re
from odoo.tools import float_compare, float_is_zero

EXPIRY_TYPE = [('iqama', 'Iqama / National ID'), ('license', 'License'), ('passport', 'Passport'),
                             ('visa', 'Visa'), ('work_permit', 'Work Permit'), ('medical_insurance', 'Meical Insurance'),
                             ('other', 'Others')]
def get_email_from(self):
    UID_ROOT = 1
    email_from = self.env['res.users'].sudo().browse(UID_ROOT).login
    mail_server_ids = self.env['ir.mail_server'].sudo().search([('smtp_user','!=',False)])
    if mail_server_ids:
        email_from = self.env['ir.mail_server'].sudo().browse(mail_server_ids[0].id).smtp_user
    return email_from

def button_send_mail(self, email_to, subject, body_html):
    main_content = {
        'subject': subject,
        'author_id': self.env.user.partner_id.id,
        'body_html': body_html,
        'email_to': email_to,
    }
    self.env['mail.mail'].create(main_content).send()

def get_url(self, model):
    cr = self._cr
    base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
    database_name = cr.dbname
    object_ids = self.search([],limit=1)
    object_id = object_ids and object_ids.id or False
    url = ''
    if object_id:
        url = '%s/?db=%s#id=%s&view_type=form&model=hr.employee.loan.ps&menu_id=&action=' % (base_url, database_name, object_id)
    return url
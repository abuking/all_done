from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree

class transfer_company_fig(models.Model):
    _name = 'transfer.company.fig'
    _description = 'Transfer Company'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    name = fields.Char(related='employee_id.name', string='Employee Name')
    transfer_date = fields.Date('Transfer Date', help="Enter Transfer Date.")
    transfer_type = fields.Selection([('permanent', 'Permanent'), ('temporary', 'Temporary'), ], 'Transfer Type',
                                     track_visibility='onchange', help='Specify Transfer Type.')
    initial = fields.Date('Initial', help=".")
    reason = fields.Text('Transfer Reason', help="Enter Transfer Reason.")
    from_company_id = fields.Many2one('res.company', "From Company", required=True)
    to_company_id = fields.Many2one('res.company', "To Company", required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('refuse', 'Cancel'),
    ], default="draft",
        string='Status', readonly=True, track_visibility='onchange',
        help='.')

    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            if employee:
                case.name = employee.name  or False
                case.gender = employee.gender and employee.gender or False
                case.from_company_id = employee.company_id and employee.company_id.id or False

    @api.multi
    def transfer_company_fig_confirm(self):
        for case in self:
            employee = case.employee_id
            to_company_id = case.to_company_id.id
            employee.write({'company_id' : to_company_id})
            case.write({'state': 'confirm'})
        return True









# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

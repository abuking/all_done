from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class hr_position_classifications(models.Model):
    _name = 'hr.position.classifications'
    _description = 'Position Classifications'

    @api.depends('pcg_id','pcc_id','pcpl_id')
    def _nameconcate(self):
        res= {}
        for record in self:
            pcg_id = ''
            pcc_id = ''
            pcpl_id = ''
            name = ''
            if record.pcg_id:
                pcg_id = record.pcg_id.name
            if record.pcc_id:
                pcc_id = record.pcc_id.name
            if record.pcpl_id:
                pcpl_id = record.pcpl_id.name
            record.name = (pcg_id and pcg_id + ' - ' or '') + (pcc_id and pcc_id + ' - ' or '') + (pcpl_id and pcpl_id or '')
        return res

    name = fields.Char(compute='_nameconcate', string='Name', store=True)
    pcg_id = fields.Many2one('hr.position.classifications.grade', 'Grade')
    pcc_id = fields.Many2one('hr.position.classifications.category', 'Category')
    pcpl_id = fields.Many2one('hr.position.classifications.position.level', 'Position Level')

    _sql_constraints = [('unique_name', 'unique(name)', 'A record with the same name already exists.')]









# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

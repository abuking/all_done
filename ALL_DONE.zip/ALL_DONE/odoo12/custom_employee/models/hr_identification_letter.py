from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class identification_letter_fig(models.Model):
    _name = 'identification.letter.fig'
    _description = 'Identification Letter'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    namee = fields.Char('Employee Name', )
    job_id = fields.Many2one('hr.job', "Job", )
    department_id = fields.Many2one('hr.department', "Department", )
    company_id = fields.Many2one('res.company', "Company", )
    starting_date = fields.Date('Starting Date', help="Enter Starting Date.", default=fields.Date.context_today)
    country_id = fields.Many2one('res.country', "Nationality", )
    expiry_detail_ids = fields.Many2many('hr.expiry.details', string='Expiry Details',
                                        )

    purpose_of_letter = fields.Char('Purpose of Letter', )
    directed_to = fields.Many2one('hr.employee', "Directed To")
    language = fields.Selection([('english', 'English'), ('arabic', 'Arabic')], 'Language', track_visibility='onchange',
                                help='Specify Language.')
    attested_by_chamber = fields.Selection([('yes', 'Yes'), ('no', 'No')], 'Attested by Chamber',
                                           track_visibility='onchange', help='Specify Language.')
    date = fields.Date('Date', help="Enter Date.")

    state= fields.Selection([
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
        ], default='draft',
        string='Status', readonly=True, track_visibility='onchange',
        help='.')

    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            if employee:
                case.namee = employee.name or ''
                case.work_location = employee.work_location and employee.work_location or ''
                case.job_id = employee.job_id and employee.job_id.id or False
                case.department_id = employee.department_id and employee.department_id.id or False
                case.company_id = employee.company_id and employee.company_id.id or False
                case.expiry_detail_ids = [
                    (6, 0, [x.id for x in employee.expiry_detail_ids if x.type in ('iqama', 'passport')])]

    @api.multi
    def identification_letter_fig_approved(self):
        self.write({'state': 'approved'})
        return True

    @api.multi
    def identification_letter_fig_refused(self):
        self.write({'state': 'refused'})
        return True


    @api.multi
    def button_print_identification_letter(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_identification_letter').report_action(self)








# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

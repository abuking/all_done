from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class employee_clearance_fig(models.Model):
    _name = 'employee.clearance.fig'
    _description = 'Employee Clearance'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    job_id = fields.Many2one('hr.job', "Job", )
    department_id = fields.Many2one('hr.department', "Department", )
    company_id = fields.Many2one('res.company', "Company", )
    work_stop_date = fields.Date('Work Stop Date', help="Enter Work Stop Date.", default=fields.Date.context_today)
    namee = fields.Char('Employee Name', )
    clearance_type = fields.Selection([('leave', 'Leave'), ('final', 'Final'), ('transfer', 'Transfer')],
                                      'Clearance Type',
                                      track_visibility='onchange', help='Specify Clearance Type.')

    employee_tasks = fields.Selection([('received', 'Received'), ('replaced', 'Replaced')], 'Employee Tasks',
                                      track_visibility='onchange', help='Specify Employee Tasks.',
                                      )
    tools_obligations = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Tools and Obligations',
                                         track_visibility='onchange', help='Specify Tools and Obligations.',
                                         )
    data_confidential_doc = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Data / Confidential Doc',
                                             track_visibility='onchange', help='Specify Data / Confidential Doc.',
                                             )
    dm_date = fields.Date('Date', help="Enter Date.", )

    internal_loans = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Internal Loans',
                                      track_visibility='onchange', help='Specify Internal Loans.',
                                      write=['account.group_account_manager'])
    bank_loans = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Bank Loans', track_visibility='onchange',
                                  help='Specify Bank Loans.', write=['account.group_account_manager'])
    deduction = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Deduction', track_visibility='onchange',
                                 help='Specify Deduction.', write=['account.group_account_manager'])
    fd_date = fields.Date('Date', help="Enter Date.", write=['account.group_account_manager'])

    computer_laptop = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Computer / Laptop',
                                       track_visibility='onchange', help='Specify Computer / Laptop.',
                                       write=['base.group_it_manager_fig'])
    email_password = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Email / Password',
                                      track_visibility='onchange', help='Specify Email / Password.',
                                      write=['base.group_it_manager_fig'])
    mobile = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Mobile', track_visibility='onchange',
                              help='Specify Mobile.', write=['base.group_it_manager_fig'])
    it_date = fields.Date('Date', help="Enter Date.", write=['base.group_it_manager_fig'])

    final_waivar = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Final Waivar',
                                    track_visibility='onchange', help='Specify Final Waivar.',
                                    write=['base.group_hr_manager'])
    word_id = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Word ID', track_visibility='onchange',
                               help='Specify Work ID.', write=['base.group_hr_manager'])
    medical_insurance = fields.Selection([('received', 'Received'), ('na', 'N/A')], 'Medical Insurance',
                                         track_visibility='onchange', help='Specify Medical Insurance.',
                                         write=['base.group_hr_manager'])
    hr_date = fields.Date('Date', help="Enter Date.", write=['base.group_hr_manager'])

    dm_note = fields.Text('Comments', help="Enter Comments.", )
    fd_note = fields.Text('Comments', help="Enter Comments.", write=['account.group_account_manager'])
    it_note = fields.Text('Comments', help="Enter Comments.", write=['base.group_it_manager_fig'])
    hr_note = fields.Text('Comments', help="Enter Comments.", write=['base.group_hr_manager'])

    approval_count = fields.Integer('Approval Count')
    approval_dm = fields.Boolean('Approval DM')
    approval_fd = fields.Boolean('Approval FD')
    approval_it = fields.Boolean('Approval IT')
    approval_hr = fields.Boolean('Approval HR')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('waiting_4_4', 'Waiting Approval 4/4'),
        ('waiting_3_4', 'Waiting Approval 3/4'),
        ('waiting_2_4', 'Waiting Approval 2/4'),
        ('waiting_1_4', 'Waiting Approval 1/4'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
    ],
        string='Status', default="draft", readonly=True, track_visibility='onchange',
        help='.')

    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            if employee:
                case.namee = employee.name or ''
                case.work_location = employee.work_location and employee.work_location or ''
                case.job_id = employee.job_id and employee.job_id.id or False
                case.department_id = employee.department_id and employee.department_id.id or False
                case.company_id = employee.company_id and employee.company_id.id or False

    def employee_clearance_fig_confirm(self):
        for case in self:
            case.write({'state': 'waiting_4_4'})
        return True

    def employee_clearance_fig_approve(self):
        context = dict(self._context or {})
        for case in self:
            approval_count = case.approval_count
            if approval_count == 0:
                case.write({'state': 'waiting_3_4'})
                case.write({'approval_count': 1})
            elif approval_count == 1:
                case.write({'state': 'waiting_2_4'})
                case.write({'approval_count': 2})
            elif approval_count == 2:
                case.write({'state': 'waiting_1_4'})
                case.write({'approval_count': 3})
            elif approval_count == 3:
                case.write({'state': 'approved'})
                case.write({'approval_count': 4})
            approve_button = context['approve_button']
            if approve_button == 'dm':
                case.write({'approval_dm': True})
            elif approve_button == 'fd':
                case.write({'approval_fd': True})
            elif approve_button == 'it':
                case.write({'approval_it': True})
            elif approve_button == 'hr':
                case.write({'approval_hr': True})

    def employee_clearance_fig_refused(self):
        for case in self:
            case.write({'state': 'refused'})
        return True

    @api.multi
    def button_print_employee_clearance(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_employee_clearance').report_action(self)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

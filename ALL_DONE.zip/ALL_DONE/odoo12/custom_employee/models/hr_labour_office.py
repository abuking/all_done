from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class labour_office_fig(models.Model):
    _name = 'labour.office.fig'
    _description = 'Labour Office'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    labour_office_no = fields.Char('Labour Office Number', help="Enter Labour Office Number.")
    country_id = fields.Many2one('res.country', "Nationality")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], 'Gender', track_visibility='onchange',
                              help='Specify Gender of Employee.')
    job_type = fields.Selection([('temporary', 'Temporary'), ('permanent', 'Permanent'), ], 'Job Type',
                                track_visibility='onchange', help='Specify Job Type of Employee.')
    job_id = fields.Many2one('hr.job', 'Job')
    education_status = fields.Selection([('pursuing', 'Pursuing'), ('completed', 'Completed'), ], 'Educational Status',
                                        track_visibility='onchange', help='Specify Educational Status of Employee.')
    qualification = fields.Char('Qualification')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('refuse', 'Cancel')],
        'Status', readonly=True, track_visibility='onchange',
        help='.')


    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            if employee:
                case.job_id = employee.job_id and employee.job_id.id or False
                case.gender = employee.gender and employee.gender or False
                case.country_id = employee.country_id and employee.country_id.id or False

    @api.multi
    def button_print_labour_office(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_labour_office').report_action(self)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

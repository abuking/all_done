from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class hr_position_classifications_category(models.Model):
    _name = 'hr.position.classifications.category'
    _description = 'Position Classifications category'

    name = fields.Char(string='Name', help='Name of the Position Classifications category Name.', required=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

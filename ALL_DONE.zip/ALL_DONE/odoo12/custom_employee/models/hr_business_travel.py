from odoo import models, fields, api, tools, _
from odoo.exceptions import UserError
from datetime import datetime
from odoo.addons.custom_employee.models import hr_config_global as hg
import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree
import math


class business_travel_fig(models.Model):
    _name = 'business.travel.fig'
    _description = 'Business Travel'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    name = fields.Char(related='employee_id.namea', string='Employee Name')
    job_id = fields.Many2one('hr.job', "Job", )
    department_id = fields.Many2one('hr.department', "Department", )
    company_id = fields.Many2one('res.company', "Company", )
    request_date = fields.Date('Request Date', help="Enter Request Date.", default=fields.Date.today)
    work_location = fields.Char('Location', )
    assignment_type = fields.Selection([('business', 'Business')
                                           , ('project', 'Temporary Project Assignment'), ],
                                       'Assignment Type', track_visibility='onchange',
                                       help='Specify Assignment Type.')
    purpose = fields.Text('Purpose of Business/Project Assignment',
                          help="Enter Purpose of Business/Project Assignment.")
    country_id = fields.Many2one('res.country', "Country", )
    city = fields.Char('City', )
    start_date = fields.Date('Start Date', help="Enter Start Date.")
    end_date = fields.Date('End Date', help="Enter End Date.")
    no_days = fields.Integer('No of days')
    country_visa_required = fields.Selection([('yes', 'Yes'), ('no', 'No'), ], 'Country VISA Required',
                                             track_visibility='onchange',
                                             help='Specify Country VISA Required or Not.')
    exit_reentry_visa_required = fields.Selection([('yes', 'Yes'), ('no', 'No'), ],
                                                  'Exit - Re Entry VISA Required', track_visibility='onchange',
                                                  help='Specify Exit / Re-Entry VISA Required.')
    contact = fields.Char('Contact at Business Assignment', )
    travel_time = fields.Integer('Travel Time (Days)', )
    perdiem = fields.Float('Total Per Diem Allowable', )
    pay_type = fields.Selection([('advance', 'Advance'), ('upon_return', 'Upon Return'), ], 'Pay Type',
                                track_visibility='onchange', help='Specify Pay Type.',
                                )
    ticket_class = fields.Char('Class of Airline Ticket', )
    ticket_cost = fields.Selection([('cash', 'Cash'), ('reservation_by_company', 'Reservation by Company'), ],
                                   'Ticket Cost', track_visibility='onchange', help='Choose Ticket Cost',
                                   )
    state = fields.Selection([
        ('draft', 'Draft'),
        ('request', 'Waiting for Direct Manager approval'),
        ('progress', 'Waiting for HR Manager approval'),
        ('progress2', 'Waiting for finance Manager approval'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
    ],
        'Status', readonly=True, track_visibility='onchange', default="draft",
        help='.')

    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            if employee:
                case.name = employee.name or ''
                case.work_location = employee.work_location and employee.work_location or ''
                case.job_id = employee.job_id and employee.job_id.id or False
                case.department_id = employee.department_id and employee.department_id.id or False
                case.company_id = employee.company_id and employee.company_id.id or False
    
    @api.onchange('start_date','end_date')
    @api.multi
    def on_change_sedate(self):
        for case in self:
            end_date = case.start_date
            start_date = case.end_date
            no_days = 0
            """Returns a float equals to the timedelta between two dates given as string."""
            if (end_date and start_date) and (start_date <= end_date):
                DATETIME_FORMAT = "%Y-%m-%d"
                from_dt = datetime.strptime(start_date, DATETIME_FORMAT)
                to_dt = datetime.strptime(end_date, DATETIME_FORMAT)
                timedelta = to_dt - from_dt
                diff_day = timedelta.days + float(timedelta.seconds) / 86400
                no_days = round(math.floor(diff_day)) + 1
            case.no_days = no_days

    @api.multi
    def business_travel_fig_request(self):
        for case in self:
            url = hg.get_url(self, 'business.travel.fig')
            email_to = False
            if case.employee_id.parent_id:
                if case.employee_id.parent_id.work_email:
                    email_to = case.employee_id.parent_id.work_email
            if email_to:
                subject = ('Business Travel request from Employee: "%s"') % case.employee_id.name
                body = _(
                    "Employee %s sent request for Business Travel, Please do necessary steps.\n\n<p>Access your messages and personal documents through <a href='%s'>Openerp</a></p>") % (
                              case.employee_id.name, url)
                hg.button_send_mail(self,email_to, subject, body)
            case.write({'state': 'request'})

    @api.multi
    def business_travel_fig_progress(self):
        for case in self:
            url = hg.get_url(self, 'business.travel.fig')
            email_to = False
            if case.employee_id:
                if case.employee_id.work_email:
                    email_to = case.employee_id.work_email
            if email_to:
                subject = ('Your Business Travel request approved by direct manager')
                body = _(
                    "Your Business Travel request was approved by your direct manager.And its waiting for HR manager approval.\n\n<p>Access your messages and personal documents through <a href='%s'>Openerp</a></p>") % (
                              url)
                hg.button_send_mail(self, email_to, subject, body)

            email_to = False
            if email_to:
                subject = ('Business Travel Request from Employee: "%s"') % case.employee_id.name
                body = _(
                    "Employee %s sent request for Business Travel, Please do necessary steps.\n\n<p>Access your messages and personal documents through <a href='%s'>Openerp</a></p>") % (
                              case.employee_id.name, url)
                hg.button_send_mail(self, email_to, subject, body)
            case.write({'state': 'progress'})

    @api.multi
    def business_travel_fig_progress2(self):
        for case in self:
            url = hg.get_url('business.travel.fig')
            email_to = False
            mgr_ids = self.pool.get('hr.config.settings').search()
            if mgr_ids:
                for r in mgr_ids:
                    email_to = self.pool.get('hr.config.settings').browse(r).finance_manager_id.work_email
            if email_to:
                subject = ('Business Travel Request from Employee: "%s"') % case.employee_id.name
                body = _(
                    "Employee %s sent request for Business Travel, Please do necessary steps.\n\n<p>Access your messages and personal documents through <a href='%s'>Openerp</a></p>") % (
                              case.employee_id.name, url)
                hg.button_send_mail(self, email_to, subject, body)
            case.write({'state': 'progress2'})

    @api.multi
    def business_travel_fig_approved(self):
        for case in self:
            case.write({'state': 'approved'})

    @api.multi
    def business_travel_fig_back2progress2(self):
        for case in self:
            self.write({'state': 'progress'})

    @api.multi
    def business_travel_fig_refused(self):
        for case in self:
            url = hg.get_url(self, 'business.travel.fig')
            email_to = False
            if case.state == 'request':
                if case.employee_id:
                    if case.employee_id.work_email:
                        email_to = case.employee_id.work_email
                        subject = ('Your Business Travel request refused by direct manager')
                        body = _(
                            "Your Business Travel request was refused by your direct manager.\n\n<p>Access your messages and personal documents through <a href='%s'>Openerp</a></p>") % (
                                      url)
            elif case.state == 'progress':
                if case.employee_id.parent_id:
                    if case.employee_id.parent_id.work_email:
                        email_to = case.employee_id.parent_id.work_email
                        subject = ('Employee %s Business Travel request refused by HR manager') % (
                        case.employee_id.name)
                        body = _(
                            "Employee %s Business Travel request was refused by your HR manager.\n\n<p>Access your messages and personal documents through <a href='%s'>Openerp</a></p>") % (
                                      case.employee_id.name, url)

            if email_to:
                hg.button_send_mail(self, email_to, subject, body)
            case.write({'state': 'refused'})

    def unlink(self):
        for rec in self:
            if rec.state != 'approve':
                raise UserError(_('You Cannot delete Employee bussiness travel where state not in draft'))
        return super(business_travel_fig, self).unlink()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

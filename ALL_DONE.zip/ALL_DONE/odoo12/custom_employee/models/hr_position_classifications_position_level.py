from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class hr_position_classifications_position_level(models.Model):
    _name = 'hr.position.classifications.position.level'
    _description = 'Position Classifications Position Level'

    name = fields.Char(string='Name',
                       help='Name of the Position Classifications Position Level Name.',
                       required=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

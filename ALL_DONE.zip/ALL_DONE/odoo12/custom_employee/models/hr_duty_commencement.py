from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree


class work_commencement_fig(models.Model):
    _name = 'work.commencement.fig'
    _description = 'Work Commencement'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    job_id = fields.Many2one('hr.job', "Job", )
    department_id = fields.Many2one('hr.department', "Department", )
    company_id = fields.Many2one('res.company', "Company", )
    commencement_date = fields.Date('Commencement Date', help="Enter Commencement Date.", default=fields.Date.today)
    namee = fields.Char('Name', )
    basic = fields.Float('Basic', help="Specify if the Basic.")
    housing = fields.Float('Housing', help="Specify if the Housing.")
    transportation = fields.Float('Transportation', help="Specify if the Transportation.")
    mobile = fields.Float('Mobile', help="Specify if the Mobile.")
    tuition = fields.Float('Tuition', help="Specify if the Tuition.")
    other = fields.Float('Others', help="Specify if the Other.")
    adult_tickets = fields.Integer('Adult Tickets', help="Enter the Number of Adult Tickets.")
    child_tickets = fields.Integer('Child Tickets', help="Enter the Number of Child Tickets.")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
    ],
        'Status', readonly=True, track_visibility='onchange', default="draft",
        help='.')

    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            con_ids = self.env['hr.contract'].search([('employee_id', '=', employee.id)])
            wage, housing, transportation, other = 0, 0, 0, 0
            if con_ids:
                con_id = con_ids and con_ids[0]
                if con_id:
                    wage = con_id.wage
                    housing = con_id.housing
                    transportation = con_id.transportation
                    other = con_id.other
            case.basic = wage
            case.housing = housing
            case.transportation = transportation
            case.other = other
            if employee:
                case.namee = employee.name
                case.commencement_date = employee.aj_date or ''
                case.job_id = employee.job_id and employee.job_id.id or False
                case.department_id = employee.department_id and employee.department_id.id or False
                case.company_id = employee.company_id and employee.company_id.id or False
    #
    def work_commencement_fig_approved(self):
        self.write({'state': 'approved'})
        return True
    #
    def work_commencement_fig_refused(self):
        self.write({'state': 'refused'})
        return True

    @api.multi
    def button_print_work_commencement(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_work_commencement').report_action(self)

class commencement_after_vacation_fig(models.Model):
    _name = 'commencement.after.vacation.fig'
    _description = 'Commencement After Vacation'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', "Employee", required=True)
    job_id = fields.Many2one('hr.job', "Job", )
    department_id = fields.Many2one('hr.department', "Department", )
    company_id = fields.Many2one('res.company', "Company", )
    commencement_date = fields.Date('Commencement Date', help="Enter Commencement Date.", default=fields.Date.today)
    leave_start_date = fields.Date('Leave Starting Date', help="Enter Leave Starting Date.")
    namee = fields.Char('Name', )
    commencement_details = fields.Selection(
        [('private', 'Private'), ('emergency', 'Emergency'), ('sick', 'Sick'), ('annual', 'Annual'), ],
        'Commencement Details', track_visibility='onchange', help='Specify Commencement Details.')
    leave_duration = fields.Selection([('annual', 'Annual'), ('unpaid', 'Unpaid'), ], 'Leave Duration',
                                      track_visibility='onchange', help='Specify Leave Duration.')
    leave_exceed = fields.Selection([('exceeded', 'Exceeded'), ('notexceeded', 'Not Exceeded'), ], 'Leave Exceed',
                                    track_visibility='onchange', help='Specify Leave Exceed.')
    exceeding_days = fields.Integer('Exceeding Days', )
    exceeding_proce = fields.Selection(
        [('noaction', 'No Action'), ('warning', 'Warning'), ('deductsalary', 'Deduct from Salary'),
         ('deductnextleave', 'Deduct from Next Leave'), ], 'Exceeding / Process', track_visibility='onchange',
        help='Specify Exceeding / Proce.')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('refused', 'Refused'),
    ],
        'Status', readonly=True, track_visibility='onchange', default='draft',
        help='.')


    @api.onchange('employee_id')
    @api.multi
    def onchange_employee_id(self):
        for case in self:
            employee = case.employee_id
            if employee:
                case.namee = employee.name
                case.job_id = employee.job_id and employee.job_id.id or False
                case.department_id = employee.department_id and employee.department_id.id or False
                case.company_id = employee.company_id and employee.company_id.id or False
    #
    def commencement_after_vacation_fig_approved(self):
        self.write({'state': 'approved'})
        return True
    #
    def commencement_after_vacation_fig_refused(self):
        self.write({'state': 'refused'})
        return True

    @api.multi
    def button_print_commencement_after_vacation(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_commencement_after_vacation').report_action(self)









# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime

import odoo.addons.decimal_precision as dp
from odoo.exceptions import except_orm, Warning, RedirectWarning
from lxml import etree

class vacation_tickets(models.Model):
    _name = 'vacation.tickets'
    _description = 'Vacation Tickets'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    city = fields.Char(string='City', help="Enter City Name.")
    normal_price = fields.Float(string='Normal Price')
    low_price = fields.Float(string='Low Price')
    ticket_period = fields.Selection([('30', '30'), ('60', '60')], string='Ticket Period'
                                     , track_visibility='onchange', default="30"
                                     , help='Specify Ticket Period of Employee.', required=True)
    last_receive_date = fields.Date(string='Last Receive Date')
    ticket_eligibility = fields.Boolean(string='Family Ticket Eligibility')
    visa = fields.Selection([('exit', 'Exit'), ('vacation', 'Vacation'), ], string='Visa',
                            track_visibility='onchange',
                            help='Choose VISA.')
    visa_type = fields.Selection([('single', 'Single'), ('multiple', 'Multiple'), ], string='Visa Type',
                                 track_visibility='onchange', help='Choose VISA Type.')
    state = fields.Selection([('draft', 'Draft'),
                              ('confirm', 'Confirm'),
                              ('refuse', 'Cancel'),
                              ], string='Status', readonly=True, track_visibility='onchange', help='.')


    @api.multi
    def button_print_vacation_tickets(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('custom_employee.hr_report_action_template_vacation_tickets').report_action(self)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

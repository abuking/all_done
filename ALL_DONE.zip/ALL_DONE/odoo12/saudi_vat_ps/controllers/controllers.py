# -*- coding: utf-8 -*-
from odoo import http

# class SaudiVatPs(http.Controller):
#     @http.route('/saudi_vat_ps/saudi_vat_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/saudi_vat_ps/saudi_vat_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('saudi_vat_ps.listing', {
#             'root': '/saudi_vat_ps/saudi_vat_ps',
#             'objects': http.request.env['saudi_vat_ps.saudi_vat_ps'].search([]),
#         })

#     @http.route('/saudi_vat_ps/saudi_vat_ps/objects/<model("saudi_vat_ps.saudi_vat_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('saudi_vat_ps.object', {
#             'object': obj
#         })
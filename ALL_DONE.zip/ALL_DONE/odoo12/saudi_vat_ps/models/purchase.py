# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError

class PurchaseOrder(models.Model):
    _name = 'purchase.order'
    _inherit = 'purchase.order'

    project_id = fields.Many2one('project.project', string='Project', readonly=False)


    @api.model
    def create(self, vals):
        result = super(PurchaseOrder, self).create(vals)
        result.check_po()
        return result

    @api.multi
    def write(self, vals):
        result = super(PurchaseOrder, self).write(vals)
        for case in self:
            case.check_po()
        return result


    def check_po(self):
        if self.project_id :
            purchases = self.search([('project_id','=',self.project_id.id)])
            po_amount = sum([p.amount_total for p in purchases])
            if po_amount > self.project_id.po_limit:
                raise UserError(_('Purchase Order Limit exceeds for the project'))


# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class ProjectProject(models.Model):
    _name = 'project.project'
    _inherit = 'project.project'

    po_limit = fields.Float('PO Limit')

# -*- coding: utf-8 -*-
{
    'name': "Saudi VAT",

    'summary': """
        VAT customisation for Saudi. """,

    'description': """
        VAT customisation for Saudi.
    """,

    'author': "Mani,Pioneer Solutions",
    'website': "www.ps-sa.net",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '11.0',

    # any module necessary for this one to work correctly
    'depends': ['base','sale','purchase','account','project'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/sale_view.xml',
        'views/purchase_view.xml',
        'views/project.xml',
        'views/account_view.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
# -*- coding: utf-8 -*-

from odoo import models, fields, api

# class product_reports_ps(models.Model):
#     _name = 'product_reports_ps.product_reports_ps'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100
# -*- coding: utf-8 -*-
from odoo import http

# class ProductReportsPs(http.Controller):
#     @http.route('/product_reports_ps/product_reports_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/product_reports_ps/product_reports_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('product_reports_ps.listing', {
#             'root': '/product_reports_ps/product_reports_ps',
#             'objects': http.request.env['product_reports_ps.product_reports_ps'].search([]),
#         })

#     @http.route('/product_reports_ps/product_reports_ps/objects/<model("product_reports_ps.product_reports_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('product_reports_ps.object', {
#             'object': obj
#         })
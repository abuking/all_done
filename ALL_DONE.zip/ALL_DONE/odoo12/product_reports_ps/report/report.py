# -*- coding: utf-8 -*-
# Copyright (c) 2015-Present TidyWay Software Solution. (<https://tidyway.in/>)

import pytz
from odoo import models, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime
from odoo.exceptions import UserError


class ReportMostSellingProducts(models.AbstractModel):
    _name = 'report.product_reports_ps.ps_most_selling_product'

    @api.model
    def _get_report_values(self, docids, data=None):
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        clause = []
        sales_records = []
        return {
            'doc_ids': self.ids,
            'doc_model': self.model,
            'docs': docs,
            'data': data,
            'get_company': self._get_company,
            'get_product_name': self._product_name,
            'get_lines': self._get_lines,

        }

    '''
    @api.model
    def render_html(self, docids, data=None):
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('product_reports_ps.ps_most_selling_product')
        self.begining_qty = 0.0
        self.total_in = 0.0
        self.total_out = 0.0
        self.total_int = 0.0
        self.total_adj = 0.0
        self.total_begin = 0.0
        self.total_end = 0.0
        self.total_inventory = []
        self.value_exist = {}
        docargs = {
            'doc_ids': self._ids,
            'doc_model': report.model,
            'docs': self,
            'data': data,
            # 'get_warehouse_name': self.get_warehouse_name,
            'get_company': self._get_company,
            'get_product_name': self._product_name,
            # 'get_warehouse': self._get_warehouse,
            'get_lines': self._get_lines,
            # 'get_value_exist': self._get_value_exist,
            # 'total_in': self._total_in,
            # 'total_out': self._total_out,
            # 'total_int': self._total_int,
            # 'total_adj': self._total_adj,
            # 'total_vals': self._total_vals,
            # 'total_begin': self._total_begin,
            # 'total_end': self._total_end,
            # 'get_product_uom': self.get_product_uom
            }
        return report_obj.render('product_reports_ps.ps_most_selling_product', docargs)

    '''
    def convert_withtimezone(self, userdate):
        """
        Convert to Time-Zone with compare to UTC
        """
        user_date = datetime.strptime(userdate, DEFAULT_SERVER_DATETIME_FORMAT)
        tz_name = self.env.context.get('tz') or self.env.user.tz
        if tz_name:
            utc = pytz.timezone('UTC')
            context_tz = pytz.timezone(tz_name)
            # not need if you give default datetime into entry ;)
            user_datetime = user_date  # + relativedelta(hours=24.0)
            local_timestamp = context_tz.localize(user_datetime, is_dst=False)
            user_datetime = local_timestamp.astimezone(utc)
            return user_datetime.strftime(DEFAULT_SERVER_DATETIME_FORMAT)
        return user_date.strftime(DEFAULT_SERVER_DATETIME_FORMAT)

    def _get_company(self, company_ids):
        res_company_pool = self.env['res.company']
        if not company_ids:
            company_ids = [x.id for x in res_company_pool.sudo().search([])]

        #filter to only have warehouses.
        selected_companies = company_ids
        # for company_id in company_ids:
        #     if self.env['stock.warehouse'].sudo().search([('company_id','=',company_id)]):
        #         selected_companies.append(company_id)

        return res_company_pool.browse(selected_companies).read(['name'])

    def product_wise_value(self, start_date, end_date, value, product_id, report_type, company_id, category_id):
        """
        Complete data with product wise
            - Out Qty(Outward Quantity to given date range)
        Return:
            [{},{},{}...]
        """

        if report_type == 'most_selling':
            cond = ""
            group_by = '''GROUP BY product_id order by product_qty_out desc LIMIT '''+str(value)

            if category_id:
                cond = " and pt.categ_id = " + str(category_id)

            else :
                if product_id:
                    cond = " and il.product_id = "+str(product_id)
                    group_by = ''' GROUP BY product_id order by product_qty_out desc '''

            print ("cond...",cond)
            # self._cr.execute('''
            #                 SELECT pp.id AS product_id,
            #                     sum((
            #                     case when i.type = 'out_refund' then -il.quantity else il.quantity end
            #                     )) AS product_qty_out,
            #                     max(il.price_unit) as price,
            #                     max(u.name) as uom
            #
            #                 FROM product_product pp
            #                 inner join account_invoice_line il
            #                 on il.product_id = pp.id
            #                 inner join account_invoice i
            #                 on i.id = il.invoice_id
            #                 inner join product_uom u on u.id = il.uom_id
            #                 inner join product_template pt on pt.id = pp.product_tmpl_id
            #                 where i.date_invoice  between %s and %s
            #                 and i.type in ('out_invoice','out_refund')
            #                 and state in ('open','paid')
            #                 and i.company_id in %s
            #                 '''+cond + ' '+ group_by ,
            #                  (start_date, end_date, tuple(company_id)))
            self._cr.execute('''
            
                            select 
                                    product_id,
                                    sum(product_qty_out) as product_qty_out,
                                    max(price_unit) as price,
                                    max(uom) as uom
                                 from
                                (
                                
                                SELECT pp.id AS product_id,
                                       (
                                        case when i.type = 'out_refund' then -il.quantity else il.quantity end 
                                        ) AS product_qty_out,
                                        
                                        il.price_unit,
                                        u.name as uom
                                
                                    FROM product_product pp 
                                    inner join account_invoice_line il
                                    on il.product_id = pp.id
                                    inner join product_template pt on pt.id = pp.product_tmpl_id
                                    inner join account_invoice i 
                                    on i.id = il.invoice_id
                                    inner join uom_uom u on u.id = il.uom_id
                                    where i.date_invoice  between %s and %s
                                    and i.type in ('out_invoice','out_refund')
                                    and state in ('open','paid')
                                    and i.company_id in %s
                                    and pt.active is true
                                    ''' + cond + '''
                                    
                                    
                                union all
                                
                                    SELECT pp.id AS product_id,
                                        (
                                        pl.qty
                                        ) AS product_qty_out,
                                       
                                        pl.price_unit,
                                        u.name as uom
                                
                                    FROM product_product pp 
                                    inner join pos_order_line pl
                                    on pl.product_id = pp.id
                                    inner join product_template pt on pt.id = pp.product_tmpl_id
                                    inner join pos_order po
                                    on po.id = pl.order_id
                                    inner join uom_uom u on u.id = pt.uom_id
                                    where to_char((po.date_order ::TIMESTAMP::VARCHAR || ' UTC')::TIMESTAMPTZ AT TIME ZONE 'Asia/Riyadh', 'yyyy-mm-dd')::date between %s and %s
                                    and state in ('posted','paid')
                                    and po.company_id in %s
                                    and pt.active is true
                                    ''' + cond + '''
                                    
                                    
                                )
                                total
                                ''' + group_by + '''
                        ''',(start_date, end_date, tuple(company_id), start_date, end_date, tuple(company_id) ))

            values = self._cr.dictfetchall()
            # if not values:
            #     raise UserError(_('There is no record found for this entry !'))

            # Removed zero values dictionary
            values = self._remove_zero_qty(values)
            return values

        else:
            cond = " and pt.active is true "
            limit = " limit "+str(value)

            if category_id:
                cond = " and pt.categ_id = " + str(category_id)

            elif product_id:
                cond = " and p.id = " + str(product_id)
                limit = ''' '''

            self._cr.execute('''
                    select
                        p.id as product_id,
                            0 as product_qty_out,
                            pt.list_price as price,
                            u.name as uom
                        from product_product p
                        inner join product_template pt 
                            on pt.id = p.product_tmpl_id
                            inner join uom_uom u on u.id = pt.uom_id
                            where p.id not in (
                                SELECT pp.id AS product_id
                                       
                                    FROM product_product pp 
                                    inner join account_invoice_line il
                                    on il.product_id = pp.id
                                    inner join product_template pt on pt.id = pp.product_tmpl_id
                                    inner join account_invoice i 
                                    on i.id = il.invoice_id
                                    inner join product_uom u on u.id = il.uom_id
                                    where i.date_invoice  between %s and %s
                                    and i.type in ('out_invoice','out_refund')
                                    and state in ('open','paid')
                                    and i.company_id in %s
                                    and pt.active is true
                                    ''' + cond + '''
                                    
                                    
                                union 
                                
                                    SELECT pp.id AS product_id
                                        
                                
                                    FROM product_product pp 
                                    inner join pos_order_line pl
                                    on pl.product_id = pp.id
                                    inner join product_template pt on pt.id = pp.product_tmpl_id
                                    inner join pos_order po
                                    on po.id = pl.order_id
                                    inner join uom_uom u on u.id = pt.uom_id
                                    where to_char((po.date_order ::TIMESTAMP::VARCHAR || ' UTC')::TIMESTAMPTZ AT TIME ZONE 'Asia/Riyadh', 'yyyy-mm-dd')::date between %s and %s
                                    and state in ('posted','paid')
                                    and po.company_id in %s
                                    and pt.active is true
                                    ''' + cond + '''
                                ) 
            ''' + cond + ' ' + limit,
                             (start_date, end_date, tuple(company_id), start_date, end_date, tuple(company_id)))
            values = self._cr.dictfetchall()
            return values



    def _remove_zero_qty(self, values):
        final_values = []
        for rm_zero in values:
            if rm_zero['product_qty_out'] == 0.0:
                pass
            else: final_values.append(rm_zero)
        return final_values


    def _get_lines(self, data, company_id):
        """
        Process:
            Pass start date, end date, locations to get data from moves,
            Merge those data with locations,
        Return:
            {location : [{},{},{}...], location : [{},{},{}...],...}
        """

        start_date = self.convert_withtimezone(data['form']['start_date'] + ' 00:00:00')
        end_date = self.convert_withtimezone(data['form']['end_date'] + ' 23:59:59')

        value = data['form'] and data['form'].get('value') or 0
        product_id = data['form'] and data['form'].get('product_id') or 0
        report_type = data['form'] and data['form'].get('report_type') or 0
        category_id = data['form'] and data['form'].get('category_id') or 0

        if not company_id:
            company_id = self.env['res.company'].search([]).ids

        else:
            company_id = [company_id]

        final_values = []

        lines =  self.product_wise_value(start_date, end_date, value, product_id, report_type, company_id,category_id)
        print ("lines....",lines)
        return lines

    def _product_name(self, product_id):
        """
        Find product name and assign to it
        """
        product = self.env['product.product'].browse(product_id).name_get()
        return product and product[0] and product[0][1] or ''
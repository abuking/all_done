# -*- coding: utf-8 -*-
# Copyright (c) 2015-Present TidyWay Software Solution. (<https://tidyway.in/>)

import pytz
from odoo import models, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime
from odoo.exceptions import UserError


class ReportMostSellingProducts(models.AbstractModel):
    _name = 'report.product_reports_ps.ps_traceability_product'

    @api.model
    def _get_report_values(self,docids, data=None):
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        clause = []
        sales_records = []
        return {
                'doc_ids': self.ids,
                'doc_model': self.model,
                'docs': docs,
                'data' : data,
                'get_warehouse_name': self._get_warehouse_name,
                'get_company': self._get_company,
                'get_product_name': self._product_name,
                'get_warehouse': self._get_warehouse,
                'get_lines': self._get_lines,
                'get_beginning_inventory': self._get_beginning_inventory,
                'get_ending_inventory': self._get_ending_inventory,
                'get_product_uom': self._get_product_uom


        }
        #'data': data,
    #def render_html(self, docids, data=None):
        #
        # report_obj = self.env['report']
        # report = report_obj._get_report_from_name('product_reports_ps.ps_traceability_product')
        # self.begining_qty = 0.0
        # self.total_in = 0.0
        # self.total_out = 0.0
        # self.total_int = 0.0
        # self.total_adj = 0.0
        # self.total_begin = 0.0
        # self.total_end = 0.0
        # self.total_inventory = []
        # self.value_exist = {}
        # docargs = {
        #     'doc_ids': self._ids,
        #     'doc_model': report.model,
        #     'docs': self,
        #     'data': data,
        #     'get_warehouse_name': self.get_warehouse_name,
        #     'get_company': self._get_company,
        #     'get_product_name': self._product_name,
        #     'get_warehouse': self._get_warehouse,
        #     'get_lines': self._get_lines,
        #     'get_beginning_inventory': self._get_beginning_inventory,
        #     'get_ending_inventory': self._get_ending_inventory,
        #     # 'get_value_exist': self._get_value_exist,
        #     # 'total_in': self._total_in,
        #     # 'total_out': self._total_out,
        #     # 'total_int': self._total_int,
        #     # 'total_adj': self._total_adj,
        #     # 'total_vals': self._total_vals,
        #     # 'total_begin': self._total_begin,
        #     # 'total_end': self._total_end,
        #     'get_product_uom': self.get_product_uom
        # }
        # return report_obj.render('product_reports_ps.ps_traceability_product', docargs)
    def _get_product_uom(self, product_id):
        """
        Warehouse wise inward Qty
        """
        return self.env['product.product'].browse(product_id).uom_id.name

    def _get_warehouse_name(self, warehouse_ids):
        """
        Return warehouse names
            - WH A, WH B...
        """
        warehouse_obj = self.env['stock.warehouse']
        if not warehouse_ids:
            warehouse_ids = [x.id for x in warehouse_obj.search([])]
        war_detail = warehouse_obj.read(warehouse_ids,['name'])
        return ', '.join([lt['name'] or '' for lt in war_detail])

    def convert_withtimezone(self, userdate):
        """
        Convert to Time-Zone with compare to UTC
        """
        user_date = datetime.strptime(userdate, DEFAULT_SERVER_DATETIME_FORMAT)
        tz_name = self.env.context.get('tz') or self.env.user.tz
        if tz_name:
            utc = pytz.timezone('UTC')
            context_tz = pytz.timezone(tz_name)
            # not need if you give default datetime into entry ;)
            user_datetime = user_date  # + relativedelta(hours=24.0)
            local_timestamp = context_tz.localize(user_datetime, is_dst=False)
            user_datetime = local_timestamp.astimezone(utc)
            return user_datetime.strftime(DEFAULT_SERVER_DATETIME_FORMAT)
        return user_date.strftime(DEFAULT_SERVER_DATETIME_FORMAT)

    def _get_company(self, company_ids):
        res_company_pool = self.env['res.company']
        if not company_ids:
            company_ids = [x.id for x in res_company_pool.sudo().search([])]

        # filter to only have warehouses.
        selected_companies = company_ids
        print ('selected',selected_companies)
        # for company_id in company_ids:
        #     if self.env['stock.warehouse'].sudo().search([('company_id','=',company_id)]):
        #         selected_companies.append(company_id)

        return res_company_pool.browse(selected_companies).read(['name'])

    # Added conversion with dual uom #need to check in deeply
    def _get_beginning_inventory(self, data, warehouse_id, product_id, current_record):
        """
        Process:
            -Pass locations , start date and product_id
        Return:
            - Beginning inventory of product for exact date
        """
        location_id = data['form'] and data['form'].get('location_id') or False
        if location_id:
            locations = [location_id]
        else:
            locations = self._find_locations(warehouse_id)

        from_date = self.convert_withtimezone(data['form']['start_date'] + ' 00:00:00')
        self._cr.execute(''' 
                            SELECT id,coalesce(sum(qty), 0.0) AS qty
                            FROM
                                ((
                                SELECT
                                    pp.id, pp.default_code,m.date,
                                    CASE WHEN pt.uom_id = m.product_uom 
                                    THEN u.name 
                                    ELSE (select name from product_uom where id = pt.uom_id) end AS name,

                                    CASE WHEN pt.uom_id = m.product_uom  
                                    THEN coalesce(sum(-m.product_qty)::decimal, 0.0)
                                    ELSE coalesce(sum(-m.product_qty * pu.factor / u.factor )::decimal, 0.0) END  AS qty

                                FROM product_product pp 
                                LEFT JOIN stock_move m ON (m.product_id=pp.id)
                                LEFT JOIN product_template pt ON (pp.product_tmpl_id=pt.id)
                                LEFT JOIN stock_location l on(m.location_id=l.id)
                                LEFT JOIN stock_picking p ON (m.picking_id=p.id)
                                LEFT JOIN product_uom pu ON (pt.uom_id=pu.id)
                                LEFT JOIN product_uom u ON (m.product_uom=u.id)

                                WHERE m.date <  %s AND (m.location_id in %s) 
                                AND m.state='done' and pp.active=True AND pp.id = %s
                                GROUP BY  pp.id,pt.uom_id , m.product_uom ,
                                pp.default_code,u.name,m.date
                                ) 
                                UNION ALL
                                (
                                SELECT
                                    pp.id, pp.default_code,m.date,
                                    CASE WHEN pt.uom_id = m.product_uom 
                                    THEN u.name 
                                    ELSE (select name from product_uom where id = pt.uom_id) end AS name,

                                    CASE WHEN pt.uom_id = m.product_uom 
                                    THEN coalesce(sum(m.product_qty)::decimal, 0.0)
                                    ELSE coalesce(sum(m.product_qty * pu.factor / u.factor )::decimal, 0.0) END  AS qty
                                FROM product_product pp 
                                LEFT JOIN stock_move m ON (m.product_id=pp.id)
                                LEFT JOIN product_template pt ON (pp.product_tmpl_id=pt.id)
                                LEFT JOIN stock_location l on(m.location_dest_id=l.id)    
                                LEFT JOIN stock_picking p ON (m.picking_id=p.id)
                                LEFT JOIN product_uom pu ON (pt.uom_id=pu.id)
                                LEFT JOIN product_uom u ON (m.product_uom=u.id)

                                WHERE m.date <  %s AND (m.location_dest_id in %s) 
                                AND m.state='done' and pp.active=True AND pp.id = %s
                                GROUP BY  pp.id,pt.uom_id , m.product_uom ,
                                pp.default_code,u.name,m.date
                                ))
                                AS foo
                            group BY id
                            ''', (from_date, tuple(locations), product_id, from_date, tuple(locations), product_id))

        res = self._cr.dictfetchall()
        self.begining_qty = res and res[0].get('qty', 0.0) or 0.0
        current_record.update({'begining_qty': res and res[0].get('qty', 0.0) or 0.0})
        return self.begining_qty

    def product_wise_value(self, locations, start_date, end_date, product_id, company_id, category_id):
        """
        Complete data with product wise
            - Out Qty(Outward Quantity to given date range)
        Return:
            [{},{},{}...]
        """
        cond = ""
        prod_cond = """
                            sum( case when spt.code is null then sm.product_qty else 0 end) as inv_adj,
                            sum( case when spt.code ='outgoing' then sm.product_qty else 0 end) as outgoing,
                            sum( case when spt.code ='incoming' and sm.origin_returned_move_id is null then sm.product_qty else 0 end) as incoming,
                            sum( case when spt.code ='incoming' and sm.origin_returned_move_id is not null then sm.product_qty else 0 end) as return,
                            sum( case when spt.code ='internal' and dl.usage = 'transit' then -sm.product_qty else 
		                         case when spt.code ='internal' and dl.usage = 'internal' then sm.product_qty else 0 end end) as internal,
                        """
        group_by = "group by pt.name, p.id"
        if category_id:
            cond = " and pt.categ_id = " + str(category_id)

        else:
            if product_id:
                cond = " and sm.product_id = " + str(product_id)
                prod_cond =  "sm.product_qty, " \
                             "case when sp.name is not null then sp.name else sm.origin end as origin," \
                             """( case when spt.code is null then sm.product_qty else 0 end) as inv_adj,
                                ( case when spt.code ='outgoing' then sm.product_qty else 0 end) as outgoing,
                                ( case when spt.code ='incoming' and sm.origin_returned_move_id is null then sm.product_qty else 0 end) as incoming,
                                ( case when spt.code ='incoming' and sm.origin_returned_move_id is not null then sm.product_qty else 0 end) as return,
                                ( case when spt.code ='internal' and dl.usage = 'transit' then -sm.product_qty else 
		                          case when spt.code ='internal' and dl.usage = 'internal' then sm.product_qty else 0 end end) as internal,"""
                group_by = " order by sm.date asc"

        if product_id :
            self._cr.execute("""
                                select  

                                    """ + prod_cond + """
                                    pt.name as product,
                                    p.id as product_id,
                                    to_char((sm.date ::TIMESTAMP::VARCHAR || ' UTC')::TIMESTAMPTZ AT TIME ZONE 'Asia/Riyadh', 'yyyy-mm-dd')::date as move_date,
                                    (select  
                                            sum( case when spt.code is null then sm.product_qty else 0 end) + 
                                            sum( case when spt.code ='incoming' then sm.product_qty else 0 end) - 
                                            sum( case when spt.code ='outgoing' then sm.product_qty else 0 end) -
                                            sum( case when spt.code ='internal' then sm.product_qty else 0 end) as opening_qty
                                            
                                            
                                            
                                        from stock_move sm
                                        left outer join product_product p 
                                        on p.id = sm.product_id
                                        left outer join product_template pt 
                                        on pt.id = p.product_tmpl_id
                                        left outer join stock_picking sp
                                        on sp.id = sm.picking_id
                                        left outer join stock_picking_type spt
                                        on spt.id = sp.picking_type_id
                                        where sm.state in ('done')
                                        and sm.location_id <> sm.location_dest_id
                                          """ + cond + """
                                        and sm.date < %s
                                        and sm.company_id = %s
                                        and p.active is True
                                        group by pt.name, p.id) as opening_qty

                                from stock_move sm
                                inner join product_product p 
                                on p.id = sm.product_id
                                inner join product_template pt 
                                on pt.id = p.product_tmpl_id
                                left outer join stock_picking sp
                                on sp.id = sm.picking_id
                                left outer join stock_picking_type spt
                                on spt.id = sp.picking_type_id
                                inner join stock_location sl on sl.id = sm.location_id
	                            inner join stock_location dl on dl.id = sm.location_dest_id

                                where sm.state in ('done')
                                and sm.location_id <> sm.location_dest_id
                                """ + cond + """
                                and sm.date between %s and %s
                                and sm.company_id = %s
                                and p.active is True
                                """ + group_by ,(start_date,company_id, start_date, end_date, company_id)
                             )
            values = self._cr.dictfetchall()
            return values




        print ("data............................",prod_cond,cond,group_by,company_id)
        self._cr.execute("""
                select * from
                    (
                    select  
                        
                        """ + prod_cond +"""
                        pt.name as product,
                        p.id as product_id
                        
                    from stock_move sm
                    inner join product_product p 
                    on p.id = sm.product_id
                    inner join product_template pt 
                    on pt.id = p.product_tmpl_id
                    left outer join stock_picking sp
                    on sp.id = sm.picking_id
                    left outer join stock_picking_type spt
                    on spt.id = sp.picking_type_id
                     inner join stock_location sl on sl.id = sm.location_id
                    inner join stock_location dl on dl.id = sm.location_dest_id
                    
                    where sm.state in ('done')
                    and sm.location_id <> sm.location_dest_id
                    """ + cond + """
                    and sm.date between %s and %s
                    and sm.company_id = %s
                    and p.active is True
                    """ + group_by +"""
                    
                    )current
                
                    left outer join 
                    (
                    select  
                        
                        sum( case when spt.code is null then sm.product_qty else 0 end) + 
                        sum( case when spt.code ='incoming' then sm.product_qty else 0 end) - 
                        sum( case when spt.code ='outgoing' then sm.product_qty else 0 end) -
                        sum( case when spt.code ='internal' then sm.product_qty else 0 end) as opening_qty,
                        pt.name as product,
                        p.id as product_id
                        
                    from stock_move sm
                    left outer join product_product p 
                    on p.id = sm.product_id
                    left outer join product_template pt 
                    on pt.id = p.product_tmpl_id
                    left outer join stock_picking sp
                    on sp.id = sm.picking_id
                    left outer join stock_picking_type spt
                    on spt.id = sp.picking_type_id
                    inner join stock_location sl on sl.id = sm.location_id
	                inner join stock_location dl on dl.id = sm.location_dest_id
                    where sm.state in ('done')
                    and sm.location_id <> sm.location_dest_id
                    """ + cond + """
                    and sm.date < %s 
                    and sm.company_id = %s
                    and p.active is True
                    group by pt.name, p.id
                    )opening
                    on current.product_id = opening.product_id
        """,(start_date, end_date, company_id ,start_date, company_id))

        values = self._cr.dictfetchall()
        return values


    def _remove_zero_qty(self, values):
        final_values = []
        for rm_zero in values:
            if rm_zero['product_qty_out'] == 0.0:
                pass
            else:
                final_values.append(rm_zero)
        return final_values

    def _compare_with_company(self, warehouse, company):
        """
        Company loop check ,whether it is in company of not.
        """
        company_id = self.env['stock.warehouse'].browse(warehouse).read(['company_id'])[0]['company_id']
        if company_id[0] != company:
            return False
        return True

    def _get_warehouse(self, warehouse):
        """
        Find warehouse name with id
        """
        return self.env['stock.warehouse'].browse(warehouse).read(['name'])[0]['name']


    def _get_ending_inventory(self, in_qty, out_qty,internal_qty,adjust_qty):
        """
        Process:
            -Inward, outward, internal, adjustment
        Return:
            - total of those qty
        """
        return self.begining_qty + in_qty + out_qty + internal_qty + adjust_qty

    def _find_locations(self, warehouse):
        """
        Find warehouse stock locations and its childs.
            -All stock reports depends on stock location of warehouse.
        """
        warehouse_obj = self.env['stock.warehouse']
        location_obj = self.env['stock.location']
        store_location_id = warehouse_obj.browse(warehouse).view_location_id.id
        return [x.id for x in location_obj.search([('location_id', 'child_of', store_location_id)])]

    def find_warehouses(self,company_id):
        """
        Find all warehouses
        """
        return [x.id for x in self.env['stock.warehouse'].search([('company_id','=',company_id)])]

    def _get_lines(self, data, company):
        """
        Process:
            Pass start date, end date, locations to get data from moves,
            Merge those data with locations,
        Return:
            {location : [{},{},{}...], location : [{},{},{}...],...}
        """

        start_date = self.convert_withtimezone(data['form']['start_date'] + ' 00:00:00')
        end_date = self.convert_withtimezone(data['form']['end_date'] + ' 23:59:59')

        product_id = data['form'] and data['form'].get('product_id') or 0
        category_id = data['form'] and data['form'].get('category_id') or 0
        warehouse_ids = data['form'] and data['form'].get('warehouse_ids', []) or []

        if not company:
            company_id = self.env['res.company'].search([]).ids

        else:
            company_id = [company]

        final_values = []

        if not warehouse_ids:
            warehouse_ids = self.find_warehouses(company)

        final_values = {}
        for warehouse in warehouse_ids:
            # looping for only warehouses which is under current company
            if self._compare_with_company(warehouse, company):
                locations = self._find_locations(warehouse)
                if not locations:
                    raise Warning(_(""" No Location Found!\n please check your warehouse/location configuration."""))
                final_values.update({
                                     warehouse: self.product_wise_value(locations, start_date, end_date, product_id, company, category_id)
                                     })
        print ("final_values...",final_values)
        return final_values

    def _product_name(self, product_id):
        """
        Find product name and assign to it
        """
        product = self.env['product.product'].browse(product_id).name_get()
        return product and product[0] and product[0][1] or ''
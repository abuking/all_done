# -*- coding: utf-8 -*-
# Copyright (c) 2015-Present TidyWay Software Solution. (<https://tidyway.in/>)

import time
from odoo import models, api, fields,_
from odoo.exceptions import Warning


class ps_top_selling_wizard(models.TransientModel):
    _name = 'ps.top.selling.report'

    company_id = fields.Many2one('res.company', string='Company')
    start_date = fields.Date('Beginning Date', required=True, default=time.strftime('%Y-%m-%d'))
    end_date = fields.Date('End Date', required=True, default=time.strftime('%Y-%m-%d'))
    product_id = fields.Many2one('product.product','Product')
    value = fields.Integer('Display Top Products?',help="If you want to see Top 10 selling product, then put 10 here.",
                           required=True, default=5)
    report_type = fields.Selection([('most_selling','Most Selling'),('not_selling','Not Selling')], 'Report Type',
                                   default = 'most_selling')
    category_id = fields.Many2one('product.category','Category')



    @api.multi
    def print_report(self):
        """
            Print report either by warehouse or product-category
        """
        assert len(self) == 1, 'This option should only be used for a single id at a time.'
        datas = {
                 'form':
                        {
                            'company_id': self.company_id and [self.company_id.id] or [],
                            'start_date': self.start_date,
                            'end_date': self.end_date,
                            'value':  self.value,
                            'id': self.id,
                            'product_id' : self.product_id and self.product_id.id or False,
                            'report_type' : self.report_type,
                            'category_id' : self.category_id and self.category_id.id or False
                        }
                }

        return self.env.ref('product_reports_ps.action_pioneer_report_most_selling_product').with_context(landscape=True).report_action(
            self, data=datas)
        #return self.env['report'].get_action(self, 'product_reports_ps.ps_most_selling_product', data=datas)


class ps_product_traceability_wizard(models.TransientModel):
    _name = 'ps.product.tracebaility.report'

    company_id = fields.Many2one('res.company', string='Company')
    start_date = fields.Date('Beginning Date', required=True, default=time.strftime('%Y-%m-%d'))
    end_date = fields.Date('End Date', required=True, default=time.strftime('%Y-%m-%d'))
    product_id = fields.Many2one('product.product','Product')
    warehouse_ids = fields.Many2many('stock.warehouse','trace_warehouse_rel','trace_id','warehouse_id','Warehouse')
    category_id = fields.Many2one('product.category','Category')



    @api.multi
    def print_report(self):
        """
            Print report either by warehouse or product-category
        """
        assert len(self) == 1, 'This option should only be used for a single id at a time.'
        datas = {
                 'form':
                        {
                            'company_id': self.company_id and [self.company_id.id] or [],
                            'start_date': self.start_date,
                            'end_date': self.end_date,
                             'warehouse_ids': [y.id for y in self.warehouse_ids],
                            'id': self.id,
                            'product_id' : self.product_id and self.product_id.id or False,
                            'category_id' : self.category_id and self.category_id.id or False
                        }
                }

        return self.env.ref('product_reports_ps.action_pioneer_report_product_traceability').with_context(landscape=True).report_action(self, data=datas)
        #return self.env['report'].get_action(self, 'product_reports_ps.ps_traceability_product', data=datas)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

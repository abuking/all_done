# -*- coding: utf-8 -*-
{
    'name': 'Pioneer Solutions-Business Trip',
    'version': '10.1.0.0',

    'description': """  Business Trip Module In HR
                    """,
    'author': 'Arun, Pioneer Solutions.',
    'depends': ['base', 'common_ps','account','hr_performance_ps'],

    'data': [
        'data/ps_bt_sequence.xml',
        'views/ps_bt_business_trip_view.xml',
        'views/ps_bt_config_view.xml',
        'views/ps_bt_report_view.xml',
        'report/ps_bt_report.xml',
        'report/ps_bt_report_business_trip.xml',
        'security/ps_bt_security_groups.xml',
        'security/ir.model.access.csv',
    ],

    'installable': True,
}

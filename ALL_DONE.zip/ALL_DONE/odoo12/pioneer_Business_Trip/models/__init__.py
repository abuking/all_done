# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import ps_bt_config
from . import ps_bt_business_trip

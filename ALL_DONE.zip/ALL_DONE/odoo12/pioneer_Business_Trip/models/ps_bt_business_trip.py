# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import except_orm, Warning, RedirectWarning
from datetime import datetime,timedelta
from dateutil import relativedelta
import math
from lxml import etree
from odoo.osv.orm import setup_modifiers

def _get_employee(obj):
    ids = obj.env['hr.employee'].search([('user_id', '=', obj.env.uid)])
    if ids:return ids[0]
    else:raise Warning(_('The user is not an employee.'))
    return False

class hr_business_trip(models.Model):
    _name = 'hr.business.trip'
    _inherit = ['mail.thread', 'resource.mixin']

    @api.one
    def _get_current_user(self):
        self.current_user = False
        self.is_direct_manager = False
        if (self.employee_id and self.employee_id.parent_id and self.employee_id.parent_id.user_id) and self.employee_id.parent_id.user_id.id == self.env.uid:
            self.is_direct_manager = True
        if (self.employee_id and self.employee_id.user_id) and self.employee_id.user_id.id == self.env.uid:
            self.current_user = True


    def _compute_date(self, date_from, date_to, DATETIME_FORMAT):
        days = months = years = 0
        differents = relativedelta.relativedelta(datetime.strptime(str(date_to), DATETIME_FORMAT),datetime.strptime(str(date_from), DATETIME_FORMAT))
        years = differents.years
        months = (years * 12) + differents.months
#        days = differents.days
        timedelta = datetime.strptime(str(date_to), DATETIME_FORMAT) - datetime.strptime(str(date_from), DATETIME_FORMAT)
        diff_day = timedelta.days + float(timedelta.seconds) / 86400
        days = round(math.floor(diff_day))
        return days, months, years

    @api.one
    @api.depends('travel_date_from', 'travel_date_to', 'actual_travel_date_from', 'actual_travel_date_to')
    def _compute_days(self):
        days = 0
        DATETIME_FORMAT = "%Y-%m-%d"
        if self.travel_date_from and self.travel_date_to:
            days, months, years = self._compute_date(self.travel_date_from, self.travel_date_to, DATETIME_FORMAT)
            self.request_travel_days = days + 1
        if self.actual_travel_date_from and self.actual_travel_date_to:
            days, months, years = self._compute_date(self.actual_travel_date_from, self.actual_travel_date_to, DATETIME_FORMAT)
            self.actual_travel_days = days + 1

    def _get_currency(self):
        user = self.env['res.users'].browse([self.env.uid])[0]
        return user.company_id.currency_id

    name = fields.Char(string='Serial', default=lambda self: _('New'))
    date = fields.Date(string='Request Date', default=fields.date.today(), readonly=True)
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, readonly=True, states={'draft': [('readonly', False)]}, default=_get_employee)
    job_id = fields.Many2one(related='employee_id.job_id', string="Job Title", readonly=True)
    department_id = fields.Many2one(related='employee_id.department_id', string="Department", readonly=True)
    company_id = fields.Many2one(related='employee_id.company_id', string="Company", readonly=True)
    country_id = fields.Many2one('res.country', string="Country", readonly=True, states={'draft': [('readonly', False)]})
    city = fields.Char(string='City', readonly=True, states={'draft': [('readonly', False)]})
    visa_required = fields.Boolean(string='VISA Required', readonly=True, states={'draft': [('readonly', False)]})
    travel_date_from = fields.Date(string='Travel Date From', required=True, readonly=True, states={'draft': [('readonly', False)]})
    travel_date_to = fields.Date(string='Travel Date To', required=True, readonly=True, states={'draft': [('readonly', False)]})
    request_travel_days = fields.Integer(string='Request Days', readonly=True, compute='_compute_days')
    actual_travel_date_from = fields.Date(string='Actual Travel Date From', readonly=True, states={'approve': [('readonly', False)]})
    actual_travel_date_to = fields.Date(string='Actual Travel Date To', readonly=True, states={'approve': [('readonly', False)]})
    actual_travel_days = fields.Integer(string='Actual Days', readonly=True, compute='_compute_days')
    recruitment = fields.Boolean(string='Recruitment', readonly=True, states={'approve': [('readonly', False)]})
    employee_recruited = fields.Integer(string='No. of Employees Recruited', readonly=True, states={'approve': [('readonly', False)]})
    expense_amount = fields.Float(string='Expense Amount', readonly=True, states={'approve': [('readonly', False)], 'close': [('readonly', False)]})
    note = fields.Text(string='Description', readonly=True, states={'draft': [('readonly', False)]})
    current_user = fields.Boolean(string='Current User', readonly=True, compute='_get_current_user')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True, default=_get_currency)
    move_id = fields.Many2one('account.move', string='Journal Entry', readonly=True)
    direct_manager_id = fields.Many2one('res.users', string='Direct Manager', readonly=True)
    direct_manager_date = fields.Datetime(string='Confirmed Date', readonly=True)
    direct_manager_note = fields.Text(string='Comments', readonly=True, states={'request': [('readonly', False)]})
    hr_manager_id = fields.Many2one('res.users', string='HR Manager', readonly=True)
    hr_manager_date = fields.Datetime(string='Confirmed Date', readonly=True)
    hr_manager_note = fields.Text(string='Comments', readonly=True, states={'confirm': [('readonly', False)]})
    account_manager_id = fields.Many2one('res.users', string='Account Manager', readonly=True)
    account_manager_date = fields.Datetime(string='Confirmed Date', readonly=True)
    account_manager_note = fields.Text(string='Comments', readonly=True, states={'approve': [('readonly', False)]})
    is_direct_manager = fields.Boolean(string='Is Direct Manager', readonly=True, compute='_get_current_user')
    state = fields.Selection([
            ('draft','Draft'),
            ('request','Sent Request'),
            ('confirm','Confirm'),
            ('approve','Approve'),
            ('refuse','Refuse'),
            ('close','Close'),
            ('fm_approve','Financial Manager Approve'),
        ], string='Status', index=True, readonly=True, default='draft',
        track_visibility='onchange', copy=False,
        help="Status")

    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        res = super(hr_business_trip, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu)
        doc = etree.XML(res['arch'])
        group_user = self.env.user.has_group('base.group_user')
        group_hr_user = self.env.user.has_group('hr.group_hr_user')
        group_hr_manager = self.env.user.has_group('hr.group_hr_manager')
        group_hr_general_manager = self.env.user.has_group('base.group_hr_general_manager')
        emp_obj = self.env['hr.employee']
        dm_emp_ids = emp_obj.search([('parent_id.user_id', '=', self._uid)]) # to check in employee list where he is direct manger
        for node in doc.xpath("//form") + doc.xpath("//tree"):
            if group_user and not dm_emp_ids and not group_hr_user and not group_hr_manager and not group_hr_general_manager:
              node.set('create', _('false'))
              node.set('edit', _('false'))
              node.set('delete', _('false'))
        res['arch'] = etree.tostring(doc)
        return res

    @api.model
    def create(self, values):
        if values.get('name', 'New') == 'New':
            values['name'] = self.env['ir.sequence'].next_by_code('hr.business.trip') or 'New'
        result = super(hr_business_trip, self).create(values)
        return result

    @api.multi
    def unlink(self):
        if self.state not in ('draft',False):
            raise Warning(_('You cannot delete record which is not in Draft.'))
        return models.Model.unlink(self)

    @api.multi
    def action_request(self):
        return self.write({'state': 'request'})

    @api.multi
    def action_confirm(self):
        return self.write({'state': 'confirm', 'direct_manager_id': self.env.uid, 'direct_manager_date':fields.date.today()})

    @api.multi
    def action_approve(self):
        return self.write({'state': 'approve', 'hr_manager_id': self.env.uid, 'hr_manager_date': fields.date.today()})

    @api.multi
    def action_refuse(self):
        return self.write({'state': 'refuse'})

    @api.multi
    def action_close(self):
        if not self.actual_travel_date_from or not self.actual_travel_date_to: raise Warning(
            _('Please choose actual travel from and to Date.'))
        return self.write({'state': 'close'})

    @api.multi
    def action_fm_approve(self):
        if self.expense_amount <= 0: return self.write({'state': 'fm_approve'})
        move_obj = self.env['account.move']
        move_line_obj = self.env['account.move.line']
        nazar_obj = self.env['account.nazar']
        company_currency = self.company_id.currency_id.id
        diff_currency_p = self.currency_id.id != company_currency
        if not self.employee_id.address_home_id: raise Warning(_('Please set the home address for employee'))
        ref = self.employee_id.name + '/' + self.name
        config = self.env['hr.accounting.config'].sudo()._get_hr_accounting_config()

        if not config or not config.business_trip_journal_id: raise Warning(_('Journal is not configure.'))
        journal_id = config.business_trip_journal_id
        if not journal_id.default_debit_account_id or not journal_id.default_credit_account_id:
            raise Warning(
                _('Missing credit or debit account for journal.Please set credit and debit account for journal.'))
        vals = {
            'journal_id': journal_id.id,
            'date': fields.datetime.today(),
            # 'period_id': period_obj.find(date)[0],
            'ref': '',
            'company_id': self.company_id.id,
        }


        line1= [(0,0,{
            'journal_id': journal_id.id,
            'partner_id': self.employee_id.address_home_id.id,
            'credit': 0,
            'debit': self.expense_amount,
            'centralisation': 'normal',
            'company_id': self.company_id.id,
            'state': 'valid',
            'blocked': False,
            'account_id': journal_id.default_debit_account_id.id,
            #'period_id': move_id.period_id.id,
            'name': 'Loan',
            'amount_currency': diff_currency_p and self.currency_id.id or False,
            'quantity': 1,

        })]

        line1.append((0,0,{
            'journal_id': journal_id.id,
            'partner_id': self.employee_id.address_home_id.id,
            'credit': self.expense_amount,
            'debit': 0,
            'centralisation': 'normal',
            'company_id': self.company_id.id,
            'state': 'valid',
            'blocked': False,
            'account_id': self.employee_id.address_home_id.property_account_payable_id.id,
            #'period_id': move_id.period_id.id,
            'name': '/',
            'amount_currency': diff_currency_p and self.currency_id.id or False,
            'quantity': 1,

        }))
        vals.update({'line_ids':line1})

        move_id = move_obj.create(vals)
        self.write({'state': 'fm_approve', 'move_id': move_id.id, 'account_manager_id': self.env.uid,
                    'account_manager_date': fields.date.today()})
        return move_id.id

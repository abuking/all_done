# -*- coding: utf-8 -*-
{
    'name': "Pioneer Partner Sequence",

    'summary': """
        Pioneer Sequence Customization 
        """,

    'description': """
        Long description of module's purpose
    """,

    'author': "Mani , Pioneer Solutions",
    'website': "www.ps-sa.net",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '11.0',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/sequence.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
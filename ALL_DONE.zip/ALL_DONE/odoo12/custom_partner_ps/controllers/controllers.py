# -*- coding: utf-8 -*-
from odoo import http

# class CustomPartnerPs(http.Controller):
#     @http.route('/custom_partner_ps/custom_partner_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/custom_partner_ps/custom_partner_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('custom_partner_ps.listing', {
#             'root': '/custom_partner_ps/custom_partner_ps',
#             'objects': http.request.env['custom_partner_ps.custom_partner_ps'].search([]),
#         })

#     @http.route('/custom_partner_ps/custom_partner_ps/objects/<model("custom_partner_ps.custom_partner_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('custom_partner_ps.object', {
#             'object': obj
#         })
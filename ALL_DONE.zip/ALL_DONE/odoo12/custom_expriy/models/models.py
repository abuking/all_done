# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import except_orm, Warning, RedirectWarning


    #exp_id_no = fields.Char('Id')
    #type = fields.Many2one('hr.expiry.details', string='Type')

#class HrExpiryDetails(models.Model):
#    _name = 'hr.expiry.details'

#    _description = 'Expiry Details'


#    name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100
# -*- coding: utf-8 -*-

import calendar

from datetime import timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models, _
from odoo.exceptions import UserError



class ReportExpriyAbs(models.AbstractModel):
    _name = 'report.custom_expriy.ps_expriy_report'
    _description = 'expriy Details Report'



    def _testing(self,iq):
        res = []
        it = iq
        self.vone = "test"
        self.vtwo = "test1"
        res.append({'color': self.vone, 'name': self.vtwo})
        type_id = self.env['hr.expiry.details'].search([])
        print("it test",it)
        #print(res)
        return res


    @api.model
    def _get_report_values(self, docids, data=None):

        iq_report = self.env['ir.actions.report']._get_report_from_name('custom_expriy.ps_expriy_report')
        docs = self.env['hr.expiry.details'].browse(self.ids)

        return {
            'doc_ids': self.ids,
            'doc_model': iq_report.model,
            'docs': docs,
            'get_model':self.get_model(data),

            #'get_employee':self._get_model(data),
            'testing': self._testing(docs),
        }


    def _get_model(self, data):

        search = [('issue_date', '>=', data['form']['f_date']),('issue_date', '<=', data['form']['t_date'])]#,('company_id', '=',company_id.id[0])]
        return search

    def get_model(self,data):
        record_ids = {}

        domain = []
        if len(data['form']['f_name']) > 0:
            domain += [('id', 'in', data['form']['f_name'])]
        record_ids = self.env['hr.family.details'].search(domain)
        print("get model work",type(record_ids))
        return record_ids

    def get_employee(self, type, data):

        res = []
        domain = [('type', '=', type.id)]
        if data['form']['f_date']:
               domain += [('issue_date', '>=', data['form']['f_date'])]
        if data['form']['t_date']:
               domain += [('issue_date', '<=', data['form']['t_date'])]
        emp_iss = self.env['hr.expiry.details'].search(domain)
        print("get employee work", emp_iss)
        return emp_iss

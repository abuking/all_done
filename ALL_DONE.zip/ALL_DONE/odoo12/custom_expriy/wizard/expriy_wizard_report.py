import time
from odoo import api, models, fields,_
from datetime import datetime
from dateutil import relativedelta
from dateutil.parser import parse
from odoo.exceptions import UserError
import base64
from custom.addons.custom_employee.models import hr_config_global as hg

class ExpriyDetailsReportWiz(models.TransientModel):       #SalaryStatementReportWiz
    _name = "expriy.details.report.wiz"			   #ps.salary.statement.report.wiz
    _description = "HR Employee Expriy Detail report"


    f_date = fields.Date('From Date', help='From Date', default=lambda *a: time.strftime('%Y-%m-01'))
    t_date = fields.Date('To Date', help='To Date',  default=lambda *a: str(datetime.now() + relativedelta.relativedelta(months=+1, day=1, days=-1))[:10])
    state = fields.Selection([('all', 'All'),('selection', 'Selection'),], 'State',default='all')
    f_name = fields.Many2many('hr.family.details',string='Type')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.user.company_id)



    @api.multi
    def print_report(self):
        [data] = self.read()
        #if not data.get('type'):
        #    raise UserError(_('You have to select at least one type.'))
        print("work print_report function")
        type_iq = self.env['hr.family.details'].browse(data['f_name'])
        datas = {
            'ids': [],
            'model': 'hr.expiry.details',
            'form': data
         }
        return self.env.ref('custom_expriy.ps_action_report_expriy_ps').with_context(
            from_transient_model=True).report_action(type_iq, data=datas)



    #
    # @api.multi
    # def check_report(self):
    #     data = {}
    #     #self.model = self.env.context.get('active_model')
    #     #docs = self.env[self.model].browse(self.env.context.get('active_id'))
    #     print("report function work")
    #     data['form'] = self.read(['f_date', 't_date', 'state','iq_type','company_id'])[0]
    #     return self._print_report(data)
    #
    # def _print_report(self, data):
    #     print("print report function work ")
    #
    #     data['form'].update(self.read(['f_date', 't_date', 'state','iq_type','company_id'])[0])
    #
    #     return self.env.ref("custom_expriy.ps_action_report_expriy_ps").with_context(landscape=True).report_action(self, data=data)
    #     #return self.env.ref("payslip_report_xls_ps.ps_action_report_payslip_ps").with_context(landscape=True).report_action(self, data=data)

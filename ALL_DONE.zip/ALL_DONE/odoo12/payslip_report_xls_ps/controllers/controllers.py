# -*- coding: utf-8 -*-
from odoo import http

# class PayslipReportXlsPs(http.Controller):
#     @http.route('/payslip_report_xls_ps/payslip_report_xls_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/payslip_report_xls_ps/payslip_report_xls_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('payslip_report_xls_ps.listing', {
#             'root': '/payslip_report_xls_ps/payslip_report_xls_ps',
#             'objects': http.request.env['payslip_report_xls_ps.payslip_report_xls_ps'].search([]),
#         })

#     @http.route('/payslip_report_xls_ps/payslip_report_xls_ps/objects/<model("payslip_report_xls_ps.payslip_report_xls_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('payslip_report_xls_ps.object', {
#             'object': obj
#         })
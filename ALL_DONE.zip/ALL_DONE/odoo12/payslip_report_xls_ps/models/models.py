# -*- coding: utf-8 -*-

from odoo import models, fields, api
from xlsxwriter.workbook import Workbook as WB
import tempfile
from io import StringIO
import io

class HrPayslip(models.Model):
    _name = 'hr.payslip'
    _inherit = 'hr.payslip'

    @api.multi
    def get_total(self, slip_id):
        total = 0
        rule_type = ['loan', 'hrdf', 'advance', 'gosi', 'other_deduction', 'absent']
        for r in rule_type:
            res = self.get_rule(slip_id, r)
            if res:
                total = total + res
            else:
                total = total
        return total

    @api.multi
    def get_rule(self, slip_id, rule):
        self._cr.execute(
            "select total from hr_payslip_line where salary_rule_id in (select id from hr_salary_rule where code = '%s') and slip_id in (select id from hr_payslip where id = %s)" % (
            rule, slip_id))
        res = self._cr.fetchone()
        if res:
            return res[0]
        else:
            return 0.0

    @api.multi
    def generate_xls(self, case, wiz):
        output = io.BytesIO()
        workbook = WB(output, {'in_memory': True})
        sheet = workbook.add_worksheet()
        # sheet.set_column('A:A', 40)
        sheet.set_column('A:K', 15)
        # Normal
        centre_bold, left, left_bold = self.get_styles(workbook, sheet, wiz, 'statement')

        row = 5
        col = 0
        cnt = 1

        # sheet.write(0, 0, 'Date From', left_bold)
        # sheet.write(0, 1, str(wiz.f_date), left)
        #
        # sheet.write(1, 0, 'Date To', left_bold)
        # sheet.write(1, 1, str(wiz.t_date), left)
        #
        # sheet.write(1, 10, 'Salary Statement', left_bold)
        #
        # sheet.write(1, 16, 'Type', left_bold)
        # sheet.write(1, 17, str(wiz.type), left)
        #
        # sheet.write(2, 0, 'Company', left_bold)
        # sheet.write(2, 1, str(wiz.company_id.name), centre_bold)
        #
        # sheet.write(2, 16, 'State', left_bold)
        # sheet.write(2, 17, str(wiz.state), left)

        sheet.write(4, 0, 'Sl.no', left_bold)
        sheet.write(4, 1, 'Employee No', left_bold)
        sheet.write(4, 2, 'Employee Name', left_bold)
        sheet.write(4, 3, 'DOJ', left_bold)
        sheet.write(4, 4, 'Iqama No', left_bold)
        sheet.write(4, 5, 'Basic Salary', left_bold)
        sheet.write(4, 6, 'Gosi Number', left_bold)
        sheet.write(4, 7, 'Gosi Salary', left_bold)
        sheet.write(4, 8, 'Job Title', left_bold)
        sheet.write(4, 9, 'Project', left_bold)
        sheet.write(4, 10, 'Department', left_bold)
        sheet.write(4, 11, 'BANK Name', left_bold)
        sheet.write(4, 12, 'IBAN Number', left_bold)
        sheet.write(4, 13, 'Worked Days', left_bold)
        sheet.write(4, 14, 'Overtime hours', left_bold)
        sheet.write(4, 15, 'Basic Salary', left_bold)
        sheet.write(4, 16, 'Overtime', left_bold)
        sheet.write(4, 17, 'Arrears', left_bold)
        sheet.write(4, 18, 'Gross Salary', left_bold)
        sheet.write(4, 19, 'Advance', left_bold)
        sheet.write(4, 20, 'Housing', left_bold)
        sheet.write(4, 21, 'Gosi', left_bold)
        sheet.write(4, 22, 'Others', left_bold)
        sheet.write(4, 23, 'Net Salary', left_bold)

        for p in case :
            sheet.write(row, 0, str(cnt), left)
            sheet.write(row, 1, str(p.employee_id.emp_code or ''), left)
            sheet.write(row, 2, p.employee_id.name, left)
            sheet.write(row, 3, str(p.employee_id.joined_date or ''), left)
            sheet.write(row, 4, str(p.employee_id.identification_id or ''), left)
            sheet.write(row, 5, str(p.get_rule(p.id, 'BASIC')), left)
            sheet.write(row, 6, str(p.employee_id.gosi_number or ''), left)
            sheet.write(row, 7, str(p.contract_id.gosi_salary or ''), left)
            sheet.write(row, 8, str(p.employee_id.job_id.name or ''), left)
            sheet.write(row, 9, str(''), left)
            sheet.write(row, 10, str(p.employee_id.department_id.name or ''), left)
            sheet.write(row, 11, str(p.employee_id.bank_account_id and p.employee_id.bank_account_id.bank_id.name or ''), left)
            sheet.write(row, 12, str(p.employee_id.bank_account_id and p.employee_id.bank_account_id.bank_id.bic or ''), left)
            sheet.write(row, 13, str(p.worked_days_line_ids and p.worked_days_line_ids[0].number_of_days or ''),
                        left)
            sheet.write(row, 14, str(0), left)
            sheet.write(row, 15, str(p.get_rule(p.id, 'BASIC')), left)
            sheet.write(row, 16, str(p.get_rule(p.id, 'OVERTIME')), left)
            sheet.write(row, 17, str(p.get_rule(p.id, 'ARREARS')), left)
            sheet.write(row, 18, str(p.get_rule(p.id, 'GROSS')), left)
            sheet.write(row, 19, str(p.get_rule(p.id, 'Advance')), left)
            sheet.write(row, 20, str(p.get_rule(p.id, 'housing')), left)
            sheet.write(row, 21, str(p.get_rule(p.id, 'GOSI')), left)
            sheet.write(row, 22, str(p.get_rule(p.id, 'other_allowance')), left)
            sheet.write(row, 23, str(p.get_rule(p.id,'net')), left)

            #sheet.write(row, 8, str(0.0), left)

            #sheet.write(row, 10, str(p.get_total(p.id)), left)

            row += 1
            cnt += 1

        workbook.close()
        output.seek(0)
        data = output.read()
        output.close()
        # f = open(dataFile, 'rb')
        # data = f.read()
        # f.close()
        return data

    def get_styles(self, workbook, sheet, wiz, type):
        left = workbook.add_format({'align': 'left'})
        left.set_font_name('Verdana')
        left.set_font_size(10)
        right = workbook.add_format({'align': 'right'})
        right.set_font_name('Verdana')
        right.set_font_size(10)
        centre = workbook.add_format({'align': 'centre'})
        centre.set_font_name('Verdana')
        centre.set_font_size(10)
        left_indent = workbook.add_format({'align': 'left'})
        left_indent.set_font_name('Verdana')
        left_indent.set_font_size(10)
        left_indent.set_indent(1)
        left_bold = workbook.add_format({'align': 'left', 'bold': True})
        left_bold.set_font_name('Verdana')
        left_bold.set_font_size(10)
        centre_bold = workbook.add_format({'align': 'centre', 'bold': True})
        centre_bold.set_font_name('Verdana')
        centre_bold.set_font_size(12)

        report_name = 'Salary Statement'
        type_position = 16
        state_position = 17
        main_position = 6
        if type == 'wages':
            report_name = 'Wages Report'
            type_position = 8
            state_position = 9
            main_position = 4

        sheet.write(0, 0, 'Date From', left_bold)
        sheet.write(0, 1, str(wiz.f_date), left)

        sheet.write(1, 0, 'Date To', left_bold)
        sheet.write(1, 1, str(wiz.t_date), left)

        sheet.write(1, main_position, report_name , left_bold)

        sheet.write(1, type_position, 'Type', left_bold)
        sheet.write(1, state_position, str(wiz.type), left)

        sheet.write(2, 0, 'Company', left_bold)
        sheet.write(2, 1, str(wiz.company_id.name), centre_bold)

        sheet.write(2, type_position, 'State', left_bold)
        sheet.write(2, state_position, str(wiz.state), left)
        return centre_bold, left, left_bold

    def generate_wages_xls(self, case, wiz, ):
        output = io.BytesIO()
        workbook = WB(output, {'in_memory': True})
        sheet = workbook.add_worksheet()
        # sheet.set_column('A:A', 40)
        sheet.set_column('A:K', 15)
        # Normal
        centre_bold, left, left_bold = self.get_styles(workbook, sheet, wiz, 'wages')

        row = 5
        col = 0
        cnt = 1

        sheet.write(4, 0, 'Sl.no', left_bold)
        sheet.write(4, 1, 'Employee No', left_bold)
        sheet.write(4, 2, 'Employee Name', left_bold)
        sheet.write(4, 3, 'Iqama No', left_bold)
        sheet.write(4, 4, 'BANK Name', left_bold)
        sheet.write(4, 5, 'IBAN Number', left_bold)
        sheet.write(4, 6, 'Net Salary', left_bold)
        sheet.write(4, 7, 'Basic Salary', left_bold)
        sheet.write(4, 8, 'Housing', left_bold)
        sheet.write(4, 9, 'Other Earnings', left_bold)
        sheet.write(4, 10, 'Deductions', left_bold)
        sheet.write(4, 11, 'Payment Detail', left_bold)

        for p in case :
            sheet.write(row, 0, str(cnt), left)
            sheet.write(row, 1, str(p.employee_id.emp_code or ''), left)
            sheet.write(row, 2, p.employee_id.name, left)
            sheet.write(row, 3, str(p.employee_id.identification_id or ''), left)
            sheet.write(row, 4,
                        str(p.employee_id.bank_account_id and p.employee_id.bank_account_id.bank_id.name or ''), left)
            sheet.write(row, 5, str(p.employee_id.bank_account_id and p.employee_id.bank_account_id.bank_id.bic or ''),
                        left)
            sheet.write(row, 6, str(p.get_rule(p.id, 'net')), left)
            sheet.write(row, 7, str(p.get_rule(p.id, 'BASIC')), left)
            sheet.write(row, 8, str(p.get_rule(p.id, 'housing')), left)
            sheet.write(row, 9, str(p.get_rule(p.id, 'other_allowance')), left)
            sheet.write(row, 10, str(p.get_rule(p.id, 'deductions')), left)
            sheet.write(row, 11, str(p.get_rule(p.id, 'payment_details')), left)


        workbook.close()
        output.seek(0)
        data = output.read()
        output.close()
        # f = open(dataFile, 'rb')
        # data = f.read()
        # f.close()
        return data




# -*- coding: utf-8 -*-

from . import models
from . import hr_contract
from . import hr_employee
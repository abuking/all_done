# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrContract(models.Model):
    _name = 'hr.contract'
    _inherit = 'hr.contract'

    gosi_salary = fields.Float('Gosi Salary')

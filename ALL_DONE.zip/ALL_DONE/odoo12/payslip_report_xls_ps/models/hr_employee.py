# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrEmployee(models.Model):
    _name = 'hr.employee'
    _inherit = 'hr.employee'

    gosi_number = fields.Char('Gosi Number')




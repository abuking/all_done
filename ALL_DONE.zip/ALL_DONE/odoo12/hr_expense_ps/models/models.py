# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from odoo import models, fields, api, _
import re

from odoo.exceptions import UserError, ValidationError
from odoo.tools import email_split, float_is_zero

import odoo.addons.decimal_precision as dp

class AccountAnalyticAccount(models.Model):
    _inherit = 'account.analytic.account'
    _description = 'Analytic Account'



class PsPettyCash(models.Model):
    """
        Petty Cash Request for Employee Hr Expenses
    """
    _name = 'ps.petty.cash'
    _rec_name = 'employee_id'
    _description = 'Petty Cash Request for Employee Project'


    def get_due_date(self):
        """
        default function to return  value of 3 days from the creation date
        :return:
        """
        return datetime.today() + timedelta(days=3)

    def _balance_limit(self):
        expense_obj = self.env['hr.expense.ps']
        for case in self:
            total = 0
            expense_ids = expense_obj.search([('employee_id','=',case.employee_id.id)])
            for expense in expense_ids:
                total += sum([l.total_amount for l in expense.line_ids])
            case.balance_limit = case.approved_limit - total

    employee_id = fields.Many2one('hr.employee', 'Employee')
    fund_limit = fields.Float('Fund Limit')
    approved_limit = fields.Float('Approved Limit')
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account')
    creation_date = fields.Date('Date', default=fields.Date.today())
    due_date = fields.Date('Due Date', default=fields.Date.today() + timedelta(days=3))
    balance_limit = fields.Float(compute="_balance_limit", string="Balance")

    #due_date = fields.Date('Due Date', default=get_due_date)


class HrExpensePs(models.Model):
    _name = "hr.expense.ps"
    _inherit = ['mail.thread', 'resource.mixin']
    _description = "Expense"
    _order = "date desc, id desc"




    name = fields.Char(string='Expense Description', readonly=True, required=True,
                       states={'draft': [('readonly', False)], 'refused': [('readonly', False)]})
    date = fields.Date(readonly=True, states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
                       default=fields.Date.context_today, string="Date")
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True, readonly=True,
                                  states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
                                  default=lambda self: self.env['hr.employee'].search([('user_id', '=', self.env.uid)],
                                                                                      limit=1))
    product_id = fields.Many2one('product.product', string='Product', readonly=False,
                                 domain=[('can_be_expensed', '=', True)])
    product_uom_id = fields.Many2one('uom.uom', related='product_id.uom_id',string='Unit of Measure', required=False, readonly=True,
                                     states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},)
    # product_uom_id = fields.Many2one('product.uom', string='Unit of Measure', required=False, readonly=True,
    #                                  states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
    #                                  default=lambda self: self.env['product.uom'].search([], limit=1, order='id'))
    unit_amount = fields.Float(string='Unit Price', readonly=True, required=False,
                               states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
                               digits=dp.get_precision('Product Price'))
    quantity = fields.Float(required=False, readonly=True,
                            states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
                            digits=dp.get_precision('Product Unit of Measure'), default=1)
    tax_ids = fields.Many2many('account.tax', 'expense_ps_tax', 'expense_ps_id', 'tax_id', string='Taxes',
                               states={'done': [('readonly', True)], 'post': [('readonly', True)]})
    total_amount = fields.Float(string='Total', store=False, compute='_compute_amount',
                                digits=dp.get_precision('Account'))
    company_id = fields.Many2one('res.company', string='Company', readonly=True,
                                 states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
                                 default=lambda self: self.env.user.company_id)
    currency_id = fields.Many2one('res.currency', string='Currency', readonly=True,
                                  states={'draft': [('readonly', False)], 'refused': [('readonly', False)]},
                                  default=lambda self: self.env.user.company_id.currency_id)
    analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic Account',
                                          states={'post': [('readonly', True)], 'done': [('readonly', True)]},
                                          oldname='analytic_account')
    account_id = fields.Many2one('account.account', string='Account',
                                 states={'post': [('readonly', True)], 'done': [('readonly', True)]},
                                 default=lambda self: self.env['ir.property'].get('property_account_expense_categ_id',
                                                                                  'product.category'))
    description = fields.Text()
    payment_mode = fields.Selection([("own_account", "Employee (to reimburse)"), ("company_account", "Company")],
                                    default='own_account',
                                    states={'done': [('readonly', True)], 'post': [('readonly', True)]},
                                    string="Payment By")
    attachment_number = fields.Integer(compute='_compute_attachment_number', string='Number of Attachments')
    state = fields.Selection([
        ('draft', 'To Submit'),
        ('submitted', 'Submitted'),
        ('reported', 'Reported'),
        ('done', 'Posted'),
        ('refused', 'Refused')
    ], compute='_compute_state', string='Status', copy=False, index=True, readonly=True, store=True,
        help="Status of the expense.")
    sheet_id = fields.Many2one('hr.expense.sheet', string="Expense Report", readonly=True, copy=False)
    reference = fields.Char(string="Bill Reference")
    line_ids = fields.One2many('hr.expense.line', 'expense_ps_id', 'Lines')
    petty_cash_id = fields.Many2one('ps.petty.cash', 'Petty Cash')
    approved_limit = fields.Float('Approved Limit', related='petty_cash_id.approved_limit')

    @api.depends('sheet_id', 'sheet_id.account_move_id', 'sheet_id.state')
    def _compute_state(self):
        for expense in self:
            if not expense.sheet_id:
                expense.state = "draft"
            elif expense.sheet_id.state == "cancel":
                expense.state = "refused"
            elif not expense.sheet_id.account_move_id:
                expense.state = "reported"
            else:
                expense.state = "done"

    @api.depends('quantity', 'unit_amount', 'tax_ids', 'currency_id')
    def _compute_amount(self):
        for expense in self:
            total = sum([l.total_amount for l in expense.line_ids])
            expense.total_amount = total
            # expense.untaxed_amount = expense.unit_amount * expense.quantity
            # taxes = expense.tax_ids.compute_all(expense.unit_amount, expense.currency_id, expense.quantity,
            #                                     expense.product_id, expense.employee_id.user_id.partner_id)
            # expense.total_amount = taxes.get('total_included')

    @api.multi
    def _compute_attachment_number(self):
        attachment_data = self.env['ir.attachment'].read_group(
            [('res_model', '=', 'hr.expense'), ('res_id', 'in', self.ids)], ['res_id'], ['res_id'])
        attachment = dict((data['res_id'], data['res_id_count']) for data in attachment_data)
        for expense in self:
            expense.attachment_number = attachment.get(expense.id, 0)

    @api.multi
    def view_sheet(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'hr.expense.sheet',
            'target': 'current',
            'res_id': self.sheet_id.id
        }

    @api.multi
    def submit_expenses(self):
        exp_obj = self.env['hr.expense']
        sheet_obj = self.env['hr.expense.sheet']

        if any(expense.state != 'draft' for expense in self):
            raise UserError(_("You cannot report twice the same line!"))
        if len(self.mapped('employee_id')) != 1:
            raise UserError(_("You cannot report expenses for different employees in the same report!"))

        for case in self:
            total = sum([l.total_amount for l in case.line_ids])
            # earlier condition case.approved_limit != total
            if total > case.approved_limit:
                raise UserError(_("You cannot report expense as approved Limit and expenses does not match!"))

        # for framing the lines and calling the respective sheet_id.
        lines = []
        for case in self:
            lines = []
            vals = {
                'name': case.name,
                'account_id': case.account_id.id,
                'date': case.date,
                'reference': case.reference,
                'employee_id': case.employee_id.id,
                'analytic_account_id': case.analytic_account_id and case.analytic_account_id.id or False,
                'payment_mode': case.payment_mode
            }
            for l in case.line_ids:
                line_vals = vals.copy()
                line_vals.update({
                    'product_id': l.product_id.id,
                    'unit_amount': l.unit_amount,
                    'product_uom_id': l.product_uom_id.id,
                    'quantity': l.quantity,
                    'tax_ids': l.tax_ids and [(6, 0, l.tax_ids._ids)] or [],
                    'supplier_id' : l.supplier_id and l.supplier_id.id or False,
                    'product_expense_account_id' : l.product_expense_account_id and l.product_expense_account_id.id or False,
                    'invoice_no': l.invoice_no,
                    'invoice_date': l.invoice_date,
                    'discount': l.discount,
                    'analytic_account' : l.analytic_account and l.analytic_account.id or False

                })
                lines.append(exp_obj.create(line_vals))

            # getting partner from the
            partner_id = case.employee_id.parent_id and case.employee_id.parent_id.user_id.partner_id.id or False

        sheet_id = sheet_obj.create({
            #'expense_line_ids': [line.id for line in lines],
            'employee_id': self[0].employee_id.id,
            'name': self.name or ''
        })
        for l in lines:
            l.write({'sheet_id':sheet_id.id})

        if partner_id:
            sheet_id.message_post(subject="Expense to Approve",
                              body="Expense to Approve",
                              message_type='comment',
                              subtype='mt_comment',
                              partner_ids=[partner_id]
                              )

        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'hr.expense.sheet',
            'target': 'current',
            'res_id' : sheet_id.id
            # 'context': {
            #     'default_expense_line_ids': [line.id for line in lines],
            #     'default_employee_id': self[0].employee_id.id,
            #     'default_name': self[0].name if len(self.ids) == 1 else ''
            # }
        }


class HrExpenseline(models.Model):
    _name = 'hr.expense.line'
    _rec_name = 'product_id'
    _description = 'New Description'

    @api.depends('quantity', 'unit_amount', 'tax_ids', 'currency_id','discount')
    def _compute_amount(self):
        context = dict(self._context or {})
        employee_id = self.env['hr.employee'].browse(context.get('employee_id'))
        for expense in self:
            expense.untaxed_amount = expense.unit_amount * expense.quantity
            unit_price = (expense.unit_amount) * (1.0 - expense.discount / 100.0)
            taxes = expense.tax_ids.compute_all(unit_price, expense.currency_id, expense.quantity,
                                                expense.product_id, employee_id.user_id.partner_id)
            expense.total_amount = taxes.get('total_included')

    @api.onchange('product_id')
    def onchange_product(self):
        if self.product_id:
            self.product_expense_account_id = self.product_id.categ_id.property_account_expense_categ_id.id

        else:
            self.product_expense_account_id = False


    product_id = fields.Many2one('product.product', 'Product')
    product_uom_id = fields.Many2one('uom.uom', related='product_id.uom_id', string='Unit of Measure')
    #product_uom_id = fields.Many2one('product.uom', string='Unit of Measure',
    #                                 default=lambda self: self.env['product.uom'].search([], order='id'))
#    product_uom_id = fields.Many2one('product.uom', string='Unit of Measure',
 #                                    default=lambda self: self.env['product.uom'].search([], limit=1, order='id'))

    unit_amount = fields.Float(string='Unit Price',
                               digits=dp.get_precision('Product Price'))
    quantity = fields.Float(required=True, readonly=False,
                            digits=dp.get_precision('Product Unit of Measure'), default=1)
    tax_ids = fields.Many2many('account.tax', 'expense_tax_ps', 'ps_expense_id', 'tax_id', string='Taxes',
                               )
    company_id = fields.Many2one('res.company', string='Company',
                                 default=lambda self: self.env.user.company_id)
    currency_id = fields.Many2one('res.currency', string='Currency',
                                  default=lambda self: self.env.user.company_id.currency_id)
    expense_ps_id = fields.Many2one('hr.expense.ps', 'Expense')
    total_amount = fields.Float('Total', compute=_compute_amount)
    account_id = fields.Many2one('account.account', string='Account',
                                 default=lambda self: self.env['ir.property'].get('property_account_expense_categ_id',
                                                                                  'product.category'))

    supplier_id = fields.Many2one('res.partner','Supplier')
    vat_no = fields.Char(related="supplier_id.vat", string="Supplier VAT")
    analytic_account = fields.Many2one('account.analytic.account', string='Analytic Account', default=False, required=False)
    product_expense_account_id = fields.Many2one('account.account','Product Expense')
    invoice_no = fields.Char('Invoice Number')
    invoice_date = fields.Date('Invoice Date')
    discount = fields.Float('Discount(%)')
    product_description = fields.Char("Description")
    analytic_tag_ids = fields.Many2many('account.analytic.tag', string='Analytic Tags')


    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.name = self.product_id.display_name or ''
            self.unit_amount = self.product_id.price_compute('standard_price')[self.product_id.id]
            self.product_uom_id = self.product_id.uom_id
            self.tax_ids = self.product_id.supplier_taxes_id
            account = self.product_id.product_tmpl_id._get_product_accounts()['expense']
            if account:
                self.account_id = account

    @api.onchange('product_uom_id')
    def _onchange_product_uom_id(self):
        if self.product_id and self.product_uom_id.category_id != self.product_id.uom_id.category_id:
            raise UserError(
                _('Selected Unit of Measure does not belong to the same category as the product Unit of Measure'))


class HrExpense(models.Model):
    _name = 'hr.expense'
    _inherit = 'hr.expense'

    @api.depends('quantity', 'unit_amount', 'tax_ids', 'currency_id','discount')
    def _compute_amount(self):
        for expense in self:
            expense.untaxed_amount = expense.unit_amount * expense.quantity
            unit_price = (expense.unit_amount) * (1.0 - expense.discount / 100.0)
            taxes = expense.tax_ids.compute_all(unit_price, expense.currency_id, expense.quantity,
                                                expense.product_id, expense.employee_id.user_id.partner_id)
            expense.total_amount = taxes.get('total_included')



    product_id = fields.Many2one('product.product', 'Product')
    supplier_id = fields.Many2one('res.partner', 'Supplier')
    vat_no = fields.Char(related="supplier_id.vat", string="Supplier VAT")
    product_expense_account_id = fields.Many2one('account.account', 'Product Expense',
                                                 )
    invoice_no = fields.Char('Invoice Number')
    invoice_date = fields.Date('Invoice Date')
    discount = fields.Float('Discount(%)')


class HrExpenseSheet(models.Model):
    _name = 'hr.expense.sheet'
    _inherit = 'hr.expense.sheet'

    journal_id = fields.Many2one('account.journal', string='Expense Journal',
                                 states={'done': [('readonly', True)], 'post': [('readonly', True)]},
                                 default=lambda self: self.env['account.journal'].search(
                                     [('is_expense', '=', True)], limit=1),
                                 help="The journal used when the expense is done.")

class AccountJournal(models.Model):
    _name = 'account.journal'
    _inherit = 'account.journal'

    is_expense = fields.Boolean('Expense Journal')



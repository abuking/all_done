# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from odoo import models, fields, api, _

class ResPartner(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    is_petty_cash_supplier = fields.Boolean('Petty Cash Supplier')


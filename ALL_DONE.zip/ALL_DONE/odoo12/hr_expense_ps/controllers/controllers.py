# -*- coding: utf-8 -*-
from odoo import http

# class HrExpensePs(http.Controller):
#     @http.route('/hr_expense_ps/hr_expense_ps/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_expense_ps/hr_expense_ps/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_expense_ps.listing', {
#             'root': '/hr_expense_ps/hr_expense_ps',
#             'objects': http.request.env['hr_expense_ps.hr_expense_ps'].search([]),
#         })

#     @http.route('/hr_expense_ps/hr_expense_ps/objects/<model("hr_expense_ps.hr_expense_ps"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_expense_ps.object', {
#             'object': obj
#         })
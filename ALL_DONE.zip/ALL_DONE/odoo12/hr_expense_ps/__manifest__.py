# -*- coding: utf-8 -*-
{
    'name': "Expenses Pioneer",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
        
        Workfow of Expenses
        
        1) Account user will create the Petty cash for the employees (employee has no permission to create)
        
        2) Employee will create the Expenses under My expense and submit to manager
        
        3) Manager will get the notification of the Expense
        
        4) When manager validates the Expense the entry will be created for the accounts based on company expense or employee expense
           irrespective of the line account
           
        5) Expense Journal with  is_petty_cash is True will be automatically selected to the Expense.
    """,

    'author': "Mani, Pioneer Solutions",
    'website': "http://ps-sa.net",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','hr_expense','analytic','hr_performance_ps'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/partner.xml',
        'views/views.xml',
        'views/templates.xml',
        'report/report_expense_ps.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
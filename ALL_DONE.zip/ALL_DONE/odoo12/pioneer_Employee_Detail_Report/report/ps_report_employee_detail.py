# -*- coding: utf-8 -*-

import time
from odoo import api, models
from dateutil.parser import parse
from odoo.exceptions import UserError


class ReportEmployeeDetails(models.AbstractModel):
    _name = 'report.pioneer_Employee_Detail_Report.report_employee_detail'


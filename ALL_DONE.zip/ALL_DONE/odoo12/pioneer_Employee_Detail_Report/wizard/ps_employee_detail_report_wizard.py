import time
from odoo import api, models, fields, _
from datetime import datetime
from dateutil import relativedelta
from dateutil.parser import parse
from odoo.exceptions import UserError
import base64
try:
    from xlsxwriter.workbook import Workbook as WB
    from xlrd import cellname
except Exception as e:
    WB = None
    cellname = None
from datetime import datetime

class ps_employee_detail_report_wizard(models.TransientModel):
    _name = "ps.employee.detail.report.wizard"

    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.user.company_id)
    report_type = fields.Selection([('pdf', 'PDF'), ('xls', 'XLS')], 'Report Type', default='xls')
    employee_ids = fields.Many2many('hr.employee', 'ps_employee_detail_report_wiz_employee_rel'
                                    , 'wizard_id', 'employee_id', string='Employees')

    def check_report(self):
        data = {}
        data['form'] = self.read(['company_id', 'report_type', 'employee_ids'])[0]
        if self.report_type == 'xls':
            return self.check_report_xls()
        return self._print_report(data)

    def _print_report(self, data):
        data['form'].update(self.read(['company_id', 'report_type', 'employee_ids'])[0])
        print(data['form'], data)
        return self.env.ref("pioneer_Employee_Detail_Report.ps_report_action_employee_detail").with_context(
            landscape=True).report_action(self, data=data)
        # return self.env.ref('pioneer_Employee_Detail_Report.ps_report_action_employee_detail', data=data)

    def check_report_xls(self):
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/binary/download_document_xls?model=ps.employee.detail.report.wizard&field=datas&id=%s&filename=OPERATIONReport.xls' % (
                self.id),
            'target': 'new',
            'tag': 'reload',
        }
    def get_companydetails(self,company):
        result = company and ((company.street or '')
                              + (company.street2 and (', ' + company.street2) or '')
                              + (company.city and (', ' + company.city) or '')
                              + (company.state_id and (', ' + company.state_id.name) or '')
                              + (company.country_id and (', ' + company.country_id.name) or '')
                              + (company.zip and (' - ' + company.zip) or '')
                              )
        return result
    def get_report_params(self, wiz):
        params = {
            'company_id' : wiz.company_id.id or 0,
            'company_name': wiz.company_id.name,
            'company_dispname': wiz.company_id and wiz.company_id.name or '',
            'company_address': self.get_companydetails(wiz.company_id),
            'report_type': wiz.report_type or '',
            'employee_ids': [x.id for x in wiz.employee_ids],
            'employee_names': ','.join([x.name for x in wiz.employee_ids]) or '',
        }
        return params

    def get_Original_Data(self, params):
        cr = self._cr
        where_clause = ''
        if params.get('company_id'):
            where_clause = """ and e.company_id = """ + str(params.get('company_id'))
        if params.get('employee_ids'):
            status_ids = str(tuple(params.get('employee_ids') or [''])).rstrip(',)') + ")"
            where_clause = where_clause + " and e.id in " + str(status_ids)
        Original_Query = """Select Q1.*
                               
                            from 
                            (
                            select distinct e.emp_code as employee_code
                            , e.emp_code_sort
                                   , r.name as employee_name
                                   , rc.name as employee_nationality
                                   , e.identification_id
                                   , j.name as employee_job
                                   , e.aj_date as employee_doj
                                   , (select exp_id_no from hr_expiry_details where type = 'iqama'
                                        and employee_id = e.id limit 1 
                                      ) as employee_iqama
                                   , (select exp_id_no from hr_expiry_details where type = 'passport'
                                        and employee_id = e.id limit 1 
                                     ) as employee_passport
                                      , ROW_NUMBER() OVER (order by e.emp_code_sort) as row_number
                            from hr_employee e 
                            inner join resource_resource r on r.id = e.resource_id
                            left join res_country as rc on rc.id = e.country_id
                            left join hr_job as j on j.id = e.job_id
                            where (r.active = True or r.active = False) """ + str(where_clause) + """ 
                             )Q1
                             Order by Q1.emp_code_sort, Q1.row_number
                         """
        cr.autocommit(True)  # avoid transaction block
        print('Original_Query ===', Original_Query)
        cr.execute(Original_Query)
        Original_Data = cr.dictfetchall()
        return Original_Data
    def get_Title_Data(self, cr ,ud, params):
        title_query = """ SELECT 'row_number'::text as column, 'Sl. No.' as value, 1 as seq
                                union all select 'employee_code'::text as column, 'Employee Code' as value, 2 as seq
                                union all select 'employee_name'::text as column, 'Employee Name' as value, 3 as seq
                                union all select 'employee_nationality'::text as column, 'Nationality' as value, 4 as seq
                                union all select 'employee_job'::text as column, 'Job' as value, 5 as seq
                                union all select 'employee_iqama'::text as column, 'Iqama' as value, 6 as seq
                                union all select 'employee_passport'::text as column, 'Passport' as value, 7 as seq
                                union all select 'employee_doj'::text as column, 'DOJ' as value, 8 as seq
                        """
        cr.autocommit(True)  # avoid transaction block
        cr.execute(title_query)
        title_data = cr.dictfetchall()
        return title_data

    def Write_TrialBalance_Data(self, cr, uid, params, Original_Data):

        workbook = WB('Cross.xlsx')
        sheet = workbook.add_worksheet()
        sheet.set_column('A:A', 5)
        sheet.set_column('B:I', 30)

        bold = workbook.add_format({'bold': True})
        bold.set_font_name('Verdana')
        bold.set_font_size(9)

        right = workbook.add_format({'align': 'right'})
        right.set_font_name('Verdana')
        right.set_font_size(8)

        left = workbook.add_format({'align': 'left'})
        left.set_font_name('Verdana')
        left.set_font_size(8)

        left_date = workbook.add_format({'num_format': 'dd-MMM-yyyy', 'align': 'left'})
        left_date.set_font_name('Verdana')
        left_date.set_font_size(8)

        money = workbook.add_format({'num_format': '#,##0.00;-#,##0.00'})
        money.set_font_name('Verdana')
        money.set_font_size(8)

        bold_right = workbook.add_format({'align': 'right', 'bold': True})
        bold_right.set_font_name('Verdana')
        bold_right.set_font_size(8)

        bold_left = workbook.add_format({'align': 'left', 'bold': True})
        bold_left.set_font_name('Verdana')
        bold_left.set_font_size(8)

        head_bold_left = workbook.add_format({'align': 'left', 'bold': True})
        head_bold_left.set_font_name('Verdana')
        head_bold_left.set_font_size(8)
        head_bold_left.set_border(1)

        head_bold_right = workbook.add_format({'align': 'right', 'bold': True})
        head_bold_right.set_font_name('Verdana')
        head_bold_right.set_font_size(8)
        head_bold_right.set_border(1)

        head_left = workbook.add_format({'align': 'left', 'bold': True})
        head_left.set_font_name('Verdana')
        head_left.set_font_size(8)
        head_left.set_border(1)

        bold_centre = workbook.add_format({'align': 'centre', 'bold': True})
        bold_centre.set_font_name('Verdana')
        bold_centre.set_font_size(12)

        right_money = workbook.add_format({'align': 'right', 'num_format': '#,##0.00;[RED]-#,##0.00'})
        right_money.set_font_name('Verdana')
        right_money.set_font_size(8)

        bold_right_money = workbook.add_format({'align': 'right', 'bold': True, 'num_format': '#,##0.00;[RED]-#,##0.00'})
        bold_right_money.set_font_name('Verdana')
        bold_right_money.set_font_size(8)

        total_bold_right = workbook.add_format({'align': 'right', 'bold': True})
        total_bold_right.set_font_name('Verdana')
        total_bold_right.set_font_size(8)
        total_bold_right.set_border(1)

        total_bold_right_money = workbook.add_format({'align': 'right', 'bold': True, 'num_format': '#,##0.00;[RED]-#,##0.00'})
        total_bold_right_money.set_font_name('Verdana')
        total_bold_right_money.set_font_size(8)
        total_bold_right_money.set_border(1)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #               TITLE DATA AND QUERY
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        title_data = self.get_Title_Data(cr, uid, params)
        title_vals = {}
        freeze_row = 5
        row = 0
        col = 0
        for td in title_data:
            sheet.write(freeze_row, col, td.get('value').upper(),
                        head_bold_left)
            title_vals[td.get('column')] = col
            col = col + 1
        sheet.freeze_panes(freeze_row, 0)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #               REPORT HEADING
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        row = row
        col = 0
        max_col = max(title_vals.values())
        if params.get('company_id', ''):
            sheet.merge_range(cellname(row, 0) + ':' + cellname(row, max_col), params.get('company_dispname', '').upper(), bold_centre)
            row = row + 1
            sheet.merge_range(cellname(row, 0) + ':' + cellname(row, max_col), params.get('company_address'), bold_centre)
            row = row + 1
        else:
            row = row + 2
        sheet.merge_range(cellname(row, 0) + ':' + cellname(row, max_col), 'Employee Detail Report', bold_centre)
        row = row + 1
        col = 0
        if params.get('employee_ids'):
            col = col + 1
            sheet.write(row, col, 'Employees : ', bold_right)
            col = col + 1
            employee_names = params.get('employee_names')
            sheet.write(row, col, employee_names, left)
        if params.get('employee_ids'):
            col = col + 1

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #               ORIGINAL DATA AND QUERY
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        row = row + 2
        col = 0

        for org in Original_Data:
            col = 0
            row = row + 1
            for td in title_data:
                format = left
                value = org[td['column']]
                if td['column'] == 'employee_doj':
                    format = left_date
                    if value:
                        value = datetime.strptime(value, '%Y-%m-%d')

                sheet.write(row, col, value, format)
                col = col + 1
        row = row + 5

    @api.multi
    def generate_xls(self):
        cr, uid = self._cr, self._uid
        wiz = self
        # context = dict(self._context or {})
        params = self.get_report_params(wiz)
        Original_Data = self.get_Original_Data(params)
        self.Write_TrialBalance_Data(cr, uid, params, Original_Data)
        f = open('Cross.xlsx', 'rb')
        data = f.read()
        filename = 'Employee Detail Report.xlsx'
        return filename, data

    def get_Master_Data(self):
        #Building master data to replace columns in query to increase query performance
        cr = self._cr

        # Partner Category Data
        cr.execute('select id, name from hr_job')
        job_MData = {x.get('id'): x.get('name') for x in cr.dictfetchall() if x}

        #Companies Data
        cr.execute('select id, name from res_company')
        companies_MData = {x.get('id') : x.get('name') for x in cr.dictfetchall() if x}
        # print('date12', datetime.today())

        #Countries Data
        cr.execute('select id, name from res_country')
        countries_MData = {x.get('id') : x.get('name') for x in cr.dictfetchall() if x}

        #Currencies Data
        cr.execute('select id, name from res_currency where active = TRUE ')
        currencies_MData = {x.get('id') : x.get('name') for x in cr.dictfetchall() if x}



        return {
            'job_MData': job_MData,
            'companies_MData':companies_MData,
            'currencies_MData':currencies_MData,
            'countries_MData' : countries_MData,
                    }
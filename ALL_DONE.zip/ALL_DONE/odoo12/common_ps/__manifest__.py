# -*- coding: utf-8 -*-
{
    'name': 'Common',
    'version': '11.0',
    'category': 'Extra',
    'description': """


    """,
    'author': "Mani, Pioneer Solution",
    'depends': ['base','mail','account', 'hr', 'hr_payroll', 'resource'],
    'data': [
        "views/res_config_view.xml",
        "views/config_view.xml",
        "views/hr_view.xml",
        'security/ir.model.access.csv',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,

}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

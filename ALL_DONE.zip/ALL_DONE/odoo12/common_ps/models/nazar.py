# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import except_orm, Warning, RedirectWarning
import logging
_logger = logging.getLogger(__name__)

def mail_create(obj, email_from, email_to, subject, body):
    mail_mail = obj.env['mail.mail']
    mail_ids = []
    mail_ids.append(mail_mail.sudo().create({
                    'email_from': email_from,
                    'email_to': email_to,
                    'subject': subject,
                    'body_html': '<pre>%s</pre>' % body}))
    mail_mail.sudo().send(mail_ids)
    _logger.info('%d mail notification(s) sent.', len(mail_ids))
    return True

def get_email_from(obj):
    UID_ROOT = 1
    email_from = obj.env['res.users'].sudo().browse(UID_ROOT).login
    mail_server_ids = obj.env['ir.mail_server'].sudo().search([('smtp_user','!=',False)])
    if mail_server_ids:
        email_from = obj.env['ir.mail_server'].sudo().browse(mail_server_ids[0].id).smtp_user
    return email_from

def get_config(obj):
    config = {}
    config_ids = obj.env['hr.common.config.settings'].sudo().search([])
    if config_ids:config = config_ids[-1]
    return config


class account_nazar(models.Model):
    _name = 'account.nazar'
    _inherit = ['mail.thread','resource.mixin']

    def account_move_get(self, call_obj, journal_id, date=False, ref='', company_id=False):
        if not journal_id:raise Warning(_('Please choose Journal'))
        return self.pool.get('account.move').account_move_prepare(self.env.cr, self.env.uid, journal_id.id, date=fields.datetime.today(), ref=ref, company_id=company_id, context=self.env.context)









# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

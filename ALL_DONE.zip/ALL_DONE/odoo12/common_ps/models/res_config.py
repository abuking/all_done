# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import except_orm, Warning, RedirectWarning


class hr_common_config_settings(models.TransientModel):
    _name = 'hr.common.config.settings'
    _inherit = 'res.config.settings'

    def _get_managers_ids(self):
        val = {}
        record_ids = self.env['hr.common.config.settings'].search([])
        for record in record_ids: val = self.env['hr.common.config.settings'].browse(record.id).managers_ids
        return val

    managers_ids = fields.Many2many(comodel_name='hr.employee', relation='manager_hr_common_config_settings_rel',
                                    column1='hr_common_config_settings_id', column2='employee_id', string='Managers',
                                    default=_get_managers_ids)

    @api.constrains('managers_ids')
    def _managers_constrains(self):
        val = []
        for manager in self.managers_ids:
            if not manager.work_email: val.append(manager.name)
        if val: raise Warning(_('The following managers are dont have an Email ID! %s') % val)

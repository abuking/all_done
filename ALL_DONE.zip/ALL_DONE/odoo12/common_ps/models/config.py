# -*- coding: utf-8 -*-
from odoo import models

class hr_accounting_config(models.TransientModel):
    _name = 'hr.accounting.config'
    _inherit = 'res.config.settings'

    def _get_hr_accounting_config(self):
        return self.env['hr.accounting.config'].sudo().search([], limit=1, order='id desc')












# -*- coding: utf-8 -*-
from odoo import models, fields



class resource_resource(models.Model):
    _inherit = 'resource.resource'

    name = fields.Char(string='Name', required=True, translate=True)


class hr_employee(models.Model):
    _inherit = 'hr.employee'

    joined_date = fields.Datetime(string='Date of Joined')






     
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

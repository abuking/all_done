# -*- coding: utf-8 -*-
from odoo import models, api, _
from odoo.exceptions import UserError


class pss_cancel_and_revalidate_invoice(models.TransientModel):
    """
    This wizard will confirm the all the selected draft invoices
    """

    _name = "pss.cancel.and.revalidate.invoice"
    _description = "Cancel and Revalidate the invoices to generate SAXON accounting Entries"

    @api.multi
    def button_cancel_create_saxon_JE(self):
        context = dict(self._context or {})
        active_ids = context.get('active_ids', []) or []
        self = self.env['account.invoice'].browse(active_ids)
        inv_ids = [x.state for x in self if x.state != 'open']
        if inv_ids:
            raise UserError(
                _("Selected invoice(s) should be in open State."))
        for case in self:
            cr = case._cr
            if case.state == 'open':
                payment_ids = []
                for x in case.payment_ids:
                    payment_ids.append(x)
                    x.cancel()
                case.action_invoice_cancel()
                print ('1', case)
                cr.commit()
                case.write({'state': 'draft', 'date': False})
                cr.commit()
                print ('2', case.state)
                cr.commit()
                case.action_invoice_open()
                print ('3', case)
                cr.commit()
                for x in payment_ids:
                    x.post()

        return {'type': 'ir.actions.act_window_close'}

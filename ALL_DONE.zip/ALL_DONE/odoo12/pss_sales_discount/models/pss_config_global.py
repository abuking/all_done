# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

@api.model
def calc_discount(self, Frmwhch, case):
    if Frmwhch == 'sale':
        qty = case.product_uom_qty
    elif Frmwhch == 'purchase':
        qty = case.product_qty
    else:
        qty = case.quantity
    discount = 0
    if qty:
        discount = (case.discount_amount * 100) / ((case.price_unit or 1) * qty)
    return discount
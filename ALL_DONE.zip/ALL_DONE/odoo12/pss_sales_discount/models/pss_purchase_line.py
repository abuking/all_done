# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.addons.pss_sales_discount.models import pss_config_global as tg

class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    @api.multi
    @api.depends('write_uid', 'write_date', 'apply_discount_by', 'discount', 'discount_amount')
    def get_discount_percentage_fixed(self):
        for case in self:
            discount_percentage_fixed = ''
            apply_discount_by = case.apply_discount_by
            if apply_discount_by == 'fixed':
                discount_percentage_fixed = case.discount_amount
            elif apply_discount_by == 'percentage':
                discount_percentage_fixed = case.discount
            else:
                discount_percentage_fixed = case.discount
            case.discount_percentage_fixed = discount_percentage_fixed

    #INHERITED
    product_qty = fields.Float(default=1.0)

    #NEW
    discount = fields.Float(string='Discount (%)', digits=dp.get_precision('Discount'),)
    discount_amount = fields.Float(string='Discount', digits=dp.get_precision('Discount'), default=0.0)
    apply_discount_by = fields.Selection(selection=[('fixed', 'Fixed Amount'),('percentage', 'Percentage')], copy=False, string="Apply Discount By")
    discount_percentage_fixed = fields.Float(string="Discount", help='Display Discount By Fixed Amount/Percentage', compute='get_discount_percentage_fixed')

    @api.model
    def default_get(self, fields):
        rec = super(PurchaseOrderLine, self).default_get(fields)
        company = self.env.user.company_id
        apply_discount_by = company.apply_discount_by
        if not apply_discount_by:
            apply_discount_by = 'percentage'
        rec.update({
            'apply_discount_by': apply_discount_by
        })
        return rec

    @api.onchange('price_unit', 'discount_amount', 'product_qty')
    def _compute_discount_amount(self):
        """
        old = price_unit * (discount_perc/100) = discount_amount
        now calc discount_perc:
            1. discount_perc/100 = discount_amount / price_unit
            2. discount_perc = (discount_amount * 100) / price_unit
        """
        for case in self:
            discount = tg.calc_discount(self, 'purchase', case)
                           #(case.discount_amount * 100)/(case.price_unit or 1)
            case.discount = 0

    #inherited
    @api.multi
    def _prepare_invoice_line(self, qty):
        """
        Prepare the dict of values to create the new invoice line for a sales order line.

        :param qty: float quantity to invoice
        """
        res = super(PurchaseOrderLine, self)._prepare_invoice_line(qty)
        if self.discount_amount:
            res['discount_amount'] = self.discount_amount
        return res

    @api.depends('product_qty', 'discount_amount', 'price_unit', 'taxes_id', 'discount')
    def _compute_amount(self):
        for line in self:
            if line.apply_discount_by == 'fixed':
                price = line.product_qty and (line.price_unit - ((line.discount_amount / line.product_qty) or 0.0)) or 0.00
            else:
                price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            #price = line.product_qty and (line.price_unit - ((line.discount_amount/line.product_qty) or 0.0)) or line.price_unit
            taxes = line.taxes_id.compute_all(price, line.order_id.currency_id, line.product_qty, product=line.product_id, partner=line.order_id.partner_id)
            line.update({
                'price_tax': taxes['total_included'] - taxes['total_excluded'],
                'price_total': taxes['total_included'],
                'price_subtotal': taxes['total_excluded']#- line.discount_amount,
            })

    def update_discount(self, res):
        cr = self._cr
        for case in res:
            discount = tg.calc_discount(self, 'purchase', case)
                           #(case.discount_amount * 100) / (case.price_unit or 1)
            cr.execute("""update purchase_order_line set discount = """ + str(discount) + """
                                where id = """ + str(case.id))

    @api.model
    def create(self, vals):
        context = dict(self._context or {})
        res =  super(PurchaseOrderLine, self).create(vals)
        # self.update_discount(res)
        return res

    @api.multi
    def write(self, vals):
        context = dict(self._context or {})
        res =  super(PurchaseOrderLine, self).write(vals)
        # for case in self:
        #     self.update_discount(case)
        return res
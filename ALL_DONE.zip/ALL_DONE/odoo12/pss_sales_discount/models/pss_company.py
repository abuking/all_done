# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT

class ResCompany(models.Model):
    _inherit = 'res.company'

    sale_discount_id = fields.Many2one('account.account', string="Sales Discount"
                                          , help="This sale discount will be assigned by default on new products."
                                         )
    purchase_discount_id = fields.Many2one('account.account', string="Purchase Discount"
                                           , help="This purchase discount will be assigned by default on new products."
                                           )
    apply_discount_by = fields.Selection([('fixed', 'Fixed Amount'),('percentage', 'Percentage')], default='percentage'
                                         ,  string="Apply Discount By")
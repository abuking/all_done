# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.addons.pss_sales_discount.models import pss_config_global as tg
from lxml import etree
from odoo.osv.orm import setup_modifiers

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    amount_discount_untaxed = fields.Monetary(string='Untaxed Amount with Discount', store=True, readonly=True, compute='_amount_all', track_visibility='always')
    amount_discount = fields.Monetary(string='Discount', store=True, readonly=True, compute='_amount_all', track_visibility='always')

    #INHERITED
    @api.depends('order_line.price_total', 'write_date', 'write_uid')
    def _amount_all(self):
        super(SaleOrder, self)._amount_all()
        amount_discount_untaxed = amount_discount = 0.0
        for case in self:

            for line in case.order_line:
                if case.company_id.apply_discount_by == 'fixed':
                    amount_discount_untaxed += (line.price_subtotal + line.discount_amount)
                    amount_discount += line.discount_amount
                else:
                    amount_discount_untaxed += line.price_subtotal + (((line.price_unit * line.product_uom_qty) * line.discount)/100 )
                    amount_discount += (((line.price_unit * line.product_uom_qty) * line.discount)/100 )
            case.update({
                'amount_discount_untaxed': case.pricelist_id.currency_id.round(amount_discount_untaxed),
                'amount_discount': case.pricelist_id.currency_id.round(amount_discount),
            })
    # @api.model
    # def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
    #     context = self._context
    #     res = super(SaleOrder, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar,
    #                                                      submenu=submenu)
    #     doc = etree.XML(res['arch'])
    #     # Hide "discount" when the dscount by fixed
    #     user = self.env.user
    #     group_discount_per_so_line = self.env.user.has_group('sale.group_discount_per_so_line')
    #     if view_type=='form' and group_discount_per_so_line:
    #         if user.company_id.apply_discount_by == 'fixed':
    #             for node in doc.xpath("//field[@name='order_line']/tree/field[@name='discount']"):# + doc.xpath(
    #                     # "//field[@name='order_line']/form//label[@for='discount']") + doc.xpath(
    #                     # "//field[@name='order_line']/form//field[@name='discount']"):
    #                 node.set('string', 'base.group_system')
    #                 setup_modifiers(node, res)
    #                 print 'group_discount_per_so_line2', group_discount_per_so_line, user.company_id.apply_discount_by
    #         else:
    #             for node in doc.xpath("//field[@name='order_line']/tree/field[@name='discount_amount']") + doc.xpath(
    #                     "//field[@name='order_line']/form//label[@for='discount_amount']"):
    #                 node.set('invisible', _('0'))
    #                 setup_modifiers(node, res['fields'])
    #         res['arch'] = etree.tostring(doc)
    #     return res
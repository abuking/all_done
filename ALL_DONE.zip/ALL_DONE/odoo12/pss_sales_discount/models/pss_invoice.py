# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
from odoo.addons.pss_sales_discount.models import pss_config_global as tg

class AccountInvoice(models.Model):
    _inherit = 'account.invoice'

    amount_discount_untaxed = fields.Monetary(string='Untaxed Amount with Discount',store=True, readonly=True, compute='_compute_amount', track_visibility='always')
    amount_discount = fields.Monetary(string='Discount', store=True, readonly=True, compute='_compute_amount', track_visibility='always')



    # INHERITTED
    @api.one
    @api.depends('invoice_line_ids.price_subtotal', 'tax_line_ids.amount', 'currency_id', 'company_id', 'date_invoice',
                 'type')
    def _compute_amount(self):
        super(AccountInvoice, self)._compute_amount()
        amount_discount_untaxed = amount_discount = 0.0
        for case in self:
            for line in case.invoice_line_ids:
                if case.company_id.apply_discount_by == 'fixed':
                    amount_discount_untaxed += (line.price_subtotal + line.discount_amount)
                    amount_discount += line.discount_amount
                else:
                    amount_discount_untaxed += line.price_subtotal + (((line.price_unit * line.quantity) * line.discount) / 100)
                    amount_discount += (((line.price_unit * line.quantity) * line.discount) / 100)

            currency_id = case.currency_id.with_context(date=case.date_invoice)
            case.update({
                'amount_discount_untaxed': currency_id.compute(amount_discount_untaxed, case.company_id.currency_id),
                'amount_discount': currency_id.compute(amount_discount, case.company_id.currency_id),
            })

    # OVERRIDDEN
    @api.multi
    def get_taxes_values(self):
        tax_grouped = {}
        for line in self.invoice_line_ids:
            if line.apply_discount_by == 'fixed':
                price = line.quantity and line.price_unit - ((line.discount_amount / line.quantity) or 0.0) or 0.00
            else:
                price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            # old price_unit = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            taxes = line.invoice_line_tax_ids.compute_all(price, self.currency_id, line.quantity, line.product_id,
                                                          self.partner_id)['taxes']
            for tax in taxes:
                val = self._prepare_tax_line_vals(line, tax)
                key = self.env['account.tax'].browse(tax['id']).get_grouping_key(val)

                if key not in tax_grouped:
                    tax_grouped[key] = val
                else:
                    tax_grouped[key]['amount'] += val['amount']
                    tax_grouped[key]['base'] += val['base']
        return tax_grouped

    @api.model
    def invoice_line_move_line_get(self):
        res = super(AccountInvoice, self).invoice_line_move_line_get()
        for r in res:
            if 'invl_id' in r:
                line = self.env['account.invoice.line'].browse(r['invl_id'])
                discount_amount = (((line.price_unit * line.quantity) * line.discount) / 100)
                if self.company_id.apply_discount_by == 'fixed':
                    discount_amount = line.discount_amount
                r.update({'price' : line.price_subtotal + discount_amount})
        for line in self.invoice_line_ids:       
            if line.discount_amount != 0 or line.discount != 0:
                type = 'dest'
                account_id = line.company_id.sale_discount_id.id
                name = 'Sales Discount'
                discount_amount = (((line.price_unit * line.quantity) * line.discount) / 100)
                if self.company_id.apply_discount_by == 'fixed' :
                    discount_amount = line.discount_amount
                if self.type == 'out_invoice':
                    if not self.env.user.company_id.sale_discount_id:
                        raise UserError(_('Select Sales Discount Account On Accounting->Settings->Sales Discount'))
                if self.type == 'in_invoice':
                    account_id = line.company_id.purchase_discount_id.id
                    type = 'src'
                    name = 'Purchase Discount'
                    if not self.env.user.company_id.purchase_discount_id:
                        raise UserError(_('Select Sales Discount Account On Accounting->Settings->Sales Discount'))
                move_line_dict = {
                'invl_id': line.id,
                'type': type,
                'name': name,
                'price_unit': line.price_unit,
                'quantity': line.quantity,
                'price': discount_amount * -1,
                'account_id': account_id,
                'product_id': line.product_id.id,
                'uom_id': line.uom_id.id,
                'account_analytic_id': line.account_analytic_id.id,
                'invoice_id': self.id,
                }
                res.append(move_line_dict)
        return res

    #INHERITED
    def _prepare_invoice_line_from_po_line(self, line):
        vals = super(AccountInvoice, self)._prepare_invoice_line_from_po_line(
            line)
        vals['discount_amount'] = line.discount_amount
        vals['apply_discount_by'] = line.apply_discount_by
        vals['quantity'] = line.product_qty
        vals['discount'] = line.discount
        return vals

    # @api.model
    # def invoice_line_move_line_get(self):
    #     res = super(AccountInvoice, self).invoice_line_move_line_get()
    #
    #     for line in self.invoice_line_ids:
    #         if line.discount_amount <> 0:
    #             if not self.env.user.company_id.sale_discount_id:
    #                 raise UserError(_('Select Sales Discount Account On Accounting->Settings->Sales Discount'))
    #
    #             move_line_dict = {
    #             'invl_id': line.id,
    #             'type': 'dest',
    #             'name': 'Sales Discount',
    #             'price_unit': line.price_unit,
    #             'quantity': line.quantity,
    #             'price': line.discount_amount * -1,
    #             'account_id': line.company_id.sale_discount_id.id,
    #             'product_id': line.product_id.id,
    #             'uom_id': line.uom_id.id,
    #             'account_analytic_id': line.account_analytic_id.id,
    #             'invoice_id': self.id,
    #             }
    #             res.append(move_line_dict)
    #     return res

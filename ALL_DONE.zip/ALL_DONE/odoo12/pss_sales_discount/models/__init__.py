# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import pss_config_global
from . import pss_company
from . import pss_sale
from . import pss_sale_line
from . import pss_invoice
from . import pss_invoice_line
from . import pss_purchase
from . import pss_purchase_line

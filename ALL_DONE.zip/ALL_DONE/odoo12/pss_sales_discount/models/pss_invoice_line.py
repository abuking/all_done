# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import UserError, ValidationError
from odoo.addons.pss_sales_discount.models import pss_config_global as tg


class InvoiceLine(models.Model):
    _inherit = 'account.invoice.line'

    @api.multi
    @api.depends('write_uid', 'write_date', 'apply_discount_by', 'discount', 'discount_amount')
    def get_discount_percentage_fixed(self):
        for case in self:
            discount_percentage_fixed = ''
            apply_discount_by = case.apply_discount_by
            if apply_discount_by == 'fixed':
                discount_percentage_fixed = case.discount_amount
            elif apply_discount_by == 'percentage':
                discount_percentage_fixed = case.discount
            else:
                discount_percentage_fixed = case.discount
            case.discount_percentage_fixed = discount_percentage_fixed

    # INHRITED
    discount = fields.Float(string='Discount', help="Discount Percentage")

    # NEW
    discount_amount = fields.Float(string='Discount.', digits=dp.get_precision('Discount'), default=0.0)
    apply_discount_by = fields.Selection(selection=[('fixed', 'Fixed Amount'),('percentage', 'Percentage')], copy=False, string="Apply Discount By")
    discount_percentage_fixed = fields.Float(string="Discount", help='Display Discount By Fixed Amount/Percentage', compute='get_discount_percentage_fixed')

    @api.model
    def default_get(self, fields):
        rec = super(InvoiceLine, self).default_get(fields)
        company = self.env.user.company_id
        apply_discount_by = company.apply_discount_by
        if not apply_discount_by:
            apply_discount_by = 'percentage'
        rec.update({
            'apply_discount_by'  : apply_discount_by
        })
        return rec

    #INHERITED
    @api.onchange('price_unit', 'discount_amount', 'quantity')
    def _compute_discount_amount(self):
        """
        old = price_unit * (discount_perc/100) = discount_amount
        now calc discount_perc:
            1. discount_perc/100 = discount_amount / price_unit
            2. discount_perc = (discount_amount * 100) / price_unit
        """
        for case in self:
            discount = tg.calc_discount(self, 'invoice', case)
            case.discount = 0

    # OVERRIDDEN
    @api.one
    @api.depends('price_unit', 'discount', 'invoice_line_tax_ids', 'quantity',
        'product_id', 'discount', 'invoice_id.partner_id', 'invoice_id.currency_id', 'invoice_id.company_id',
        'invoice_id.date_invoice')
    def _compute_price(self):
        currency = self.invoice_id and self.invoice_id.currency_id or None
        price = self.price_unit
        if self.apply_discount_by == 'fixed':
            price = self.quantity and self.price_unit - ((self.discount_amount / self.quantity) or 0.0) or 0.00
        else:
            price = self.price_unit * (1 - (self.discount or 0.0) / 100.0)
        taxes = False
        if self.invoice_line_tax_ids:
            taxes = self.invoice_line_tax_ids.compute_all(price, currency, self.quantity, product=self.product_id, partner=self.invoice_id.partner_id)
        price_subtotal = taxes['total_excluded'] if taxes else (self.quantity * price)
        # price_subtotal = price_subtotal - (self.discount_amount or 0.0)
        # print 'price_subtotalprice_subtotal',price_subtotal, (self.quantity * price), (self.discount_amount)
        self.price_subtotal = price_subtotal_signed = price_subtotal
        if self.invoice_id.currency_id and self.invoice_id.company_id and self.invoice_id.currency_id != self.invoice_id.company_id.currency_id:
            price_subtotal_signed = self.invoice_id.currency_id.with_context(date=self.invoice_id.date_invoice).compute(price_subtotal_signed, self.invoice_id.company_id.currency_id)
        sign = self.invoice_id.type in ['in_refund', 'out_refund'] and -1 or 1
        self.price_subtotal_signed = price_subtotal_signed * sign

    def update_discount(self, res):
        cr = self._cr
        for case in res:
            discount = tg.calc_discount(self, 'invoice', case)
            cr.execute("""update account_invoice_line set discount = """ + str(discount) + """
                                where id = """ + str(case.id))

    @api.model
    def create(self, vals):
        context = dict(self._context or {})
        res =  super(InvoiceLine, self).create(vals)
        # self.update_discount(res)
        return res

    @api.multi
    def write(self, vals):
        context = dict(self._context or {})
        res =  super(InvoiceLine, self).write(vals)
        # for case in self:
            # self.update_discount(case)
        return res
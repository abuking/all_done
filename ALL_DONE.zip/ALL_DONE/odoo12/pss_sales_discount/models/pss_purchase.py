# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.addons.pss_sales_discount.models import pss_config_global as tg

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    amount_discount_untaxed = fields.Monetary(string='Untaxed Amount with Discount', store=True, readonly=True, compute='_amount_all', track_visibility='always')
    amount_discount = fields.Monetary(string='Discount', store=True, readonly=True, compute='_amount_all', track_visibility='always')

    #INHERITED
    @api.depends('order_line.price_total', 'write_date', 'write_uid')
    def _amount_all(self):
        super(PurchaseOrder, self)._amount_all()
        amount_discount_untaxed = amount_discount = 0.0
        for case in self:
            for line in case.order_line:
                if case.company_id.apply_discount_by == 'fixed':
                    amount_discount_untaxed += (line.price_subtotal + line.discount_amount)
                    amount_discount += line.discount_amount
                else:
                    amount_discount_untaxed += line.price_subtotal + (((line.price_unit * line.product_qty) * line.discount) / 100)
                    amount_discount += (((line.price_unit * line.product_qty) * line.discount) / 100)
            case.update({
                'amount_discount_untaxed': case.currency_id.round(amount_discount_untaxed),
                'amount_discount': case.currency_id.round(amount_discount),
            })
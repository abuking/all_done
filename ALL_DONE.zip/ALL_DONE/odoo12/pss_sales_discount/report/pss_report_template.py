# -*- coding: utf-8 -*-

import datetime
import time
from openerp.osv import osv
from openerp.report import report_sxw
from openerp import api, fields, models, _

class wrapper_product_category_report(report_sxw.rml_parse):
    def __init__(self, cr, uid, name, context):
        super(wrapper_product_category_report, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
            'result': self._get_result,
            'get_product_image': self._get_product_image,
            # 'total_result': self._get_total_result,
            'currency': self._get_currency,
        })

    def _get_product_image(self, product_id):
        product = self.pool.get('product.template').browse(self.cr, self.uid, product_id)
        return product

    def _get_currency(self, currency_id):
        currency = self.pool.get('res.currency').browse(self.cr, self.uid, currency_id)
        return currency

    def _get_result(self, product_category_id, date_from, date_to, invoice_type, state, limit):
        where_clause = ""
        if date_from and date_to:
            where_clause = where_clause + " and i.date_invoice between '" + str(date_from) + "' and '" + str(
                date_to) + "'"
        if state:
            where_clause = where_clause + " and i.state = '" + str(state) + "'"
        if product_category_id:
            where_clause = where_clause + " and pc.id = " + str(product_category_id)

        having_clause = ''
        if invoice_type:
            having_clause = having_clause + " and type = '" + str(invoice_type) + "'"
        limit_clause = " limit " + str(limit)

        isql = """  select row_number() OVER (order by invoice_id) AS sl_no
                                , invoice_id
                                , number as invoice_number
                                , type
                                , currency_id
                                , date_invoice as invoice_date
                                , min(customervendor) as customervendor
                                , product_id
                                , (product) as product
				                , category
				                , category_code
				                , sum(case when discount is not null then discount else 0 end) as discount
                                , sum(quantity) as quantity
                                , sum(price_unit) as price_unit
                                , sum(sales_price) as sales_price

                                --, sum(purchase_price) as purchase_price
				                , sum(case when purchase_price is not null then purchase_price else 0 end) as purchase_price
                                , abs(sum(sales_price) - sum(case when purchase_price is not null then purchase_price else 0 end)) as gross_price
                            from
                            (
                                    select
                                         i.id as invoice_id
                                        , i.currency_id
                                        , i.number
                                        , i.type
                                        , i.date_invoice
                                        , ip.name as customervendor
                                        , pt.id as product_id
                                        , pt.name as product
                                        , pc.name as category
                                        , pc.category_code as category_code
         				                , round(((case when il.price_unit is not null then il.price_unit else 0 end)
         				                    * (case when il.quantity is not null then il.quantity else 0 end)
         				                    * (case when il.discount is not null then il.discount else 0 end))/100, 2) as discount
                                        , round(case when il.quantity is not null then il.quantity else 0 end,2) as quantity
                                        , round(case when il.price_unit is not null then il.price_unit else 0 end,2)  as price_unit
                                        , round((case when i.type= 'out_invoice' then
                                              ((case when il.price_unit is not null then il.price_unit else 0 end)
                                              * (case when il.quantity is not null then il.quantity else 0 end)) 
                                              - (((case when il.price_unit is not null then il.price_unit else 0 end)
                                                    * (case when il.quantity is not null then il.quantity else 0 end)
                                                    * (case when il.discount is not null then il.discount else 0 end))/100)
                                                else 0 end),2) as sales_price
                                        --, round((case when i.type= 'in_invoice' then il.price_unit else 0 end * il.quantity),2) as purchase_price
                                        --, max(case when i.type= 'in_invoice' then round(il.price_unit,2) else 0 end) OVER (PARTITION BY il.product_id, pc.id ORDER BY il.product_id, pc.id) as purchase_price
                                        , (select (case when value_float is null then 0 else value_float end)
                                                    * (case when il.quantity is not null then il.quantity else 0 end)
                                              from ir_property
                                               where name = 'standard_price'
                                                and case when res_id is not null
                                                        then split_part(res_id,',',2)::integer else 0 end = pp.id)
                                                as purchase_price
                                    from account_invoice i
                                    inner join account_invoice_line il on il.invoice_id = i.id
                                    left join product_product pp on il.product_id = pp.id
                                    inner join product_template pt on pt.id = pp.product_tmpl_id
                                    inner join product_category pc on pc.id = pt.categ_id
                                    left join res_users ru on ru.id = i.user_id
                                    left join res_partner rp on rp.id = ru.partner_id
                                    left join res_partner ip on ip.id = i.partner_id
                                    where i.state in ('draft', 'open','paid')
                                    """ + str(where_clause) + """
                            )data
                            group by invoice_id, number, type, date_invoice, category, category_code, product, product_id, currency_id
                            having number is not null
                            """ + str(having_clause) + """
                            order by sl_no, number, date_invoice, category, category_code, currency_id
                            """ + str(limit_clause) + """
                            """
        print 'isqlllllllll', isql
        self.cr.execute(isql)
        res = self.cr.dictfetchall()
        return res


class wrapper_product_intcategory_report(report_sxw.rml_parse):
    def __init__(self, cr, uid, name, context):
        super(wrapper_product_intcategory_report, self).__init__(cr, uid, name, context=context)
        self.localcontext.update({
            'result': self._get_result,
            'get_product_image': self._get_product_image,
            'currency': self._get_currency,
        })

    def _get_product_image(self, product_id):
        product = self.pool.get('product.template').browse(self.cr, self.uid, product_id)
        return product

    def _get_currency(self, currency_id):
        currency = self.pool.get('res.currency').browse(self.cr, self.uid, currency_id)
        return currency

    def _get_result(self, product_category_id, date_from, date_to, invoice_type, state, qoh_selection, qoh_value, limit):
        where_clause = ""
        # if date_from and date_to:
        #     where_clause = where_clause + " and i.date_invoice between '" + str(date_from) + "' and '" + str(
        #         date_to) + "'"
        if product_category_id:
            where_clause = where_clause + " and pc.id = " + str(product_category_id)

        limit_clause = " limit " + str(limit)

        isql = """  select product_id
                                , product as product
				                , category
				                , category_code
				                , barcode
				                , internal_ref
                                , sum(case when sales_price is not null then sales_price else 0 end) as sales_price
				                --, sum(case when purchase_price is not null then purchase_price else 0 end) as purchase_price
                                -- , abs(sum(sales_price) - sum(case when purchase_price is not null then purchase_price else 0 end)) as gross_price
                            from
                            (
                                    select
                                        pt.id as product_id
                                        , pt.name as product
                                        , pc.name as category
                                        , pc.category_code
                                        , pp.barcode
                                        , pp.default_code as internal_ref
                                        -- , (select currency_id from res_company where id in (select company_id from
                                        --             product_template where id = pt.id limit 1) limit 1) as currency_id
                                        , round(case when pt.list_price is not null then pt.list_price else 0 end,2) as sales_price
                                        -- , 0 as purchase_price

                                    from product_product pp
                                    inner join product_template pt on pt.id = pp.product_tmpl_id
                                    inner join product_category pc on pc.id = pt.categ_id
                                    """ + str(where_clause) + """
                            )data
                            group by category, category_code, product, barcode, internal_ref, product_id
                            order by category, category_code, product, barcode, internal_ref
                            """ + str(limit_clause) + """ """
        print 'isqlllllllll', isql
        self.cr.execute(isql)
        res = self.cr.dictfetchall()
        if limit != 1:
            res = self.filter_records_based_onQOH(res, qoh_selection, qoh_value)
        # print 'resss', res, qoh_selection, qoh_value
        return res

    def filter_records_based_onQOH(self, res, qoh_selection, qoh_value):
        new_res = []
        for r in res:
            product_id = r.get('product_id', False)
            product = self.pool.get('product.template').browse(self.cr, self.uid, product_id)
            usercompany = self.pool.get('res.users').browse(self.cr, self.uid, self.uid)
            qoh = int(product.qty_available)
            r.update({'qoh' : qoh
                 , 'purchase_price' : float(product.standard_price)
                 , 'sales_price' : product.list_price
                 , 'gross_price' : round(abs(product.list_price - product.standard_price),2)})
            new_res.append(r)
        if qoh_selection == 'greater':
            new_res = [x for x in new_res if x.get('qoh') > qoh_value]
        elif qoh_selection == 'lesser':
            new_res = [x for x in new_res if x.get('qoh') < qoh_value]
        elif qoh_selection == 'equal':
            new_res = [x for x in new_res if x.get('qoh') == qoh_value]
        else:
            new_res = new_res
        return new_res



# select row_number() OVER (order by invoice_id) AS sl_no
#                                 , invoice_id
#                                 , number as invoice_number
#                                 , currency_id
#                                 , date_invoice as invoice_date
#                                 , min(customervendor) as customervendor
#                                 , (product) as product
# 				                , category
# 				                , sum(case when discount is not null then discount else 0 end) as discount
#                                 , sum(quantity) as quantity
#                                 , sum(price_unit) as price_unit
#                                 , sum(sales_price) as sales_price
#                                 , sum(purchase_price) as purchase_price
#                                 , sum(sales_price) - sum(purchase_price) as gross_price
#
#                             from
#                             (
#                             select
#                                  i.id as invoice_id
#                                 , i.currency_id
#                                 , i.number
#                                 , i.date_invoice
#                                 , ip.name as customervendor
#                                 , pt.name as product
# 				                , pc.name as category
# 				                , round(il.discount, 2) as discount
#                                 , round(il.quantity,2) as quantity
#                                 , round(il.price_unit,2) as price_unit
#                                 , round((il.price_unit * il.quantity),2) as sales_price
#                                 , round((case when i.type = 'in_invoice' then il.price_unit else 0 end * il.quantity),2) as purchase_price
#
#                             from account_invoice i
#                             inner join account_invoice_line il on il.invoice_id = i.id
#                             left join product_product pp on il.product_id = pp.id
#                             inner join product_template pt on pt.id = pp.product_tmpl_id
#                             inner join product_category pc on pc.id = pt.categ_id
#                             left join res_users ru on ru.id = i.user_id
#                             left join res_partner rp on rp.id = ru.partner_id
#                             left join res_partner ip on ip.id = i.partner_id
#                             where i.state in ('draft', 'open','paid')
#                              and i.date_invoice between '2017-06-15' and '2017-06-16' and pc.id = 4
#                             )data
#                             group by invoice_id, number, date_invoice, category, product, currency_id
#                             order by sl_no, number, date_invoice, category, currency_id


class product_category_report(osv.AbstractModel):
    _name = 'report.pss_product_category_report.product_category_report'
    _inherit = 'report.abstract_report'
    _template = 'pss_product_category_report.product_category_report'
    _wrapped_report_class = wrapper_product_category_report



class product_intcategory_report(osv.AbstractModel):
    _name = 'report.pss_product_category_report.product_intcategory_report'
    _inherit = 'report.abstract_report'
    _template = 'pss_product_category_report.product_intcategory_report'
    _wrapped_report_class = wrapper_product_intcategory_report

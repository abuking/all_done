# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT

class AccountConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    sale_discount_id = fields.Many2one('account.account', string="Sales Discount"
                                       , related='company_id.sale_discount_id'
                                       , help="This sale discount will be assigned by default on new products."
                                         )
    purchase_discount_id = fields.Many2one('account.account', string="Purchase Discount"
                                       , related='company_id.purchase_discount_id'
                                       , help="This purchase discount will be assigned by default on new products."
                                       )

    @api.multi
    def set_sale_discount(self):
        if self.sale_discount_id and self.sale_discount_id != self.company_id.sale_discount_id:
            self.company_id.write({'sale_discount_id': self.sale_discount_id.id})

    @api.multi
    def set_purchase_discount(self):
        if self.purchase_discount_id and self.purchase_discount_id != self.company_id.purchase_discount_id:
            self.company_id.write({'purchase_discount_id': self.purchase_discount_id.id})

class SaleConfiguration(models.TransientModel):
    _inherit = 'res.config.settings'

    so_order_approval = fields.Boolean("Sale Discount Approval",
                                       default=lambda self: self.env.user.company_id.apply_discount_by == 1)
    apply_discount_by = fields.Selection([('fixed', 'Fixed Amount'),('percentage', 'Percentage')], "Apply Discount By"
                                         , related='company_id.apply_discount_by'
                                         ,implied_group='sale.group_discount_per_so_line')

    @api.multi
    def set_apply_discount(self):
        if self.apply_discount_by :
            self.company_id.write({'apply_discount_by': self.company_id.apply_discount_by})
        else:
            self.company_id.write({'apply_discount_by': 'percentage'})
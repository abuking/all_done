# -*- coding: utf-8 -*-
{
    'name': "Pioneer Menu Configuration",

    'summary': """
        Module to handle Handle Menu configuration
        """,

    'description': """
        These Menu Changes will be hidden based on the group under otheres
        Enable Special Menu's
        
        1- Sales
        Hide   configuration  - commission - credit - invoicing
        2- Sales Order
        Hide  cancel - lock  -  send by mail 
        3- shippment ( delivery)
        Hide  button scrap - return
        4- in invoices
        Hide button  return invoice
        5- Inventory
        want to hide  configuration
        6- internal  transfer
        Hide scrap -  return
        7-Accounting
        HIde this  configuration - commission - bank facilitiy
        8- receipt
         Hide create & edit product & customer 
    """,

    'author': "Pioneer Solution",
    'website': "www.ps-sa.net",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','pos_credit_payment','pioneer_SCC','bank_facility'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'security/security.xml',
        'views/views.xml',
        'views/templates.xml',
        'views/sale_view.xml',
        'views/stock_view.xml',
        'views/account_payment_view.xml',
        'views/account_invoice_view.xml',
        'views/purchase_view.xml',
        'report/sale_report.xml',
        'report/purchase_report.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
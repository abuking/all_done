# -*- coding: utf-8 -*-
{
    'name': 'Pioneer Solutions-Manufacturing ',
    'version': '10.1.2.2',
    'Latest Changes ': 'Manufacturing Technical Analysis',
    'description': """
            This is the Pioneer Solutions Module To Manufacturing Technical Analysis.
            /n
            1. Make a new checkbox like can be sold / purchased : Checkbox name : Block
            2. If the value is true add a new tab as Block Details, so there add the following fields
            """,
    'author': 'Arun, Pioneer Solutions.',
    'depends': ['base', 'mrp','purchase','sale','account','stock','account_almuneef','mrp_byproduct'],

    'data': [
        'data/ps_product_demo.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizard/ps_mob_transport_wiz.xml',
        'views/ps_mob_product.xml',
        'views/ps_mob_users.xml',
        'views/ps_mob_purchase.xml',
        'views/ps_mob_stock_move.xml',
        'views/ps_mob_mrp.xml',
        'views/ps_mob_invoice.xml',
        'views/ps_mob_config.xml',
        'wizard/gang_saw_wiz.xml',
        'wizard/ps_mob_production_view.xml',
        'report/gangsaw_report.xml',
        'report/production_summary_report.xml',
        #'report/purchase_report.xml',
        'report/mo_purchase_report.xml',
        'report/account_report.xml',
        'report/mo_account_report.xml',
        'report/mo_mrp_report.xml',
        'report/mo_statement_production.xml',
        'report/mo_delivery_report.xml',
        'report/report_view.xml'
    ],

    'installable': True,
}

# -*- coding: utf-8 -*-

{
    'name': 'Report Header Footer',
    'version': '1.1',
    'author': 'Abdul Nazar , Pioneer Solutions',
    'category': 'Product',
    'sequence': 21,
    'website': 'http://www.ps-sa.net',
    'summary': 'Change Report Header Footer Image',
    'depends': ['base'],
    'data': [
            'views/views.xml',
            'views/layout.xml'


    ],
    'demo': [],
    'test': [

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'qweb': [],
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# -*- coding: utf-8 -*-
{
    'name': 'Bank Facility',
    'version': '1.0',
    'category': 'Accounts',
    'description': "",
    'author': "Abdul Nazar, Pioneer Solutions",
    'depends': ['base', 'account', 'project', 'hr','purchase'],
    'data': [
        'wizard/account_bank_facility_wizard_view.xml',
        'views/model_view.xml',
        'data/sequence.xml',
        'report/report.xml',
        'report/report_account_bank_facility_bills.xml',
        'report/report_account_bank_facility_lc.xml',
        'report/report_account_bank_facility_lg.xml',
        'report/report_account_bank_facility_loan.xml',
        'report/report_account_bank_facility.xml',
        'report/report_account_bank_facility_report.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
            ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,

}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

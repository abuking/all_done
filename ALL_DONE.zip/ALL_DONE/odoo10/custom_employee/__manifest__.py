# -*- coding: utf-8 -*-
{
    'name': "Custom Employee",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Mani, Pioneer Solutions",
    'website': "www.ps-sa.net",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '11.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr', 'hr_payroll', 'hr_contract', 'hr_holidays_saudi','contacts'],

    # always loaded
    'data': [
        'security/security_groups.xml',
        'security/custom_security.xml',
        'security/ir.model.access.csv',
        #'views/hr_position_classification_category.xml',
        #'views/hr_position_classification_grade.xml',
        #'views/hr_position_classification_position_level.xml',
        'views/hr_employee_expiry_details.xml',
        'views/hr_employee_main.xml',
        'views/hr_employee_mydetails.xml',
        'views/hr_contract_view.xml',
        'views/hr_vacation_tickets.xml',
        'views/hr_labour_office.xml',
        'views/hr_transfer_company.xml',
        'views/hr_employee_clearance.xml',
        'views/hr_identification_letter.xml',
        #'views/hr_commercial_certificate.xml',
        #'views/hr_position_classification.xml',
        'views/hr_business_travel.xml',
        #'views/pss_res_partner.xml',
        'views/pss_hr_payroll.xml',
        'views/hr_duty_commencement.xml',
        'report/template/hr_report_commercial_certificate.xml',
        'report/template/hr_report_employee_clearance.xml',
        'report/template/hr_report_commencement_after_vacation.xml',
        'report/template/hr_report_work_commencement.xml',
        'report/template/hr_report_identification_letter.xml',
        'report/template/hr_report_vacation_tickets.xml',
        'report/template/hr_report_labour_office.xml',
        'report/template/hr_report_action.xml',
        #'wizard/ps_import_csv.xml'
    ],
}

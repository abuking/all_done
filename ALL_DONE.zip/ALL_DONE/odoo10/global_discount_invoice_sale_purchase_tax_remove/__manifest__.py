{
    'name': 'Global Discount on Total Amount',
    'version': '10.0.1.0',
    'category': 'Sales, Invoice, Purchase',
    'summary': "Discount on total in sale, invoice and purchase",
    'author': 'Bala',
    'company': 'HI-TECH',
    'website': 'https://hitech-qatar.com/',

    'description': """

Sale Discount for Total Amount
=======================
Module to manage discount on total amount in Sale.
        as an specific amount or percentage
""",
    'depends': ['sale',
                'account',
                'purchase',
                ],
    'data': [
        'views/sale_view.xml',
        #'views/account_invoice_view.xml',
        #'views/invoice_report.xml',
        #'views/sale_order_report.xml',
        #'views/res_config_view.xml',
        'views/purchase_order_view.xml',

    ],
    'demo': [
    ],
    'application': True,
    'installable': True,
    'auto_install': False,
}

# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
{
    'name': 'Web Digital Signature v11.0',
    'version': '11.0.1.0.0',
    'author': 'Serpent Consulting Services Pvt. Ltd.',
    'sub_author': 'Arun, Pioneer Solutions',
    'maintainer': 'Serpent Consulting Services Pvt. Ltd.',
    'category': '',
    'license': 'AGPL-3',
    'complexity': 'easy',
    'depends': ['web', 'sale', 'purchase', 'stock', 'account'],
    'summary': 'Digital signature control',
    'Latest Change': """added signature type browse/draw""",
    'description': '''
     This module provides the functionality to store digital signature
     for a record.
        -> This  module is helpfull to make your business process a little
           bit more faster & makes it more user friendly by providing you
           digital signature functionality on your documents.
        -> It is touch screen enable so user can add signature with touch
           devices.
        -> Digital signature can be very useful for documents such as
           sale orders, purchase orders, inovoices, payslips, procurement
           receipts, etc.
        -> Display Digital Signature In PO, SO, Invoice, Delivery Slip Reports
        -> Display Company Seal In the right Corner of All PO, SO, Invoice, Delivery Slip Reports
        The example can be seen into the User's form view where we have
        added a test field under signature.        
    ''',
    'data': [
        'security/ps_wds_security_groups.xml',
        'views/ps_wds_template.xml',
        'views/ps_wds_users.xml',
        'views/ps_wds_sale.xml',
        'views/ps_wds_invoice.xml',
        'views/ps_wds_purchase.xml',
        'views/ps_wds_stock.xml',
        'report/ps_wds_report_action.xml',
        'report/ps_wds_report_digital_signature.xml',
        'report/ps_wds_report_purchase_order_digital.xml',
    ],
    'website': 'http://www.serpentcs.com',
    'qweb': ['static/src/xml/digital_sign.xml'],
    'installable': True,
    'auto_install': False,
}

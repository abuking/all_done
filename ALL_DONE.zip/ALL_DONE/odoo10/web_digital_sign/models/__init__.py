# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import ps_wds_config_global
from . import ps_wds_users
from . import ps_wds_company
from . import ps_wds_invoice
from . import ps_wds_sale
from . import ps_wds_invoice
from . import ps_wds_purchase
from . import ps_wds_stock

# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.tools.translate import _
from lxml import etree
from odoo.osv.orm import setup_modifiers
from odoo.exceptions import AccessError, UserError, ValidationError
from odoo.http import request
from odoo import SUPERUSER_ID
import base64
@api.model
def get_user_signature(self):
    for case in self:
        issue_user_signature = False
        approve_user_signature = False
        receive_user_signature = False
        if case.issue_user_id and case.issue_user_id.confirm_digital_signature:
            issue_user_signature = case.issue_user_id.digital_signature or ''
            if case.issue_user_id.signature_type == 'draw':
                issue_user_signature = case.issue_user_id.signature_image
        if case.approve_user_id and case.approve_user_id.confirm_digital_signature:
            approve_user_signature = case.approve_user_id.digital_signature or ''
            if case.approve_user_id.signature_type == 'draw':
                approve_user_signature = case.approve_user_id.signature_image
        if case.receive_user_id and case.receive_user_id.confirm_digital_signature:
            receive_user_signature = case.receive_user_id.digital_signature or ''
            if case.receive_user_id.signature_type == 'draw':
                receive_user_signature = case.receive_user_id.signature_image

        case.issue_user_signature = issue_user_signature
        case.approve_user_signature = approve_user_signature
        case.receive_user_signature = receive_user_signature

@api.model
def get_user_employee_id(self):
    "get the employee if any linked to the loggin user"
    emp_obj = self.env['hr.employee']
    for case in self:
        issue_user_employee_id = False
        receive_user_employee_id = False
        approve_user_employee_id = False
        if case.issue_user_id:
            issue_user_employee_ids = emp_obj.search([('user_id', '=', case.issue_user_id.id)], limit=1)
            issue_user_employee_id = issue_user_employee_ids.id
        if case.approve_user_id:
            approve_user_employee_ids = emp_obj.search([('user_id', '=', case.approve_user_id.id)], limit=1)
            approve_user_employee_id = approve_user_employee_ids.id
        if case.receive_user_id:
            receive_user_employee_ids = emp_obj.search([('user_id', '=', case.receive_user_id.id)], limit=1)
            receive_user_employee_id = receive_user_employee_ids.id

        case.issue_user_employee_id = issue_user_employee_id
        case.approve_user_employee_id = approve_user_employee_id
        case.receive_user_employee_id = receive_user_employee_id

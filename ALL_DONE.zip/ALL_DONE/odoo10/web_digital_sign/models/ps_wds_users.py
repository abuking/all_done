# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import api, models, fields
from odoo.modules import get_module_resource
import sys
import base64
from odoo.modules import get_module_resource

class Users(models.Model):

    _name = 'res.users'
    _inherit = 'res.users'

    digital_signature = fields.Binary("Digital Signature",
                                      help="This field holds the signature used as avatar for this contact, limited to 1024x1024px")
    signature_image = fields.Binary(string='Signature', help='Draw your own signature')
    signature_type = fields.Selection([('browse', 'Browse'), ('draw', 'Draw')], 'Signature Type'
                                      , help="Select the signature type. Choose Upload image/Draw own signature",
                                      default='draw')
    confirm_digital_signature = fields.Boolean('I agree this is my signature')

    @api.model
    def default_get(self, fields):
        rec = super(Users, self).default_get(fields)
        img_path = get_module_resource('web_digital_sign', 'static/src/img', 'digital_signature.gif')
        with open(img_path, "rb") as imageFile:
            digital_signature = base64.b64encode(imageFile.read())
        rec.update({
            'digital_signature': digital_signature,
        })
        return rec

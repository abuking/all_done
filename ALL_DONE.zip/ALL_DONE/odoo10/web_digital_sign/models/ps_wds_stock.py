# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.addons.web_digital_sign.models import ps_wds_config_global as dg

class stock_picking(models.Model):
    _inherit = 'stock.picking'

    @api.multi
    @api.depends('issue_user_id', 'approve_user_id', 'receive_user_id')
    def _get_user_signature(self):
        return dg.get_user_signature(self)

    @api.multi
    @api.depends('issue_user_id', 'approve_user_id', 'receive_user_id')
    def _get_user_employee_id(self):
        return dg.get_user_employee_id(self)

    issue_user_id = fields.Many2one('res.users', 'Issued By')
    approve_user_id = fields.Many2one('res.users', 'Approved By')
    receive_user_id = fields.Many2one('res.users', 'Received/Approved By')

    issue_user_signature = fields.Binary(string="Signature", compute="_get_user_signature")
    approve_user_signature = fields.Binary(string="Signature", compute="_get_user_signature")
    receive_user_signature = fields.Binary(string="Signature", compute="_get_user_signature")

    issue_user_employee_id = fields.Many2one('hr.employee',string="Signature", compute="_get_user_employee_id")
    approve_user_employee_id = fields.Many2one('hr.employee',string="Signature", compute="_get_user_employee_id")
    receive_user_employee_id = fields.Many2one('hr.employee',string="Signature", compute="_get_user_employee_id")

    company_seal = fields.Binary(string="Company Seal", related="company_id.company_seal")

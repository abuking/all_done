# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.addons.web_digital_sign.models import ps_wds_config_global as dg
from odoo.exceptions import UserError

class purchase_order(models.Model):
    _inherit = 'purchase.order'

    @api.multi
    @api.depends('issue_user_id', 'approve_user_id', 'receive_user_id')
    def _get_user_signature(self):
            return dg.get_user_signature(self)

    @api.multi
    @api.depends('issue_user_id', 'approve_user_id', 'receive_user_id')
    def _get_user_employee_id(self):
        return dg.get_user_employee_id(self)

    state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent', 'RFQ Sent'),
        ('to approve', 'To Approve'),
        ('executed', 'Waiting E-MGR Approval'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', track_visibility='onchange')

    #new
    issue_user_id = fields.Many2one('res.users', 'Issued By', default=lambda self: self.env.user)
    approve_user_id = fields.Many2one('res.users', 'Approved By')
    receive_user_id = fields.Many2one('res.users', 'Executed By')

    issue_user_signature = fields.Binary(string="Signature", compute="_get_user_signature")
    approve_user_signature = fields.Binary(string="Signature", compute="_get_user_signature")
    receive_user_signature = fields.Binary(string="Signature", compute="_get_user_signature")

    issue_user_employee_id = fields.Many2one('hr.employee',string="Signature", compute="_get_user_employee_id")
    approve_user_employee_id = fields.Many2one('hr.employee',string="Signature", compute="_get_user_employee_id")
    receive_user_employee_id = fields.Many2one('hr.employee',string="Signature", compute="_get_user_employee_id")

    company_seal = fields.Binary(string="Company Seal", related="company_id.company_seal")

    @api.multi
    def button_print_purchase_order_digital(self):
        """ Print the payment and mark it as sent, so that we can see more
            easily the next step of the workflow
        """
        self.ensure_one()
        return self.env.ref('web_digital_sign.ps_wds_report_action_template_purchase_order_digital').report_action(self)

    @api.multi
    def action_executed(self):
        if not self.user_has_groups('web_digital_sign.group_purchase_executive_director'):
            raise UserError(_('You Dont Have Permission To Approve. Only Executive Director Can Approve'))
        for case in self:
            case.write({'state': 'purchase', 'receive_user_id': self._uid})

    @api.multi
    def button_confirm(self):
        res = super(purchase_order, self).button_confirm()
        for case in self:
            case.write({'state': 'executed', 'approve_user_id': self._uid})
        return res

    @api.multi
    def purchase_order_sign(self):
        #FIXME: NO USE I GUESS(ARUN)
        user_obj = self.env['res.users']
        if self.env.user.confirm_digital_signature:
            self.write({'digital_signature_user_id': self._uid, 'signed': True})
        else:
            raise UserError(_('Error!', 'No signature for this user !'))
            return True
    # REPORT PURPOSE START
    def get_purchase_discount(self):
        is_discount = False
        discount_total = 0
        for pl in self.order_line:
            try:
                pl_discount = pl.discount
            except:
                pl_discount = 0
            discount_total = discount_total + pl_discount
        if discount_total != 0:
            is_discount = True
        result = {'is_discount' : is_discount, 'discount_total' : float(discount_total)}
        print('fffffffff', result)
        return result

class purchase_order_line(models.Model):
    _inherit = 'purchase.order.line'

    ship_by = fields.Char('Ship By')


# -*- coding: utf-8 -*-
{
    'name': "hr_extra",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Abdulla Pioneer Solution",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/10.0/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','hr_holidays_saudi','fleet','custom_employee'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        # 'wizard/wizard_views.xml',
        'views/views.xml',
        'views/templates.xml',
        'views/hr_clearance.xml',
        'views/hr_saher_traffic_clearance.xml',
        'views/hr_button_view.xml',
        'views/hr_duty_commencement_view.xml',
        'report/emp_call_template.xml',
        'report/emp_clearance_report_template.xml',
        'report/emp_saher_clearance_report_template.xml',
        'report/emp_noc_report_template.xml',
        'report/emp_commitment_report_template.xml',
        'report/emp_duty_report_template.xml',
        'views/config.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

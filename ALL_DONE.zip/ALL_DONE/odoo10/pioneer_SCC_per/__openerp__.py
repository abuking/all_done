 # -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd. See LICENSE file for full copyright and licensing details.

{
    'name': 'Pioneer - SCC Sales Commission by Sales/Invoice/Payment',
    'version': '1.0',
    'price': 152.0,
    'currency': 'EUR',
    'category': 'Sales',
    'license': 'Other proprietary',
    'description': """  A Module Which Deals With SCC Includes
                          1. SALES MANAGEMENT with
                                Price Range  to approve
                                Sales order should have discount
                          2. Sales Commissions
                                Commission based on Product Sales
                                Commission based on Sales Representative Target
                """
    # """
    # Sales Commission by Sales/Invoice/Payment
    #
    # sales Commission
    # sale_commission
    # sales_Commission
    # sale Commission
    # sales Commissions
    # sales order Commission
    # order Commission
    # sales person Commission
    # sales team Commission
    # sale team Commission
    # sale person Commission
    # team Commission
    # Commission
    # sales order on Commission
    # invoice on Commission
    # payment on Commission
    # Commission invoice
    # Commission vendor invoice
    # sales Commision
    # Commission sales user invoice
    #
    # Sales Commission (form)
    # Sales Commission (form)
    # Sales Commission List (tree)
    # Sales Commission List (tree)
    # Sales Commission Search (search)
    # Sales Commission Search (search)
    # sales_commission_id (qweb)
    # sales_commission_worksheet_id (qweb)
    #
    # Sales Commission by Sales/Invoice/Payment
    #
    # This module provide feature to manage sales commision by Sales/Invoice/Payments
    #
    #
    # This module allow company to manage sales commision with different options. You can configure after installing module what option/policy your company is following to give commissions to your sales users.
    # We are allowing you to select When to Pay and Calculation based on . Here you can define policy which will be used to give commission to your sales team.
    #
    #
    # For every Calcalulation based on we are allowing you to select:
    # 1. Sales Manager Commission %
    # 2. Sales Person Commission %
    #
    # If you keep Sales Manager Commission 0% then system will not create sales commision lines and sales commision worksheet. System will work only with single option at time ie for example you can select When to Pay = Invoice confirm and calculation based on = Product category so system will run on that and create commission.
    #
    # Please note that When to Pay = Customer payment is only supported with Calculation based on Sales Team. - Other options are supported in matrix.
    # Workflow will be:
    # Option1 : Sales Confirmation -> Create Sales commission worksheet (if not created for current month) -> Add Sales commission lines on worksheet -> For every sales of current month, system will append sales commission lines on worksheet. -> End of month Accouant may review worksheet and create commision invoice to pay/release commision to sales person.
    # Option2 : Invoice Validate -> Create Sales commission worksheet (if not created for current month) -> Add Sales commission lines on worksheet -> For every invoice validation of current month, system will append sales commission lines on worksheet. -> End of month Accouant may review worksheet and create commision invoice to pay/release commision to sales person.
    # Option3 : Customer Payment -> Create Sales commission worksheet (if not created for current month) -> Add Sales commission lines on worksheet -> For every payment from customer of current month, system will append sales commission lines on worksheet. -> End of month Accouant may review worksheet and create commision invoice to pay/release commision to sales person.
    # Commission to sales person always will be in company currency. Multi currency is supported for this module so sales order/ invoice / payment can be in different currency but system will take care for it and create commission lines in company currency.
    # Sales Commission product is created using data and you still can change commission product on commission worksheet to create commission invoice.
    #
    # Menus
    # ---- Invoicing/Commissions
    # ---- ---- Invoicing/Commissions/Commission Worksheets
    # ---- ---- Invoicing/Commissions/Sales Commissions Lines
    # ---- Sales/Commissions
    # ---- ---- Sales/Commissions/Commission Worksheets
    # ---- ---- Sales/Commissions/Sales Commissions Lines
    #
    # Configuration for Sales Commission
    #
    # Commission to sales person always will be in company currency. Multi currency is supported for this module so sales order/ invoice / payment can be in different currency but system will take care for it and create commission lines in company currency.
    # Sales Commission product is created using data and you still can change commission product on commission worksheet to create commission invoice.
    # Commission amount will be based on Net Revenue Model where it consider amounts without taxes. (This module does not support Gross Margin Model)
    #
    #             """
    ,
    'summary': 'This module provide feature to manage sales commission by Sales/Invoice/Payments',
    'author': 'Probuse Consulting Service Pvt. Ltd.',
    'website': 'wwww.probuse.com',
    'depends': ['base', 'account', 'sale', 'sales_team', 'crm', 'utm', 'product', 'mrp_repair'],
    'support': 'contact@probuse.com',
    'data': [
        'security/pss_scc_security_groups.xml',
        'data/pss_scc_default_data.xml',
        # 'view/pss_scc_sale_config_settings.xml',
        # 'view/pss_scc_crm_team.xml',
        # 'view/pss_scc_product_template.xml',
        # 'view/pss_scc_product.xml',
        # 'view/pss_scc_users.xml',
        # 'view/pss_scc_partner.xml',
        # 'view/pss_scc_config.xml',
        # 'view/pss_scc_product_category.xml',
        # 'view/pss_scc_sales_commission_line.xml',
        # 'view/pss_scc_product_category_commission.xml',
        # 'view/pss_scc_salesperson_commission_target.xml',
        # 'view/pss_scc_salesperson_commission_entitlement.xml',
        # 'view/pss_scc_sales_commission.xml',
        'view/pss_scc_account_invoice.xml',
        # 'report/pss_scc_report_sales_commission.xml',
        # 'report/pss_scc_report_sales_commission_worksheet.xml',
        'view/pss_scc_account_payment.xml',
        # 'view/pss_scc_sale.xml',
        'wizard/pss_scc_wizard.xml',
        'data/pss_scc_email_template.xml',
        'security/pss_scc_security_menu.xml',
        'security/ir.model.access.csv',
        'security/pss_scc_security.xml',

    ],
    'installable': True,
    'application': False,
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
